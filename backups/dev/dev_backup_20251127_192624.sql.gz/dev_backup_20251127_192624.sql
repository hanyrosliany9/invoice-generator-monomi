--
-- PostgreSQL database dump
--

\restrict JGqL3Sr1R6ZJzcnLG4o02qgNnS1KmTdBe3UEEFXYPhLMlIzGmG3MgYXwe1vwdzM

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: invoiceuser
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO invoiceuser;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: invoiceuser
--

COMMENT ON SCHEMA public IS '';


--
-- Name: APPaymentStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."APPaymentStatus" AS ENUM (
    'UNPAID',
    'PARTIALLY_PAID',
    'PAID',
    'OVERDUE',
    'WRITTEN_OFF'
);


ALTER TYPE public."APPaymentStatus" OWNER TO invoiceuser;

--
-- Name: APSourceType; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."APSourceType" AS ENUM (
    'VENDOR_INVOICE',
    'EXPENSE',
    'MANUAL_ENTRY'
);


ALTER TYPE public."APSourceType" OWNER TO invoiceuser;

--
-- Name: AccountType; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."AccountType" AS ENUM (
    'ASSET',
    'LIABILITY',
    'EQUITY',
    'REVENUE',
    'EXPENSE'
);


ALTER TYPE public."AccountType" OWNER TO invoiceuser;

--
-- Name: AllocationMethod; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."AllocationMethod" AS ENUM (
    'PERCENTAGE',
    'HOURS',
    'DIRECT',
    'SQUARE_METER',
    'HEADCOUNT'
);


ALTER TYPE public."AllocationMethod" OWNER TO invoiceuser;

--
-- Name: ApprovalStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."ApprovalStatus" AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED'
);


ALTER TYPE public."ApprovalStatus" OWNER TO invoiceuser;

--
-- Name: AssetCondition; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."AssetCondition" AS ENUM (
    'EXCELLENT',
    'GOOD',
    'FAIR',
    'POOR',
    'BROKEN'
);


ALTER TYPE public."AssetCondition" OWNER TO invoiceuser;

--
-- Name: AssetStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."AssetStatus" AS ENUM (
    'AVAILABLE',
    'RESERVED',
    'CHECKED_OUT',
    'IN_MAINTENANCE',
    'BROKEN',
    'RETIRED'
);


ALTER TYPE public."AssetStatus" OWNER TO invoiceuser;

--
-- Name: BalanceType; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."BalanceType" AS ENUM (
    'DEBIT',
    'CREDIT'
);


ALTER TYPE public."BalanceType" OWNER TO invoiceuser;

--
-- Name: BankRecItemStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."BankRecItemStatus" AS ENUM (
    'PENDING',
    'MATCHED',
    'ADJUSTED',
    'CLEARED',
    'UNRESOLVED'
);


ALTER TYPE public."BankRecItemStatus" OWNER TO invoiceuser;

--
-- Name: BankRecItemType; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."BankRecItemType" AS ENUM (
    'DEPOSIT_IN_TRANSIT',
    'OUTSTANDING_CHECK',
    'BANK_CHARGE',
    'BANK_INTEREST',
    'NSF_CHECK',
    'AUTOMATIC_PAYMENT',
    'DIRECT_DEPOSIT',
    'BANK_ERROR',
    'BOOK_ERROR',
    'OTHER_ADJUSTMENT'
);


ALTER TYPE public."BankRecItemType" OWNER TO invoiceuser;

--
-- Name: BankRecStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."BankRecStatus" AS ENUM (
    'DRAFT',
    'IN_PROGRESS',
    'REVIEWED',
    'APPROVED',
    'REJECTED',
    'COMPLETED'
);


ALTER TYPE public."BankRecStatus" OWNER TO invoiceuser;

--
-- Name: BankTransferStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."BankTransferStatus" AS ENUM (
    'PENDING',
    'APPROVED',
    'IN_PROGRESS',
    'COMPLETED',
    'FAILED',
    'REJECTED',
    'CANCELLED'
);


ALTER TYPE public."BankTransferStatus" OWNER TO invoiceuser;

--
-- Name: BudgetPeriod; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."BudgetPeriod" AS ENUM (
    'MONTHLY',
    'QUARTERLY',
    'YEARLY',
    'CUSTOM'
);


ALTER TYPE public."BudgetPeriod" OWNER TO invoiceuser;

--
-- Name: BusinessJourneyEventSource; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."BusinessJourneyEventSource" AS ENUM (
    'SYSTEM',
    'USER',
    'API',
    'WEBHOOK'
);


ALTER TYPE public."BusinessJourneyEventSource" OWNER TO invoiceuser;

--
-- Name: BusinessJourneyEventStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."BusinessJourneyEventStatus" AS ENUM (
    'PENDING',
    'IN_PROGRESS',
    'COMPLETED',
    'CANCELLED',
    'REQUIRES_ATTENTION'
);


ALTER TYPE public."BusinessJourneyEventStatus" OWNER TO invoiceuser;

--
-- Name: BusinessJourneyEventType; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."BusinessJourneyEventType" AS ENUM (
    'CLIENT_CREATED',
    'PROJECT_STARTED',
    'QUOTATION_DRAFT',
    'QUOTATION_SENT',
    'QUOTATION_APPROVED',
    'QUOTATION_DECLINED',
    'QUOTATION_REVISED',
    'INVOICE_GENERATED',
    'INVOICE_SENT',
    'PAYMENT_RECEIVED',
    'PAYMENT_OVERDUE',
    'MATERAI_REQUIRED',
    'MATERAI_APPLIED'
);


ALTER TYPE public."BusinessJourneyEventType" OWNER TO invoiceuser;

--
-- Name: BusinessJourneyPriority; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."BusinessJourneyPriority" AS ENUM (
    'LOW',
    'MEDIUM',
    'HIGH',
    'CRITICAL'
);


ALTER TYPE public."BusinessJourneyPriority" OWNER TO invoiceuser;

--
-- Name: CashCategory; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."CashCategory" AS ENUM (
    'SALES_REVENUE',
    'SERVICE_REVENUE',
    'OTHER_INCOME',
    'OPERATING_EXPENSE',
    'ASSET_PURCHASE',
    'LOAN_REPAYMENT',
    'OTHER_EXPENSE'
);


ALTER TYPE public."CashCategory" OWNER TO invoiceuser;

--
-- Name: CashTransactionStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."CashTransactionStatus" AS ENUM (
    'DRAFT',
    'SUBMITTED',
    'APPROVED',
    'POSTED',
    'REJECTED',
    'VOID'
);


ALTER TYPE public."CashTransactionStatus" OWNER TO invoiceuser;

--
-- Name: CashTransactionType; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."CashTransactionType" AS ENUM (
    'RECEIPT',
    'DISBURSEMENT'
);


ALTER TYPE public."CashTransactionType" OWNER TO invoiceuser;

--
-- Name: CollaboratorRole; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."CollaboratorRole" AS ENUM (
    'OWNER',
    'EDITOR',
    'COMMENTER',
    'VIEWER'
);


ALTER TYPE public."CollaboratorRole" OWNER TO invoiceuser;

--
-- Name: ContentPlatform; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."ContentPlatform" AS ENUM (
    'INSTAGRAM',
    'TIKTOK',
    'FACEBOOK',
    'TWITTER',
    'LINKEDIN',
    'YOUTUBE'
);


ALTER TYPE public."ContentPlatform" OWNER TO invoiceuser;

--
-- Name: ContentStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."ContentStatus" AS ENUM (
    'DRAFT',
    'SCHEDULED',
    'PUBLISHED',
    'FAILED',
    'ARCHIVED'
);


ALTER TYPE public."ContentStatus" OWNER TO invoiceuser;

--
-- Name: CostType; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."CostType" AS ENUM (
    'MATERIAL',
    'LABOR',
    'OVERHEAD',
    'SUBCONTRACTOR',
    'EQUIPMENT'
);


ALTER TYPE public."CostType" OWNER TO invoiceuser;

--
-- Name: Currency; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."Currency" AS ENUM (
    'IDR',
    'USD',
    'USDT'
);


ALTER TYPE public."Currency" OWNER TO invoiceuser;

--
-- Name: DeferredRevenueStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."DeferredRevenueStatus" AS ENUM (
    'DEFERRED',
    'PARTIALLY_RECOGNIZED',
    'FULLY_RECOGNIZED',
    'REFUNDED'
);


ALTER TYPE public."DeferredRevenueStatus" OWNER TO invoiceuser;

--
-- Name: DepreciationMethod; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."DepreciationMethod" AS ENUM (
    'STRAIGHT_LINE',
    'DECLINING_BALANCE',
    'DOUBLE_DECLINING',
    'SUM_OF_YEARS_DIGITS',
    'UNITS_OF_PRODUCTION'
);


ALTER TYPE public."DepreciationMethod" OWNER TO invoiceuser;

--
-- Name: DepreciationStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."DepreciationStatus" AS ENUM (
    'CALCULATED',
    'POSTED',
    'REVERSED',
    'ADJUSTED'
);


ALTER TYPE public."DepreciationStatus" OWNER TO invoiceuser;

--
-- Name: DocumentCategory; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."DocumentCategory" AS ENUM (
    'SUPPORTING_DOCUMENT',
    'CONTRACT',
    'RECEIPT',
    'INVOICE_ATTACHMENT',
    'OTHER'
);


ALTER TYPE public."DocumentCategory" OWNER TO invoiceuser;

--
-- Name: DrawingType; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."DrawingType" AS ENUM (
    'ARROW',
    'CIRCLE',
    'RECTANGLE',
    'FREEHAND',
    'TEXT'
);


ALTER TYPE public."DrawingType" OWNER TO invoiceuser;

--
-- Name: ECLProvisionStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."ECLProvisionStatus" AS ENUM (
    'ACTIVE',
    'WRITTEN_OFF',
    'RECOVERED',
    'REVERSED'
);


ALTER TYPE public."ECLProvisionStatus" OWNER TO invoiceuser;

--
-- Name: EFakturStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."EFakturStatus" AS ENUM (
    'NOT_REQUIRED',
    'PENDING',
    'UPLOADED',
    'VALID',
    'INVALID',
    'EXPIRED'
);


ALTER TYPE public."EFakturStatus" OWNER TO invoiceuser;

--
-- Name: ExpenseApprovalAction; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."ExpenseApprovalAction" AS ENUM (
    'SUBMITTED',
    'APPROVED',
    'REJECTED',
    'RECALLED',
    'PAYMENT_REQUESTED',
    'PAYMENT_COMPLETED'
);


ALTER TYPE public."ExpenseApprovalAction" OWNER TO invoiceuser;

--
-- Name: ExpenseClass; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."ExpenseClass" AS ENUM (
    'SELLING',
    'GENERAL_ADMIN',
    'OTHER',
    'LABOR_COST',
    'COGS'
);


ALTER TYPE public."ExpenseClass" OWNER TO invoiceuser;

--
-- Name: ExpenseDocumentCategory; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."ExpenseDocumentCategory" AS ENUM (
    'RECEIPT',
    'SUPPORTING_DOC',
    'CONTRACT',
    'BUKTI_POTONG',
    'OTHER'
);


ALTER TYPE public."ExpenseDocumentCategory" OWNER TO invoiceuser;

--
-- Name: ExpensePaymentStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."ExpensePaymentStatus" AS ENUM (
    'UNPAID',
    'PENDING',
    'PAID',
    'PARTIAL'
);


ALTER TYPE public."ExpensePaymentStatus" OWNER TO invoiceuser;

--
-- Name: ExpenseStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."ExpenseStatus" AS ENUM (
    'DRAFT',
    'SUBMITTED',
    'APPROVED',
    'REJECTED',
    'PAID',
    'CANCELLED'
);


ALTER TYPE public."ExpenseStatus" OWNER TO invoiceuser;

--
-- Name: GRStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."GRStatus" AS ENUM (
    'DRAFT',
    'RECEIVED',
    'INSPECTED',
    'POSTED',
    'CANCELLED'
);


ALTER TYPE public."GRStatus" OWNER TO invoiceuser;

--
-- Name: HolidayType; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."HolidayType" AS ENUM (
    'NATIONAL',
    'RELIGIOUS',
    'REGIONAL',
    'SUBSTITUTE'
);


ALTER TYPE public."HolidayType" OWNER TO invoiceuser;

--
-- Name: InspectionStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."InspectionStatus" AS ENUM (
    'PENDING',
    'IN_PROGRESS',
    'PASSED',
    'FAILED',
    'PARTIAL'
);


ALTER TYPE public."InspectionStatus" OWNER TO invoiceuser;

--
-- Name: InviteStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."InviteStatus" AS ENUM (
    'PENDING',
    'ACCEPTED',
    'EXPIRED',
    'REVOKED'
);


ALTER TYPE public."InviteStatus" OWNER TO invoiceuser;

--
-- Name: InvoiceStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."InvoiceStatus" AS ENUM (
    'DRAFT',
    'SENT',
    'PAID',
    'OVERDUE',
    'CANCELLED'
);


ALTER TYPE public."InvoiceStatus" OWNER TO invoiceuser;

--
-- Name: JournalStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."JournalStatus" AS ENUM (
    'DRAFT',
    'POSTED',
    'VOID',
    'REVERSED'
);


ALTER TYPE public."JournalStatus" OWNER TO invoiceuser;

--
-- Name: LaborEntryStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."LaborEntryStatus" AS ENUM (
    'DRAFT',
    'SUBMITTED',
    'APPROVED',
    'REJECTED',
    'BILLED'
);


ALTER TYPE public."LaborEntryStatus" OWNER TO invoiceuser;

--
-- Name: LaborType; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."LaborType" AS ENUM (
    'REGULAR',
    'OVERTIME',
    'HOLIDAY',
    'WEEKEND'
);


ALTER TYPE public."LaborType" OWNER TO invoiceuser;

--
-- Name: MaintenanceFrequency; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."MaintenanceFrequency" AS ENUM (
    'DAILY',
    'WEEKLY',
    'MONTHLY',
    'QUARTERLY',
    'SEMI_ANNUAL',
    'ANNUAL',
    'AS_NEEDED'
);


ALTER TYPE public."MaintenanceFrequency" OWNER TO invoiceuser;

--
-- Name: MatchingStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."MatchingStatus" AS ENUM (
    'UNMATCHED',
    'MATCHED',
    'PARTIAL_MATCH',
    'VARIANCE',
    'FAILED'
);


ALTER TYPE public."MatchingStatus" OWNER TO invoiceuser;

--
-- Name: MediaAssetType; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."MediaAssetType" AS ENUM (
    'VIDEO',
    'IMAGE',
    'RAW_IMAGE'
);


ALTER TYPE public."MediaAssetType" OWNER TO invoiceuser;

--
-- Name: MediaReviewStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."MediaReviewStatus" AS ENUM (
    'DRAFT',
    'IN_REVIEW',
    'NEEDS_CHANGES',
    'APPROVED',
    'ARCHIVED'
);


ALTER TYPE public."MediaReviewStatus" OWNER TO invoiceuser;

--
-- Name: MediaType; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."MediaType" AS ENUM (
    'IMAGE',
    'VIDEO',
    'CAROUSEL'
);


ALTER TYPE public."MediaType" OWNER TO invoiceuser;

--
-- Name: MilestonePriority; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."MilestonePriority" AS ENUM (
    'LOW',
    'MEDIUM',
    'HIGH'
);


ALTER TYPE public."MilestonePriority" OWNER TO invoiceuser;

--
-- Name: MilestoneStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."MilestoneStatus" AS ENUM (
    'PENDING',
    'IN_PROGRESS',
    'COMPLETED',
    'ACCEPTED',
    'BILLED',
    'CANCELLED'
);


ALTER TYPE public."MilestoneStatus" OWNER TO invoiceuser;

--
-- Name: PKPStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."PKPStatus" AS ENUM (
    'PKP',
    'NON_PKP',
    'GOVERNMENT'
);


ALTER TYPE public."PKPStatus" OWNER TO invoiceuser;

--
-- Name: POItemType; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."POItemType" AS ENUM (
    'GOODS',
    'SERVICE',
    'ASSET',
    'EXPENSE'
);


ALTER TYPE public."POItemType" OWNER TO invoiceuser;

--
-- Name: POStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."POStatus" AS ENUM (
    'DRAFT',
    'PENDING',
    'APPROVED',
    'SENT',
    'PARTIAL',
    'COMPLETED',
    'CANCELLED',
    'CLOSED'
);


ALTER TYPE public."POStatus" OWNER TO invoiceuser;

--
-- Name: PPNCategory; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."PPNCategory" AS ENUM (
    'CREDITABLE',
    'NON_CREDITABLE',
    'EXEMPT',
    'ZERO_RATED'
);


ALTER TYPE public."PPNCategory" OWNER TO invoiceuser;

--
-- Name: PaymentMethod; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."PaymentMethod" AS ENUM (
    'BANK_TRANSFER',
    'CASH',
    'OTHER'
);


ALTER TYPE public."PaymentMethod" OWNER TO invoiceuser;

--
-- Name: PaymentStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."PaymentStatus" AS ENUM (
    'PENDING',
    'CONFIRMED',
    'FAILED',
    'REFUNDED'
);


ALTER TYPE public."PaymentStatus" OWNER TO invoiceuser;

--
-- Name: PaymentType; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."PaymentType" AS ENUM (
    'FULL_PAYMENT',
    'MILESTONE_BASED',
    'ADVANCE_PAYMENT',
    'CUSTOM'
);


ALTER TYPE public."PaymentType" OWNER TO invoiceuser;

--
-- Name: PeriodStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."PeriodStatus" AS ENUM (
    'OPEN',
    'CLOSED',
    'LOCKED'
);


ALTER TYPE public."PeriodStatus" OWNER TO invoiceuser;

--
-- Name: PeriodType; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."PeriodType" AS ENUM (
    'MONTHLY',
    'QUARTERLY',
    'YEARLY'
);


ALTER TYPE public."PeriodType" OWNER TO invoiceuser;

--
-- Name: ProjectStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."ProjectStatus" AS ENUM (
    'PLANNING',
    'IN_PROGRESS',
    'ON_HOLD',
    'COMPLETED',
    'CANCELLED'
);


ALTER TYPE public."ProjectStatus" OWNER TO invoiceuser;

--
-- Name: PublicAccessLevel; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."PublicAccessLevel" AS ENUM (
    'VIEW_ONLY',
    'DOWNLOAD',
    'COMMENT'
);


ALTER TYPE public."PublicAccessLevel" OWNER TO invoiceuser;

--
-- Name: PurchaseSource; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."PurchaseSource" AS ENUM (
    'MANUAL',
    'FROM_PO',
    'FROM_VENDOR_INVOICE'
);


ALTER TYPE public."PurchaseSource" OWNER TO invoiceuser;

--
-- Name: PurchaseType; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."PurchaseType" AS ENUM (
    'DIRECT',
    'CREDIT',
    'FROM_PO'
);


ALTER TYPE public."PurchaseType" OWNER TO invoiceuser;

--
-- Name: QualityStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."QualityStatus" AS ENUM (
    'PENDING',
    'ACCEPTED',
    'REJECTED',
    'CONDITIONAL'
);


ALTER TYPE public."QualityStatus" OWNER TO invoiceuser;

--
-- Name: QuotationStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."QuotationStatus" AS ENUM (
    'DRAFT',
    'SENT',
    'APPROVED',
    'DECLINED',
    'REVISED'
);


ALTER TYPE public."QuotationStatus" OWNER TO invoiceuser;

--
-- Name: ReportStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."ReportStatus" AS ENUM (
    'DRAFT',
    'COMPLETED',
    'SENT'
);


ALTER TYPE public."ReportStatus" OWNER TO invoiceuser;

--
-- Name: ReservationStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."ReservationStatus" AS ENUM (
    'PENDING',
    'CONFIRMED',
    'CANCELLED',
    'COMPLETED'
);


ALTER TYPE public."ReservationStatus" OWNER TO invoiceuser;

--
-- Name: SortOrder; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."SortOrder" AS ENUM (
    'ASC',
    'DESC'
);


ALTER TYPE public."SortOrder" OWNER TO invoiceuser;

--
-- Name: StatementType; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."StatementType" AS ENUM (
    'INCOME_STATEMENT',
    'BALANCE_SHEET',
    'CASH_FLOW',
    'TRIAL_BALANCE',
    'ACCOUNTS_RECEIVABLE',
    'ACCOUNTS_PAYABLE'
);


ALTER TYPE public."StatementType" OWNER TO invoiceuser;

--
-- Name: TransactionType; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."TransactionType" AS ENUM (
    'INVOICE_SENT',
    'INVOICE_PAID',
    'EXPENSE_SUBMITTED',
    'EXPENSE_PAID',
    'PAYMENT_RECEIVED',
    'PAYMENT_MADE',
    'DEPRECIATION',
    'ADJUSTMENT',
    'CLOSING',
    'OPENING',
    'CASH_RECEIPT',
    'CASH_DISBURSEMENT',
    'BANK_TRANSFER',
    'CAPITAL_CONTRIBUTION',
    'OWNER_DRAWING',
    'PO_APPROVED',
    'PO_CANCELLED',
    'GOODS_RECEIVED',
    'VENDOR_INVOICE_APPROVED',
    'VENDOR_PAYMENT_MADE',
    'PURCHASE_RETURN',
    'BANK_RECONCILIATION'
);


ALTER TYPE public."TransactionType" OWNER TO invoiceuser;

--
-- Name: TransferMethod; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."TransferMethod" AS ENUM (
    'INTERNAL',
    'INTERBANK',
    'RTGS',
    'CLEARING',
    'SKN',
    'BIFAST',
    'OTHER'
);


ALTER TYPE public."TransferMethod" OWNER TO invoiceuser;

--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."UserRole" AS ENUM (
    'SUPER_ADMIN',
    'FINANCE_MANAGER',
    'ACCOUNTANT',
    'PROJECT_MANAGER',
    'STAFF',
    'VIEWER',
    'ADMIN',
    'USER'
);


ALTER TYPE public."UserRole" OWNER TO invoiceuser;

--
-- Name: VIStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."VIStatus" AS ENUM (
    'DRAFT',
    'PENDING_MATCH',
    'MATCHED',
    'APPROVED',
    'POSTED',
    'PAID',
    'CANCELLED'
);


ALTER TYPE public."VIStatus" OWNER TO invoiceuser;

--
-- Name: VendorPaymentStatus; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."VendorPaymentStatus" AS ENUM (
    'DRAFT',
    'PENDING',
    'POSTED',
    'CLEARED',
    'CANCELLED',
    'REVERSED'
);


ALTER TYPE public."VendorPaymentStatus" OWNER TO invoiceuser;

--
-- Name: VendorType; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."VendorType" AS ENUM (
    'SUPPLIER',
    'SERVICE_PROVIDER',
    'CONTRACTOR',
    'CONSULTANT',
    'UTILITY',
    'GOVERNMENT',
    'OTHER'
);


ALTER TYPE public."VendorType" OWNER TO invoiceuser;

--
-- Name: WithholdingTaxType; Type: TYPE; Schema: public; Owner: invoiceuser
--

CREATE TYPE public."WithholdingTaxType" AS ENUM (
    'PPH23',
    'PPH4_2',
    'PPH15',
    'NONE'
);


ALTER TYPE public."WithholdingTaxType" OWNER TO invoiceuser;

--
-- Name: auto_create_expense_category(); Type: FUNCTION; Schema: public; Owner: invoiceuser
--

CREATE FUNCTION public.auto_create_expense_category() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_expense_class "ExpenseClass";
  v_code_prefix TEXT;
  v_category_code TEXT;
  v_existing_id TEXT;
BEGIN
  -- Only process if this is an EXPENSE account starting with 5- or 6-
  IF NEW."accountType" = 'EXPENSE' AND (NEW.code LIKE '5-%' OR NEW.code LIKE '6-%') THEN

    -- Generate category code from account code (replace - with _)
    v_category_code := UPPER(REPLACE(NEW.code, '-', '_'));

    -- Determine expense class based on account code pattern
    v_code_prefix := substring(NEW.code from 1 for 2);

    CASE
      -- 5-xxxx: COGS (Cost of Goods Sold)
      WHEN v_code_prefix = '5-' THEN
        v_expense_class := 'COGS';

      -- 6-1xxx: SELLING (Sales Expenses)
      WHEN NEW.code LIKE '6-1%' THEN
        v_expense_class := 'SELLING';

      -- 6-2010: LABOR_COST (Special case)
      WHEN NEW.code = '6-2010' THEN
        v_expense_class := 'LABOR_COST';

      -- 6-2xxx: GENERAL_ADMIN (General & Administrative Expenses)
      WHEN NEW.code LIKE '6-2%' THEN
        v_expense_class := 'GENERAL_ADMIN';

      -- Other 6-xxxx: Default to OTHER
      ELSE
        v_expense_class := 'OTHER';
    END CASE;

    -- Check if expense category already exists for this accountCode
    SELECT id INTO v_existing_id
    FROM expense_categories
    WHERE "accountCode" = NEW.code
    LIMIT 1;

    IF v_existing_id IS NULL THEN
      -- Insert new expense category
      INSERT INTO expense_categories (
        id,
        code,
        "accountCode",
        "expenseClass",
        name,
        "nameId",
        "isActive",
        "createdAt",
        "updatedAt"
      )
      VALUES (
        gen_random_uuid(),
        v_category_code,
        NEW.code,
        v_expense_class,
        NEW.name,
        NEW."nameId",
        NEW."isActive",
        NOW(),
        NOW()
      )
      ON CONFLICT (code) DO UPDATE SET
        "accountCode" = EXCLUDED."accountCode",
        name = EXCLUDED.name,
        "nameId" = EXCLUDED."nameId",
        "isActive" = EXCLUDED."isActive",
        "updatedAt" = NOW();

      RAISE NOTICE 'Auto-created expense category: % for account code: %', v_category_code, NEW.code;
    ELSE
      -- Update existing expense category
      UPDATE expense_categories SET
        name = NEW.name,
        "nameId" = NEW."nameId",
        "isActive" = NEW."isActive",
        "updatedAt" = NOW()
      WHERE id = v_existing_id;

      RAISE NOTICE 'Updated existing expense category for account code: %', NEW.code;
    END IF;
  END IF;

  RETURN NEW;
END;
$$;


ALTER FUNCTION public.auto_create_expense_category() OWNER TO invoiceuser;

--
-- Name: FUNCTION auto_create_expense_category(); Type: COMMENT; Schema: public; Owner: invoiceuser
--

COMMENT ON FUNCTION public.auto_create_expense_category() IS 'Automatically creates or updates expense_categories when new expense accounts (5-xxxx or 6-xxxx) are added to chart_of_accounts';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO invoiceuser;

--
-- Name: account_balances; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.account_balances (
    id text NOT NULL,
    "accountId" text NOT NULL,
    "fiscalPeriodId" text NOT NULL,
    "beginningBalance" numeric(15,2) DEFAULT 0 NOT NULL,
    "debitTotal" numeric(15,2) DEFAULT 0 NOT NULL,
    "creditTotal" numeric(15,2) DEFAULT 0 NOT NULL,
    "endingBalance" numeric(15,2) DEFAULT 0 NOT NULL,
    "isClosed" boolean DEFAULT false NOT NULL,
    "closedAt" timestamp(3) without time zone,
    "lastUpdated" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.account_balances OWNER TO invoiceuser;

--
-- Name: accounts_payable; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.accounts_payable (
    id text NOT NULL,
    "apNumber" text NOT NULL,
    "vendorId" text NOT NULL,
    "sourceType" public."APSourceType" NOT NULL,
    "vendorInvoiceId" text,
    "expenseId" text,
    "originalAmount" numeric(15,2) NOT NULL,
    "paidAmount" numeric(15,2) DEFAULT 0 NOT NULL,
    "outstandingAmount" numeric(15,2) NOT NULL,
    "invoiceDate" timestamp(3) without time zone NOT NULL,
    "dueDate" timestamp(3) without time zone NOT NULL,
    "paymentStatus" public."APPaymentStatus" DEFAULT 'UNPAID'::public."APPaymentStatus" NOT NULL,
    "daysOutstanding" integer,
    "agingBucket" text,
    "journalEntryId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" text NOT NULL,
    "updatedBy" text
);


ALTER TABLE public.accounts_payable OWNER TO invoiceuser;

--
-- Name: allowance_for_doubtful_accounts; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.allowance_for_doubtful_accounts (
    id text NOT NULL,
    "invoiceId" text NOT NULL,
    "calculationDate" timestamp(3) without time zone NOT NULL,
    "fiscalPeriodId" text,
    "agingBucket" text NOT NULL,
    "daysPastDue" integer DEFAULT 0 NOT NULL,
    "outstandingAmount" numeric(15,2) NOT NULL,
    "eclRate" numeric(5,4) NOT NULL,
    "eclAmount" numeric(15,2) NOT NULL,
    "previousEclAmount" numeric(15,2),
    "adjustmentAmount" numeric(15,2),
    "eclModel" text DEFAULT '12_MONTH'::text NOT NULL,
    "lossRateSource" text,
    "provisionStatus" public."ECLProvisionStatus" DEFAULT 'ACTIVE'::public."ECLProvisionStatus" NOT NULL,
    "journalEntryId" text,
    "writtenOffAt" timestamp(3) without time zone,
    "writtenOffBy" text,
    "writeOffReason" text,
    "writeOffAmount" numeric(15,2),
    "recoveredAt" timestamp(3) without time zone,
    "recoveredAmount" numeric(15,2),
    "recoveryJournalId" text,
    notes text,
    "notesId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" text
);


ALTER TABLE public.allowance_for_doubtful_accounts OWNER TO invoiceuser;

--
-- Name: asset_kit_items; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.asset_kit_items (
    id text NOT NULL,
    "kitId" text NOT NULL,
    "assetId" text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.asset_kit_items OWNER TO invoiceuser;

--
-- Name: asset_kits; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.asset_kits (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.asset_kits OWNER TO invoiceuser;

--
-- Name: asset_metadata; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.asset_metadata (
    id text NOT NULL,
    "assetId" text NOT NULL,
    "assigneeId" text,
    "dueDate" timestamp(3) without time zone,
    platforms public."ContentPlatform"[],
    tags text[],
    "customFields" jsonb,
    "cameraModel" text,
    "cameraMake" text,
    lens text,
    iso integer,
    aperture numeric(4,2),
    "shutterSpeed" text,
    "focalLength" integer,
    "capturedAt" timestamp(3) without time zone,
    "gpsLatitude" numeric(10,8),
    "gpsLongitude" numeric(11,8),
    copyright text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.asset_metadata OWNER TO invoiceuser;

--
-- Name: asset_reservations; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.asset_reservations (
    id text NOT NULL,
    "assetId" text NOT NULL,
    "userId" text NOT NULL,
    "projectId" text,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone NOT NULL,
    purpose text NOT NULL,
    status public."ReservationStatus" DEFAULT 'PENDING'::public."ReservationStatus" NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.asset_reservations OWNER TO invoiceuser;

--
-- Name: assets; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.assets (
    id text NOT NULL,
    "assetCode" text NOT NULL,
    name text NOT NULL,
    category text NOT NULL,
    subcategory text,
    manufacturer text,
    model text,
    "serialNumber" text,
    specifications jsonb,
    "purchaseDate" timestamp(3) without time zone NOT NULL,
    "purchasePrice" numeric(15,2) NOT NULL,
    supplier text,
    "invoiceNumber" text,
    "warrantyExpiration" timestamp(3) without time zone,
    "currentValue" numeric(15,2),
    "notesFinancial" text,
    status public."AssetStatus" DEFAULT 'AVAILABLE'::public."AssetStatus" NOT NULL,
    condition public."AssetCondition" DEFAULT 'GOOD'::public."AssetCondition" NOT NULL,
    location text,
    photos text[],
    documents text[],
    "qrCode" text,
    "rfidTag" text,
    tags text[],
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdById" text,
    "vendorId" text,
    "purchaseOrderId" text,
    "goodsReceiptId" text,
    "vendorInvoiceId" text,
    "residualValue" numeric(15,2),
    "usefulLifeYears" integer
);


ALTER TABLE public.assets OWNER TO invoiceuser;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.audit_logs (
    id text NOT NULL,
    action text NOT NULL,
    "entityType" text NOT NULL,
    "entityId" text NOT NULL,
    "oldValues" jsonb,
    "newValues" jsonb,
    "userId" text NOT NULL,
    "ipAddress" text,
    "userAgent" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO invoiceuser;

--
-- Name: bank_reconciliation_items; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.bank_reconciliation_items (
    id text NOT NULL,
    "reconciliationId" text NOT NULL,
    "itemDate" timestamp(3) without time zone NOT NULL,
    "itemType" public."BankRecItemType" NOT NULL,
    description text NOT NULL,
    "descriptionId" text,
    amount numeric(15,2) NOT NULL,
    "isMatched" boolean DEFAULT false NOT NULL,
    "matchedTransactionId" text,
    "matchedAt" timestamp(3) without time zone,
    "matchedBy" text,
    status public."BankRecItemStatus" DEFAULT 'PENDING'::public."BankRecItemStatus" NOT NULL,
    "requiresAdjustment" boolean DEFAULT false NOT NULL,
    "adjustmentJournalId" text,
    "adjustedAt" timestamp(3) without time zone,
    "checkNumber" text,
    reference text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" text,
    notes text
);


ALTER TABLE public.bank_reconciliation_items OWNER TO invoiceuser;

--
-- Name: bank_reconciliations; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.bank_reconciliations (
    id text NOT NULL,
    "reconciliationNumber" text NOT NULL,
    "bankAccountId" text NOT NULL,
    "statementDate" timestamp(3) without time zone NOT NULL,
    "periodStartDate" timestamp(3) without time zone NOT NULL,
    "periodEndDate" timestamp(3) without time zone NOT NULL,
    "bookBalanceStart" numeric(15,2) NOT NULL,
    "bookBalanceEnd" numeric(15,2) NOT NULL,
    "statementBalance" numeric(15,2) NOT NULL,
    "depositsInTransit" numeric(15,2) DEFAULT 0 NOT NULL,
    "outstandingChecks" numeric(15,2) DEFAULT 0 NOT NULL,
    "bankCharges" numeric(15,2) DEFAULT 0 NOT NULL,
    "bankInterest" numeric(15,2) DEFAULT 0 NOT NULL,
    "otherAdjustments" numeric(15,2) DEFAULT 0 NOT NULL,
    "adjustedBookBalance" numeric(15,2) NOT NULL,
    "adjustedBankBalance" numeric(15,2) NOT NULL,
    difference numeric(15,2) DEFAULT 0 NOT NULL,
    "isBalanced" boolean DEFAULT false NOT NULL,
    "statementReference" text,
    "statementFilePath" text,
    status public."BankRecStatus" DEFAULT 'DRAFT'::public."BankRecStatus" NOT NULL,
    "reviewedBy" text,
    "reviewedAt" timestamp(3) without time zone,
    "approvedBy" text,
    "approvedAt" timestamp(3) without time zone,
    "rejectedBy" text,
    "rejectedAt" timestamp(3) without time zone,
    "rejectionReason" text,
    "adjustmentJournalId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" text NOT NULL,
    "updatedBy" text,
    notes text,
    "notesId" text
);


ALTER TABLE public.bank_reconciliations OWNER TO invoiceuser;

--
-- Name: bank_transfers; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.bank_transfers (
    id text NOT NULL,
    "transferNumber" text NOT NULL,
    "transferDate" timestamp(3) without time zone NOT NULL,
    amount numeric(12,2) NOT NULL,
    currency public."Currency" DEFAULT 'IDR'::public."Currency" NOT NULL,
    "originalAmount" numeric(18,2),
    "exchangeRate" numeric(18,8),
    "idrAmount" numeric(15,2) NOT NULL,
    "fromAccountId" text NOT NULL,
    "toAccountId" text NOT NULL,
    description text NOT NULL,
    "descriptionId" text,
    "descriptionEn" text,
    reference text,
    "transferFee" numeric(12,2),
    "feeAccountId" text,
    "feePaymentMethod" text,
    "transferMethod" public."TransferMethod" DEFAULT 'INTERNAL'::public."TransferMethod" NOT NULL,
    "bankReference" text,
    "confirmationCode" text,
    "projectId" text,
    "clientId" text,
    "journalEntryId" text,
    status public."BankTransferStatus" DEFAULT 'PENDING'::public."BankTransferStatus" NOT NULL,
    "approvedBy" text,
    "approvedAt" timestamp(3) without time zone,
    "rejectedBy" text,
    "rejectedAt" timestamp(3) without time zone,
    "rejectionReason" text,
    "completedAt" timestamp(3) without time zone,
    "completedBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" text NOT NULL,
    "updatedBy" text,
    notes text,
    "notesId" text
);


ALTER TABLE public.bank_transfers OWNER TO invoiceuser;

--
-- Name: business_journey_event_metadata; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.business_journey_event_metadata (
    id text NOT NULL,
    "eventId" text NOT NULL,
    "userCreated" text NOT NULL,
    "userModified" text,
    source public."BusinessJourneyEventSource" DEFAULT 'SYSTEM'::public."BusinessJourneyEventSource" NOT NULL,
    priority public."BusinessJourneyPriority" DEFAULT 'MEDIUM'::public."BusinessJourneyPriority" NOT NULL,
    tags text[],
    "relatedDocuments" text[],
    notes text,
    "ipAddress" text,
    "userAgent" text,
    "materaiRequired" boolean DEFAULT false NOT NULL,
    "materaiAmount" numeric(12,2),
    "complianceStatus" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.business_journey_event_metadata OWNER TO invoiceuser;

--
-- Name: business_journey_events; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.business_journey_events (
    id text NOT NULL,
    type public."BusinessJourneyEventType" NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    status public."BusinessJourneyEventStatus" DEFAULT 'PENDING'::public."BusinessJourneyEventStatus" NOT NULL,
    amount numeric(12,2),
    "clientId" text,
    "projectId" text,
    "quotationId" text,
    "invoiceId" text,
    "paymentId" text,
    "createdBy" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.business_journey_events OWNER TO invoiceuser;

--
-- Name: cash_bank_balances; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.cash_bank_balances (
    id text NOT NULL,
    period character varying(100) NOT NULL,
    "periodDate" timestamp(3) without time zone NOT NULL,
    year integer NOT NULL,
    month integer NOT NULL,
    "openingBalance" numeric(15,2) NOT NULL,
    "closingBalance" numeric(15,2) NOT NULL,
    "totalInflow" numeric(15,2) NOT NULL,
    "totalOutflow" numeric(15,2) NOT NULL,
    "netChange" numeric(15,2) NOT NULL,
    "calculatedAt" timestamp(3) without time zone,
    "calculatedBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" text,
    "updatedBy" text,
    notes text
);


ALTER TABLE public.cash_bank_balances OWNER TO invoiceuser;

--
-- Name: cash_transactions; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.cash_transactions (
    id text NOT NULL,
    "transactionNumber" text NOT NULL,
    "transactionType" public."CashTransactionType" NOT NULL,
    category public."CashCategory" NOT NULL,
    "transactionDate" timestamp(3) without time zone NOT NULL,
    amount numeric(12,2) NOT NULL,
    currency public."Currency" DEFAULT 'IDR'::public."Currency" NOT NULL,
    "originalAmount" numeric(18,2),
    "exchangeRate" numeric(18,8),
    "idrAmount" numeric(15,2) NOT NULL,
    "cashAccountId" text NOT NULL,
    "offsetAccountId" text NOT NULL,
    description text NOT NULL,
    "descriptionId" text,
    "descriptionEn" text,
    reference text,
    "paymentMethod" public."PaymentMethod" DEFAULT 'CASH'::public."PaymentMethod" NOT NULL,
    "checkNumber" text,
    "bankReference" text,
    "projectId" text,
    "clientId" text,
    "journalEntryId" text,
    status public."CashTransactionStatus" DEFAULT 'DRAFT'::public."CashTransactionStatus" NOT NULL,
    "approvedBy" text,
    "approvedAt" timestamp(3) without time zone,
    "rejectedBy" text,
    "rejectedAt" timestamp(3) without time zone,
    "rejectionReason" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" text NOT NULL,
    "updatedBy" text,
    notes text,
    "notesId" text
);


ALTER TABLE public.cash_transactions OWNER TO invoiceuser;

--
-- Name: chart_of_accounts; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.chart_of_accounts (
    id text NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    "nameId" text NOT NULL,
    "accountType" public."AccountType" NOT NULL,
    "accountSubType" text NOT NULL,
    "normalBalance" public."BalanceType" NOT NULL,
    "parentId" text,
    "isControlAccount" boolean DEFAULT false NOT NULL,
    "isTaxAccount" boolean DEFAULT false NOT NULL,
    "taxType" text,
    currency public."Currency" DEFAULT 'IDR'::public."Currency" NOT NULL,
    "isCurrencyAccount" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "isSystemAccount" boolean DEFAULT false NOT NULL,
    description text,
    "descriptionId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.chart_of_accounts OWNER TO invoiceuser;

--
-- Name: clients; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.clients (
    id text NOT NULL,
    name text NOT NULL,
    email text,
    phone text,
    address text,
    company text,
    "contactPerson" text,
    "paymentTerms" text,
    status text DEFAULT 'active'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "taxNumber" text,
    "bankAccount" text,
    notes text
);


ALTER TABLE public.clients OWNER TO invoiceuser;

--
-- Name: collection_items; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.collection_items (
    id text NOT NULL,
    "collectionId" text NOT NULL,
    "assetId" text NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    "addedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.collection_items OWNER TO invoiceuser;

--
-- Name: collections; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.collections (
    id text NOT NULL,
    "projectId" text NOT NULL,
    name text NOT NULL,
    description text,
    "isDynamic" boolean DEFAULT true NOT NULL,
    filters jsonb,
    "groupBy" text,
    "sortBy" text DEFAULT 'uploadedAt'::text NOT NULL,
    "sortOrder" public."SortOrder" DEFAULT 'DESC'::public."SortOrder" NOT NULL,
    "isShared" boolean DEFAULT false NOT NULL,
    "shareToken" text,
    "sharePassword" text,
    "createdBy" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.collections OWNER TO invoiceuser;

--
-- Name: company_settings; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.company_settings (
    id text DEFAULT 'default'::text NOT NULL,
    "companyName" text DEFAULT 'PT Teknologi Indonesia'::text NOT NULL,
    address text,
    phone text,
    email text,
    website text,
    "taxNumber" text,
    currency text DEFAULT 'IDR'::text NOT NULL,
    "bankBCA" text,
    "bankMandiri" text,
    "bankBNI" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.company_settings OWNER TO invoiceuser;

--
-- Name: content_calendar_items; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.content_calendar_items (
    id text NOT NULL,
    "scheduledAt" timestamp(3) without time zone,
    "publishedAt" timestamp(3) without time zone,
    status public."ContentStatus" DEFAULT 'DRAFT'::public."ContentStatus" NOT NULL,
    platforms public."ContentPlatform"[],
    "clientId" text,
    "projectId" text,
    "createdBy" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    caption text NOT NULL
);


ALTER TABLE public.content_calendar_items OWNER TO invoiceuser;

--
-- Name: COLUMN content_calendar_items.caption; Type: COMMENT; Schema: public; Owner: invoiceuser
--

COMMENT ON COLUMN public.content_calendar_items.caption IS 'Social media caption/post text (replaces title & description)';


--
-- Name: content_media; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.content_media (
    id text NOT NULL,
    url text NOT NULL,
    key text NOT NULL,
    type public."MediaType" NOT NULL,
    "mimeType" text NOT NULL,
    size integer NOT NULL,
    width integer,
    height integer,
    duration integer,
    "originalName" text,
    "contentId" text NOT NULL,
    "uploadedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "thumbnailKey" text,
    "thumbnailUrl" text,
    "order" integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.content_media OWNER TO invoiceuser;

--
-- Name: COLUMN content_media."order"; Type: COMMENT; Schema: public; Owner: invoiceuser
--

COMMENT ON COLUMN public.content_media."order" IS 'Carousel order (0 = first, 1 = second, etc.)';


--
-- Name: deferred_revenue; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.deferred_revenue (
    id text NOT NULL,
    "invoiceId" text NOT NULL,
    "paymentDate" timestamp(3) without time zone NOT NULL,
    "totalAmount" numeric(15,2) NOT NULL,
    "recognitionDate" timestamp(3) without time zone NOT NULL,
    "recognizedAmount" numeric(15,2) DEFAULT 0 NOT NULL,
    "remainingAmount" numeric(15,2) NOT NULL,
    status public."DeferredRevenueStatus" DEFAULT 'DEFERRED'::public."DeferredRevenueStatus" NOT NULL,
    "performanceObligation" text,
    "completionPercentage" numeric(5,2),
    "initialJournalId" text,
    "recognitionJournalId" text,
    "fiscalPeriodId" text,
    notes text,
    "notesId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" text,
    "recognizedAt" timestamp(3) without time zone,
    "recognizedBy" text
);


ALTER TABLE public.deferred_revenue OWNER TO invoiceuser;

--
-- Name: depreciation_entries; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.depreciation_entries (
    id text NOT NULL,
    "assetId" text NOT NULL,
    "scheduleId" text NOT NULL,
    "periodDate" timestamp(3) without time zone NOT NULL,
    "fiscalPeriodId" text,
    "depreciationAmount" numeric(15,2) NOT NULL,
    "accumulatedDepreciation" numeric(15,2) NOT NULL,
    "bookValue" numeric(15,2) NOT NULL,
    "journalEntryId" text,
    status public."DepreciationStatus" DEFAULT 'CALCULATED'::public."DepreciationStatus" NOT NULL,
    "calculatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "postedAt" timestamp(3) without time zone,
    "postedBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.depreciation_entries OWNER TO invoiceuser;

--
-- Name: depreciation_schedules; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.depreciation_schedules (
    id text NOT NULL,
    "assetId" text NOT NULL,
    method public."DepreciationMethod" NOT NULL,
    "depreciableAmount" numeric(15,2) NOT NULL,
    "residualValue" numeric(15,2) DEFAULT 0 NOT NULL,
    "usefulLifeMonths" integer NOT NULL,
    "usefulLifeYears" numeric(5,2) NOT NULL,
    "depreciationPerMonth" numeric(15,2) NOT NULL,
    "depreciationPerYear" numeric(15,2) NOT NULL,
    "annualRate" numeric(5,4) NOT NULL,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "isFulfilled" boolean DEFAULT false NOT NULL,
    notes text,
    "notesId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.depreciation_schedules OWNER TO invoiceuser;

--
-- Name: documents; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.documents (
    id text NOT NULL,
    "fileName" text NOT NULL,
    "originalFileName" text NOT NULL,
    "filePath" text NOT NULL,
    "fileSize" integer NOT NULL,
    "mimeType" text NOT NULL,
    category public."DocumentCategory" DEFAULT 'OTHER'::public."DocumentCategory" NOT NULL,
    description text,
    "invoiceId" text,
    "quotationId" text,
    "projectId" text,
    "uploadedBy" text NOT NULL,
    "uploadedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.documents OWNER TO invoiceuser;

--
-- Name: exchange_rates; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.exchange_rates (
    id text NOT NULL,
    "fromCurrency" public."Currency" NOT NULL,
    "toCurrency" public."Currency" DEFAULT 'IDR'::public."Currency" NOT NULL,
    rate numeric(18,8) NOT NULL,
    "effectiveDate" timestamp(3) without time zone NOT NULL,
    "expiryDate" timestamp(3) without time zone,
    source text,
    "isAutomatic" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" text NOT NULL,
    "updatedBy" text
);


ALTER TABLE public.exchange_rates OWNER TO invoiceuser;

--
-- Name: expense_approval_history; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.expense_approval_history (
    id text NOT NULL,
    "expenseId" text NOT NULL,
    action public."ExpenseApprovalAction" NOT NULL,
    "actionBy" text NOT NULL,
    "previousStatus" public."ExpenseStatus" NOT NULL,
    "newStatus" public."ExpenseStatus" NOT NULL,
    comments text,
    "commentsId" text,
    "commentsEn" text,
    "actionDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.expense_approval_history OWNER TO invoiceuser;

--
-- Name: expense_budgets; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.expense_budgets (
    id text NOT NULL,
    name text NOT NULL,
    "nameId" text,
    description text,
    "descriptionId" text,
    "categoryId" text,
    "projectId" text,
    "userId" text,
    amount numeric(12,2) NOT NULL,
    period public."BudgetPeriod" NOT NULL,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone NOT NULL,
    spent numeric(12,2) DEFAULT 0 NOT NULL,
    remaining numeric(12,2) NOT NULL,
    "alertThreshold" integer DEFAULT 80 NOT NULL,
    "alertSent" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.expense_budgets OWNER TO invoiceuser;

--
-- Name: expense_categories; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.expense_categories (
    id text NOT NULL,
    code text NOT NULL,
    "accountCode" text NOT NULL,
    "expenseClass" public."ExpenseClass" NOT NULL,
    name text NOT NULL,
    "nameId" text NOT NULL,
    description text,
    "descriptionId" text,
    "parentId" text,
    "defaultPPNRate" numeric(5,4) DEFAULT 0.1200 NOT NULL,
    "isLuxuryGoods" boolean DEFAULT false NOT NULL,
    "withholdingTaxType" public."WithholdingTaxType" DEFAULT 'NONE'::public."WithholdingTaxType",
    "withholdingTaxRate" numeric(5,4),
    icon text,
    color text DEFAULT '#1890ff'::text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "isBillable" boolean DEFAULT false NOT NULL,
    "requiresReceipt" boolean DEFAULT true NOT NULL,
    "requiresEFaktur" boolean DEFAULT true NOT NULL,
    "approvalRequired" boolean DEFAULT true NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.expense_categories OWNER TO invoiceuser;

--
-- Name: expense_comments; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.expense_comments (
    id text NOT NULL,
    "expenseId" text NOT NULL,
    "userId" text NOT NULL,
    comment text NOT NULL,
    "commentId" text,
    "commentEn" text,
    "isInternal" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.expense_comments OWNER TO invoiceuser;

--
-- Name: expense_documents; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.expense_documents (
    id text NOT NULL,
    "fileName" text NOT NULL,
    "originalFileName" text NOT NULL,
    "filePath" text NOT NULL,
    "fileSize" integer NOT NULL,
    "mimeType" text NOT NULL,
    category public."ExpenseDocumentCategory" DEFAULT 'OTHER'::public."ExpenseDocumentCategory" NOT NULL,
    description text,
    "expenseId" text NOT NULL,
    "uploadedBy" text NOT NULL,
    "uploadedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.expense_documents OWNER TO invoiceuser;

--
-- Name: expenses; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.expenses (
    id text NOT NULL,
    "expenseNumber" text NOT NULL,
    "buktiPengeluaranNumber" text NOT NULL,
    "accountCode" text NOT NULL,
    "accountName" text NOT NULL,
    "accountNameEn" text,
    "expenseClass" public."ExpenseClass" NOT NULL,
    description text NOT NULL,
    "descriptionId" text,
    "descriptionEn" text,
    "ppnRate" numeric(5,4) DEFAULT 0.1200 NOT NULL,
    "ppnAmount" numeric(12,2) NOT NULL,
    "ppnCategory" public."PPNCategory" DEFAULT 'CREDITABLE'::public."PPNCategory" NOT NULL,
    "isLuxuryGoods" boolean DEFAULT false NOT NULL,
    "eFakturNSFP" text,
    "eFakturQRCode" text,
    "eFakturApprovalCode" text,
    "eFakturStatus" public."EFakturStatus" DEFAULT 'NOT_REQUIRED'::public."EFakturStatus" NOT NULL,
    "eFakturValidatedAt" timestamp(3) without time zone,
    "withholdingTaxType" public."WithholdingTaxType",
    "withholdingTaxRate" numeric(5,4),
    "withholdingTaxAmount" numeric(12,2),
    "buktiPotongNumber" text,
    "buktiPotongDate" timestamp(3) without time zone,
    "vendorName" text NOT NULL,
    "vendorNPWP" text,
    "vendorAddress" text,
    "vendorPhone" text,
    "vendorBank" text,
    "vendorAccountNo" text,
    "vendorAccountName" text,
    "grossAmount" numeric(12,2) NOT NULL,
    "withholdingAmount" numeric(12,2),
    "netAmount" numeric(12,2) NOT NULL,
    "totalAmount" numeric(12,2) NOT NULL,
    "expenseDate" timestamp(3) without time zone NOT NULL,
    currency text DEFAULT 'IDR'::text NOT NULL,
    "categoryId" text NOT NULL,
    tags text[],
    "isTaxDeductible" boolean DEFAULT true NOT NULL,
    "userId" text NOT NULL,
    "projectId" text,
    "clientId" text,
    "isBillable" boolean DEFAULT false NOT NULL,
    "billableAmount" numeric(12,2),
    "invoiceId" text,
    status public."ExpenseStatus" DEFAULT 'DRAFT'::public."ExpenseStatus" NOT NULL,
    "submittedAt" timestamp(3) without time zone,
    "approvedAt" timestamp(3) without time zone,
    "approvedBy" text,
    "rejectedAt" timestamp(3) without time zone,
    "rejectionReason" text,
    "paymentStatus" public."ExpensePaymentStatus" DEFAULT 'UNPAID'::public."ExpensePaymentStatus" NOT NULL,
    "paidAt" timestamp(3) without time zone,
    "paymentMethod" text,
    "paymentReference" text,
    "paymentId" text,
    "journalEntryId" text,
    "paymentJournalId" text,
    notes text,
    "notesId" text,
    "notesEn" text,
    "receiptNumber" text,
    "merchantName" text,
    location text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" text,
    "updatedBy" text,
    "purchaseType" public."PurchaseType" DEFAULT 'DIRECT'::public."PurchaseType" NOT NULL,
    "purchaseSource" public."PurchaseSource" DEFAULT 'MANUAL'::public."PurchaseSource" NOT NULL,
    "vendorId" text,
    "purchaseOrderId" text,
    "vendorInvoiceId" text,
    "accountsPayableId" text,
    "dueDate" timestamp(3) without time zone
);


ALTER TABLE public.expenses OWNER TO invoiceuser;

--
-- Name: feature_flag_events; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.feature_flag_events (
    id text NOT NULL,
    "flagId" text NOT NULL,
    "userId" text,
    "eventType" text NOT NULL,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.feature_flag_events OWNER TO invoiceuser;

--
-- Name: feature_flags; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.feature_flags (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    enabled boolean DEFAULT false NOT NULL,
    "globalEnabled" boolean DEFAULT false NOT NULL,
    "targetUsers" text[],
    "targetGroups" text[],
    rules jsonb,
    "expiresAt" timestamp(3) without time zone,
    "disabledReason" text,
    "disabledAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.feature_flags OWNER TO invoiceuser;

--
-- Name: financial_statements; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.financial_statements (
    id text NOT NULL,
    "statementType" public."StatementType" NOT NULL,
    "fiscalPeriodId" text NOT NULL,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone NOT NULL,
    data jsonb NOT NULL,
    "generatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "generatedBy" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.financial_statements OWNER TO invoiceuser;

--
-- Name: fiscal_periods; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.fiscal_periods (
    id text NOT NULL,
    name text NOT NULL,
    code text NOT NULL,
    "periodType" public."PeriodType" NOT NULL,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone NOT NULL,
    status public."PeriodStatus" DEFAULT 'OPEN'::public."PeriodStatus" NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "closedAt" timestamp(3) without time zone,
    "closedBy" text,
    "closingNotes" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.fiscal_periods OWNER TO invoiceuser;

--
-- Name: frame_comments; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.frame_comments (
    id text NOT NULL,
    "frameId" text NOT NULL,
    text text NOT NULL,
    x numeric(5,2),
    y numeric(5,2),
    "parentId" text,
    "authorId" text NOT NULL,
    mentions text[],
    resolved boolean DEFAULT false NOT NULL,
    "resolvedBy" text,
    "resolvedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.frame_comments OWNER TO invoiceuser;

--
-- Name: frame_drawings; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.frame_drawings (
    id text NOT NULL,
    "frameId" text NOT NULL,
    type public."DrawingType" NOT NULL,
    data jsonb NOT NULL,
    "createdBy" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.frame_drawings OWNER TO invoiceuser;

--
-- Name: general_ledger; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.general_ledger (
    id text NOT NULL,
    "accountId" text NOT NULL,
    "entryDate" timestamp(3) without time zone NOT NULL,
    "postingDate" timestamp(3) without time zone NOT NULL,
    "journalEntryId" text NOT NULL,
    "journalEntryNumber" text NOT NULL,
    "lineNumber" integer NOT NULL,
    debit numeric(15,2) DEFAULT 0 NOT NULL,
    credit numeric(15,2) DEFAULT 0 NOT NULL,
    balance numeric(15,2) NOT NULL,
    description text NOT NULL,
    "descriptionId" text,
    "transactionType" public."TransactionType" NOT NULL,
    "transactionId" text NOT NULL,
    "documentNumber" text,
    "projectId" text,
    "clientId" text,
    "fiscalPeriodId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.general_ledger OWNER TO invoiceuser;

--
-- Name: goods_receipt_items; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.goods_receipt_items (
    id text NOT NULL,
    "grId" text NOT NULL,
    "poItemId" text NOT NULL,
    "lineNumber" integer NOT NULL,
    "orderedQuantity" numeric(15,3) NOT NULL,
    "receivedQuantity" numeric(15,3) NOT NULL,
    "acceptedQuantity" numeric(15,3) NOT NULL,
    "rejectedQuantity" numeric(15,3) DEFAULT 0 NOT NULL,
    "qualityStatus" public."QualityStatus" DEFAULT 'PENDING'::public."QualityStatus" NOT NULL,
    "rejectionReason" text,
    "unitPrice" numeric(15,2) NOT NULL,
    "lineTotal" numeric(15,2) NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.goods_receipt_items OWNER TO invoiceuser;

--
-- Name: goods_receipts; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.goods_receipts (
    id text NOT NULL,
    "grNumber" text NOT NULL,
    "grDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "poId" text NOT NULL,
    "vendorId" text NOT NULL,
    "deliveryNoteNumber" text,
    "receivedBy" text NOT NULL,
    "receivedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "warehouseLocation" text,
    "inspectionStatus" public."InspectionStatus" DEFAULT 'PENDING'::public."InspectionStatus" NOT NULL,
    "inspectedBy" text,
    "inspectedAt" timestamp(3) without time zone,
    "inspectionNotes" text,
    status public."GRStatus" DEFAULT 'DRAFT'::public."GRStatus" NOT NULL,
    "isPosted" boolean DEFAULT false NOT NULL,
    "postedAt" timestamp(3) without time zone,
    notes text,
    "notesId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" text NOT NULL,
    "updatedBy" text,
    "journalEntryId" text
);


ALTER TABLE public.goods_receipts OWNER TO invoiceuser;

--
-- Name: indonesian_holidays; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.indonesian_holidays (
    id text NOT NULL,
    date date NOT NULL,
    year integer NOT NULL,
    name text NOT NULL,
    "nameIndonesian" text NOT NULL,
    description text,
    type public."HolidayType" DEFAULT 'NATIONAL'::public."HolidayType" NOT NULL,
    region text,
    "isLunarBased" boolean DEFAULT false NOT NULL,
    "isSubstitute" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.indonesian_holidays OWNER TO invoiceuser;

--
-- Name: invoice_counters; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.invoice_counters (
    id text NOT NULL,
    year integer NOT NULL,
    month integer NOT NULL,
    sequence integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.invoice_counters OWNER TO invoiceuser;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.invoices (
    id text NOT NULL,
    "invoiceNumber" text NOT NULL,
    "creationDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "dueDate" timestamp(3) without time zone NOT NULL,
    "quotationId" text,
    "clientId" text NOT NULL,
    "projectId" text NOT NULL,
    "amountPerProject" numeric(12,2) NOT NULL,
    "totalAmount" numeric(12,2) NOT NULL,
    "subtotalAmount" numeric(15,2),
    "taxRate" numeric(5,2),
    "taxAmount" numeric(15,2),
    "includeTax" boolean DEFAULT false NOT NULL,
    "scopeOfWork" text,
    "priceBreakdown" jsonb,
    "paymentInfo" text NOT NULL,
    "materaiRequired" boolean DEFAULT false NOT NULL,
    "materaiApplied" boolean DEFAULT false NOT NULL,
    "materaiAppliedAt" timestamp(3) without time zone,
    "materaiAppliedBy" text,
    "materaiAmount" numeric(12,2),
    terms text,
    signature text,
    status public."InvoiceStatus" DEFAULT 'DRAFT'::public."InvoiceStatus" NOT NULL,
    "createdBy" text NOT NULL,
    "markedPaidBy" text,
    "markedPaidAt" timestamp(3) without time zone,
    "journalEntryId" text,
    "paymentJournalId" text,
    "paymentMilestoneId" text,
    "projectMilestoneId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.invoices OWNER TO invoiceuser;

--
-- Name: journal_entries; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.journal_entries (
    id text NOT NULL,
    "entryNumber" text NOT NULL,
    "entryDate" timestamp(3) without time zone NOT NULL,
    "postingDate" timestamp(3) without time zone,
    description text NOT NULL,
    "descriptionId" text,
    "descriptionEn" text,
    "transactionType" public."TransactionType" NOT NULL,
    "transactionId" text NOT NULL,
    "documentNumber" text,
    "documentDate" timestamp(3) without time zone,
    status public."JournalStatus" DEFAULT 'DRAFT'::public."JournalStatus" NOT NULL,
    "isPosted" boolean DEFAULT false NOT NULL,
    "postedAt" timestamp(3) without time zone,
    "postedBy" text,
    "fiscalPeriodId" text,
    "isReversing" boolean DEFAULT false NOT NULL,
    "reversedEntryId" text,
    "createdBy" text NOT NULL,
    "updatedBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.journal_entries OWNER TO invoiceuser;

--
-- Name: journal_line_items; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.journal_line_items (
    id text NOT NULL,
    "journalEntryId" text NOT NULL,
    "lineNumber" integer NOT NULL,
    "accountId" text NOT NULL,
    debit numeric(15,2) DEFAULT 0 NOT NULL,
    credit numeric(15,2) DEFAULT 0 NOT NULL,
    description text,
    "descriptionId" text,
    "projectId" text,
    "clientId" text,
    "departmentId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.journal_line_items OWNER TO invoiceuser;

--
-- Name: labor_entries; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.labor_entries (
    id text NOT NULL,
    "projectId" text NOT NULL,
    "teamMemberId" text NOT NULL,
    "userId" text NOT NULL,
    "workDate" date NOT NULL,
    "hoursWorked" numeric(5,2) NOT NULL,
    "laborType" public."LaborType" DEFAULT 'REGULAR'::public."LaborType" NOT NULL,
    "laborTypeRate" numeric(3,2) NOT NULL,
    "hourlyRate" numeric(12,2) NOT NULL,
    "laborCost" numeric(15,2) NOT NULL,
    "costType" public."CostType" DEFAULT 'LABOR'::public."CostType" NOT NULL,
    "isDirect" boolean DEFAULT true NOT NULL,
    description text,
    "descriptionId" text,
    "taskPerformed" text,
    status public."LaborEntryStatus" DEFAULT 'DRAFT'::public."LaborEntryStatus" NOT NULL,
    "submittedAt" timestamp(3) without time zone,
    "approvedBy" text,
    "approvedAt" timestamp(3) without time zone,
    "rejectedReason" text,
    "expenseId" text,
    "journalEntryId" text,
    "costAllocationId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" text,
    "updatedBy" text
);


ALTER TABLE public.labor_entries OWNER TO invoiceuser;

--
-- Name: maintenance_records; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.maintenance_records (
    id text NOT NULL,
    "assetId" text NOT NULL,
    "maintenanceType" text NOT NULL,
    "performedDate" timestamp(3) without time zone NOT NULL,
    "performedBy" text,
    cost numeric(15,2),
    description text NOT NULL,
    "partsReplaced" jsonb,
    "nextMaintenanceDate" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.maintenance_records OWNER TO invoiceuser;

--
-- Name: maintenance_schedules; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.maintenance_schedules (
    id text NOT NULL,
    "assetId" text NOT NULL,
    "maintenanceType" text NOT NULL,
    frequency public."MaintenanceFrequency" NOT NULL,
    "lastMaintenanceDate" timestamp(3) without time zone,
    "nextMaintenanceDate" timestamp(3) without time zone NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.maintenance_schedules OWNER TO invoiceuser;

--
-- Name: media_assets; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.media_assets (
    id text NOT NULL,
    "projectId" text NOT NULL,
    filename text NOT NULL,
    "originalName" text NOT NULL,
    description text,
    url text NOT NULL,
    key text NOT NULL,
    "thumbnailUrl" text,
    "mediaType" public."MediaAssetType" NOT NULL,
    "mimeType" text NOT NULL,
    size bigint NOT NULL,
    duration numeric(10,3),
    fps numeric(6,2),
    codec text,
    bitrate integer,
    width integer,
    height integer,
    status public."MediaReviewStatus" DEFAULT 'DRAFT'::public."MediaReviewStatus" NOT NULL,
    "starRating" integer,
    "uploadedBy" text NOT NULL,
    "uploadedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "folderId" text
);


ALTER TABLE public.media_assets OWNER TO invoiceuser;

--
-- Name: media_collaborators; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.media_collaborators (
    id text NOT NULL,
    "projectId" text NOT NULL,
    "userId" text,
    role public."CollaboratorRole" DEFAULT 'VIEWER'::public."CollaboratorRole" NOT NULL,
    "invitedBy" text NOT NULL,
    "addedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "guestEmail" text,
    "guestName" text,
    "inviteToken" text,
    status public."InviteStatus" DEFAULT 'PENDING'::public."InviteStatus" NOT NULL,
    "lastAccessAt" timestamp(3) without time zone,
    "expiresAt" timestamp(3) without time zone,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.media_collaborators OWNER TO invoiceuser;

--
-- Name: media_folders; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.media_folders (
    id text NOT NULL,
    name text NOT NULL,
    "parentId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdById" text NOT NULL,
    description text,
    "projectId" text NOT NULL
);


ALTER TABLE public.media_folders OWNER TO invoiceuser;

--
-- Name: media_frames; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.media_frames (
    id text NOT NULL,
    "assetId" text NOT NULL,
    "timestamp" numeric(10,3),
    "frameNumber" integer,
    x numeric(5,2),
    y numeric(5,2),
    "thumbnailUrl" text,
    "createdBy" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.media_frames OWNER TO invoiceuser;

--
-- Name: media_projects; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.media_projects (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "clientId" text,
    "projectId" text,
    "folderId" text,
    "createdBy" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "isPublic" boolean DEFAULT false NOT NULL,
    "publicShareToken" text,
    "publicShareUrl" text,
    "publicViewCount" integer DEFAULT 0 NOT NULL,
    "publicSharedAt" timestamp(3) without time zone,
    "publicAccessLevel" public."PublicAccessLevel" DEFAULT 'VIEW_ONLY'::public."PublicAccessLevel" NOT NULL
);


ALTER TABLE public.media_projects OWNER TO invoiceuser;

--
-- Name: media_versions; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.media_versions (
    id text NOT NULL,
    "assetId" text NOT NULL,
    "versionNumber" integer NOT NULL,
    filename text NOT NULL,
    url text NOT NULL,
    key text NOT NULL,
    "thumbnailUrl" text,
    size bigint NOT NULL,
    duration numeric(10,3),
    width integer,
    height integer,
    "changeNotes" text,
    "uploadedBy" text NOT NULL,
    "uploadedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.media_versions OWNER TO invoiceuser;

--
-- Name: payment_milestones; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.payment_milestones (
    id text NOT NULL,
    "quotationId" text NOT NULL,
    "milestoneNumber" integer NOT NULL,
    name text NOT NULL,
    "nameId" text,
    description text,
    "descriptionId" text,
    "paymentPercentage" numeric(5,2) NOT NULL,
    "paymentAmount" numeric(12,2) NOT NULL,
    "dueDate" timestamp(3) without time zone,
    "dueDaysFromPrev" integer,
    deliverables jsonb,
    "isInvoiced" boolean DEFAULT false NOT NULL,
    "projectMilestoneId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.payment_milestones OWNER TO invoiceuser;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.payments (
    id text NOT NULL,
    "invoiceId" text NOT NULL,
    amount numeric(12,2) NOT NULL,
    "paymentDate" timestamp(3) without time zone NOT NULL,
    "paymentMethod" public."PaymentMethod" NOT NULL,
    "transactionRef" text,
    "bankDetails" text,
    status public."PaymentStatus" DEFAULT 'PENDING'::public."PaymentStatus" NOT NULL,
    "confirmedAt" timestamp(3) without time zone,
    "journalEntryId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.payments OWNER TO invoiceuser;

--
-- Name: project_cost_allocations; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.project_cost_allocations (
    id text NOT NULL,
    "projectId" text NOT NULL,
    "expenseId" text NOT NULL,
    "allocationDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "allocationMethod" public."AllocationMethod" NOT NULL,
    "allocationPercentage" numeric(5,2),
    "allocatedAmount" numeric(15,2) NOT NULL,
    "journalEntryId" text,
    "costType" public."CostType" NOT NULL,
    "isDirect" boolean DEFAULT true NOT NULL,
    notes text,
    "notesId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" text
);


ALTER TABLE public.project_cost_allocations OWNER TO invoiceuser;

--
-- Name: project_equipment_usage; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.project_equipment_usage (
    id text NOT NULL,
    "projectId" text,
    "assetId" text NOT NULL,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone,
    "returnDate" timestamp(3) without time zone,
    condition text,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.project_equipment_usage OWNER TO invoiceuser;

--
-- Name: project_milestones; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.project_milestones (
    id text NOT NULL,
    "projectId" text NOT NULL,
    "milestoneNumber" integer NOT NULL,
    name text NOT NULL,
    "nameId" text,
    description text,
    "descriptionId" text,
    "plannedStartDate" timestamp(3) without time zone,
    "plannedEndDate" timestamp(3) without time zone,
    "actualStartDate" timestamp(3) without time zone,
    "actualEndDate" timestamp(3) without time zone,
    "completionPercentage" numeric(5,2) DEFAULT 0 NOT NULL,
    "plannedRevenue" numeric(15,2) NOT NULL,
    "recognizedRevenue" numeric(15,2) DEFAULT 0 NOT NULL,
    "remainingRevenue" numeric(15,2) NOT NULL,
    "estimatedCost" numeric(15,2),
    "actualCost" numeric(15,2) DEFAULT 0,
    status public."MilestoneStatus" DEFAULT 'PENDING'::public."MilestoneStatus" NOT NULL,
    deliverables jsonb,
    "acceptedBy" text,
    "acceptedAt" timestamp(3) without time zone,
    "journalEntryId" text,
    notes text,
    "notesId" text,
    priority public."MilestonePriority" DEFAULT 'MEDIUM'::public."MilestonePriority" NOT NULL,
    "predecessorId" text,
    "delayDays" integer DEFAULT 0,
    "delayReason" text,
    "materaiRequired" boolean DEFAULT false NOT NULL,
    "taxTreatment" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" text
);


ALTER TABLE public.project_milestones OWNER TO invoiceuser;

--
-- Name: project_team_members; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.project_team_members (
    id text NOT NULL,
    "projectId" text NOT NULL,
    "userId" text NOT NULL,
    role text NOT NULL,
    "roleId" text,
    "allocationPercent" numeric(5,2) DEFAULT 100 NOT NULL,
    "hourlyRate" numeric(12,2) NOT NULL,
    "hourlyRateCurrency" text DEFAULT 'IDR'::text NOT NULL,
    "assignedDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    notes text,
    "notesId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" text,
    "updatedBy" text
);


ALTER TABLE public.project_team_members OWNER TO invoiceuser;

--
-- Name: project_type_configs; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.project_type_configs (
    id text NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    description text,
    prefix text NOT NULL,
    color text DEFAULT '#1890ff'::text NOT NULL,
    "isDefault" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.project_type_configs OWNER TO invoiceuser;

--
-- Name: projects; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.projects (
    id text NOT NULL,
    number text NOT NULL,
    description text NOT NULL,
    "scopeOfWork" text,
    output text NOT NULL,
    "projectTypeId" text NOT NULL,
    "clientId" text NOT NULL,
    "startDate" timestamp(3) without time zone,
    "endDate" timestamp(3) without time zone,
    "estimatedBudget" numeric(12,2),
    "basePrice" numeric(12,2),
    "priceBreakdown" jsonb,
    "estimatedExpenses" jsonb,
    "projectedGrossMargin" numeric(5,2),
    "projectedNetMargin" numeric(5,2),
    "projectedProfit" numeric(15,2),
    "totalDirectCosts" numeric(15,2) DEFAULT 0,
    "totalIndirectCosts" numeric(15,2) DEFAULT 0,
    "totalAllocatedCosts" numeric(15,2) DEFAULT 0,
    "totalInvoicedAmount" numeric(15,2) DEFAULT 0,
    "totalPaidAmount" numeric(15,2) DEFAULT 0,
    "grossProfit" numeric(15,2),
    "netProfit" numeric(15,2),
    "grossMarginPercent" numeric(5,2),
    "netMarginPercent" numeric(5,2),
    "budgetVariance" numeric(15,2),
    "budgetVariancePercent" numeric(5,2),
    "profitCalculatedAt" timestamp(3) without time zone,
    "profitCalculatedBy" text,
    status public."ProjectStatus" DEFAULT 'PLANNING'::public."ProjectStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.projects OWNER TO invoiceuser;

--
-- Name: purchase_order_items; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.purchase_order_items (
    id text NOT NULL,
    "poId" text NOT NULL,
    "lineNumber" integer NOT NULL,
    "itemType" public."POItemType" NOT NULL,
    "itemCode" text,
    description text NOT NULL,
    "descriptionId" text,
    quantity numeric(15,3) NOT NULL,
    unit text NOT NULL,
    "unitPrice" numeric(15,2) NOT NULL,
    "discountPercent" numeric(5,2) DEFAULT 0 NOT NULL,
    "discountAmount" numeric(15,2) DEFAULT 0 NOT NULL,
    "lineTotal" numeric(15,2) NOT NULL,
    "ppnAmount" numeric(15,2) NOT NULL,
    "quantityReceived" numeric(15,3) DEFAULT 0 NOT NULL,
    "quantityInvoiced" numeric(15,3) DEFAULT 0 NOT NULL,
    "quantityOutstanding" numeric(15,3) NOT NULL,
    "assetId" text,
    "expenseCategoryId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.purchase_order_items OWNER TO invoiceuser;

--
-- Name: purchase_orders; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.purchase_orders (
    id text NOT NULL,
    "poNumber" text NOT NULL,
    "poDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "vendorId" text NOT NULL,
    "projectId" text,
    subtotal numeric(15,2) NOT NULL,
    "discountAmount" numeric(15,2) DEFAULT 0 NOT NULL,
    "ppnAmount" numeric(15,2) NOT NULL,
    "pphAmount" numeric(15,2) DEFAULT 0 NOT NULL,
    "totalAmount" numeric(15,2) NOT NULL,
    "isPPNIncluded" boolean DEFAULT true NOT NULL,
    "ppnRate" numeric(5,2) DEFAULT 12 NOT NULL,
    "withholdingTaxType" public."WithholdingTaxType" DEFAULT 'NONE'::public."WithholdingTaxType" NOT NULL,
    "withholdingTaxRate" numeric(5,2),
    "deliveryAddress" text,
    "deliveryDate" timestamp(3) without time zone,
    "paymentTerms" text DEFAULT 'NET 30'::text NOT NULL,
    "dueDate" timestamp(3) without time zone,
    status public."POStatus" DEFAULT 'DRAFT'::public."POStatus" NOT NULL,
    "approvalStatus" public."ApprovalStatus" DEFAULT 'PENDING'::public."ApprovalStatus" NOT NULL,
    "requestedBy" text NOT NULL,
    "approvedBy" text,
    "approvedAt" timestamp(3) without time zone,
    "rejectedBy" text,
    "rejectedAt" timestamp(3) without time zone,
    "rejectionReason" text,
    "totalReceived" numeric(15,2) DEFAULT 0 NOT NULL,
    "totalInvoiced" numeric(15,2) DEFAULT 0 NOT NULL,
    "isClosed" boolean DEFAULT false NOT NULL,
    "closedAt" timestamp(3) without time zone,
    "closedBy" text,
    "closureReason" text,
    description text,
    "descriptionId" text,
    notes text,
    "termsConditions" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" text NOT NULL,
    "updatedBy" text,
    "journalEntryId" text
);


ALTER TABLE public.purchase_orders OWNER TO invoiceuser;

--
-- Name: quotation_counters; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.quotation_counters (
    id text NOT NULL,
    year integer NOT NULL,
    month integer NOT NULL,
    sequence integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.quotation_counters OWNER TO invoiceuser;

--
-- Name: quotations; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.quotations (
    id text NOT NULL,
    "quotationNumber" text NOT NULL,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "validUntil" timestamp(3) without time zone NOT NULL,
    "clientId" text NOT NULL,
    "projectId" text NOT NULL,
    "amountPerProject" numeric(12,2) NOT NULL,
    "totalAmount" numeric(12,2) NOT NULL,
    "scopeOfWork" text,
    "priceBreakdown" jsonb,
    terms text,
    "paymentType" public."PaymentType" DEFAULT 'FULL_PAYMENT'::public."PaymentType" NOT NULL,
    "paymentTermsText" text,
    status public."QuotationStatus" DEFAULT 'DRAFT'::public."QuotationStatus" NOT NULL,
    "createdBy" text NOT NULL,
    "approvedBy" text,
    "approvedAt" timestamp(3) without time zone,
    "rejectedBy" text,
    "rejectedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.quotations OWNER TO invoiceuser;

--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.refresh_tokens (
    id text NOT NULL,
    token text NOT NULL,
    "userId" text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "lastUsedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "isRevoked" boolean DEFAULT false NOT NULL,
    "revokedAt" timestamp(3) without time zone,
    "revokedReason" text,
    "userAgent" text,
    "ipAddress" text,
    "deviceId" text,
    "replacedBy" text
);


ALTER TABLE public.refresh_tokens OWNER TO invoiceuser;

--
-- Name: report_sections; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.report_sections (
    id text NOT NULL,
    "reportId" text NOT NULL,
    "order" integer NOT NULL,
    title text NOT NULL,
    description text,
    "csvFileName" text NOT NULL,
    "csvFilePath" text,
    "importedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "columnTypes" jsonb NOT NULL,
    "rawData" jsonb NOT NULL,
    "rowCount" integer NOT NULL,
    visualizations jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    layout jsonb,
    "layoutVersion" integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.report_sections OWNER TO invoiceuser;

--
-- Name: COLUMN report_sections.layout; Type: COMMENT; Schema: public; Owner: invoiceuser
--

COMMENT ON COLUMN public.report_sections.layout IS 'Widget-based layout for visual report builder';


--
-- Name: COLUMN report_sections."layoutVersion"; Type: COMMENT; Schema: public; Owner: invoiceuser
--

COMMENT ON COLUMN public.report_sections."layoutVersion" IS 'Track layout schema version';


--
-- Name: social_media_reports; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.social_media_reports (
    id text NOT NULL,
    "projectId" text NOT NULL,
    title text NOT NULL,
    description text,
    month integer NOT NULL,
    year integer NOT NULL,
    status public."ReportStatus" DEFAULT 'DRAFT'::public."ReportStatus" NOT NULL,
    "pdfUrl" text,
    "pdfGeneratedAt" timestamp(3) without time zone,
    "pdfVersion" integer DEFAULT 1 NOT NULL,
    "emailedAt" timestamp(3) without time zone,
    "emailedTo" text[],
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" text,
    "updatedBy" text
);


ALTER TABLE public.social_media_reports OWNER TO invoiceuser;

--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.system_settings (
    id text DEFAULT 'default'::text NOT NULL,
    "defaultPaymentTerms" text DEFAULT 'NET 30'::text NOT NULL,
    "materaiThreshold" integer DEFAULT 5000000 NOT NULL,
    "invoicePrefix" text DEFAULT 'INV-'::text NOT NULL,
    "quotationPrefix" text DEFAULT 'QT-'::text NOT NULL,
    "autoBackup" boolean DEFAULT true NOT NULL,
    "backupFrequency" text DEFAULT 'daily'::text NOT NULL,
    "backupTime" text DEFAULT '02:00'::text NOT NULL,
    "autoMateraiReminder" boolean DEFAULT true NOT NULL,
    "defaultCurrency" text DEFAULT 'IDR'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.system_settings OWNER TO invoiceuser;

--
-- Name: user_preferences; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.user_preferences (
    id text NOT NULL,
    "userId" text NOT NULL,
    timezone text DEFAULT 'Asia/Jakarta'::text NOT NULL,
    language text DEFAULT 'id-ID'::text NOT NULL,
    currency text DEFAULT 'IDR'::text NOT NULL,
    "emailNotifications" boolean DEFAULT true NOT NULL,
    "pushNotifications" boolean DEFAULT true NOT NULL,
    theme text DEFAULT 'light'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.user_preferences OWNER TO invoiceuser;

--
-- Name: users; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.users (
    id text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    name text NOT NULL,
    role public."UserRole" DEFAULT 'STAFF'::public."UserRole" NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO invoiceuser;

--
-- Name: ux_metrics; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.ux_metrics (
    id text NOT NULL,
    "componentName" text NOT NULL,
    "eventType" text NOT NULL,
    "metricName" text NOT NULL,
    value double precision NOT NULL,
    "userId" text,
    "sessionId" text,
    "clientId" text,
    url text,
    "userAgent" text,
    "performanceData" jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.ux_metrics OWNER TO invoiceuser;

--
-- Name: vendor_invoice_items; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.vendor_invoice_items (
    id text NOT NULL,
    "viId" text NOT NULL,
    "poItemId" text,
    "lineNumber" integer NOT NULL,
    description text NOT NULL,
    "descriptionId" text,
    quantity numeric(15,3) NOT NULL,
    unit text NOT NULL,
    "unitPrice" numeric(15,2) NOT NULL,
    "discountAmount" numeric(15,2) DEFAULT 0 NOT NULL,
    "lineTotal" numeric(15,2) NOT NULL,
    "ppnAmount" numeric(15,2) NOT NULL,
    "isMatched" boolean DEFAULT false NOT NULL,
    "varianceReason" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.vendor_invoice_items OWNER TO invoiceuser;

--
-- Name: vendor_invoices; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.vendor_invoices (
    id text NOT NULL,
    "vendorInvoiceNumber" text NOT NULL,
    "internalNumber" text NOT NULL,
    "invoiceDate" timestamp(3) without time zone NOT NULL,
    "vendorId" text NOT NULL,
    "poId" text,
    "grId" text,
    subtotal numeric(15,2) NOT NULL,
    "discountAmount" numeric(15,2) DEFAULT 0 NOT NULL,
    "ppnAmount" numeric(15,2) NOT NULL,
    "pphAmount" numeric(15,2) DEFAULT 0 NOT NULL,
    "totalAmount" numeric(15,2) NOT NULL,
    "eFakturNSFP" text,
    "eFakturQRCode" text,
    "eFakturStatus" public."EFakturStatus" DEFAULT 'NOT_REQUIRED'::public."EFakturStatus" NOT NULL,
    "eFakturUploadDate" timestamp(3) without time zone,
    "paymentTerms" text NOT NULL,
    "dueDate" timestamp(3) without time zone NOT NULL,
    "matchingStatus" public."MatchingStatus" DEFAULT 'UNMATCHED'::public."MatchingStatus" NOT NULL,
    "matchedBy" text,
    "matchedAt" timestamp(3) without time zone,
    "matchingNotes" text,
    "priceVariance" numeric(15,2),
    "quantityVariance" numeric(15,3),
    "withinTolerance" boolean DEFAULT false NOT NULL,
    status public."VIStatus" DEFAULT 'DRAFT'::public."VIStatus" NOT NULL,
    "approvalStatus" public."ApprovalStatus" DEFAULT 'PENDING'::public."ApprovalStatus" NOT NULL,
    "approvedBy" text,
    "approvedAt" timestamp(3) without time zone,
    "rejectedBy" text,
    "rejectedAt" timestamp(3) without time zone,
    "rejectionReason" text,
    "accountsPayableId" text,
    "journalEntryId" text,
    description text,
    "descriptionId" text,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" text NOT NULL,
    "updatedBy" text
);


ALTER TABLE public.vendor_invoices OWNER TO invoiceuser;

--
-- Name: vendor_payment_allocations; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.vendor_payment_allocations (
    id text NOT NULL,
    "paymentId" text NOT NULL,
    "apId" text NOT NULL,
    "allocatedAmount" numeric(15,2) NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.vendor_payment_allocations OWNER TO invoiceuser;

--
-- Name: vendor_payments; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.vendor_payments (
    id text NOT NULL,
    "paymentNumber" text NOT NULL,
    "paymentDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "vendorId" text NOT NULL,
    "paymentMethod" public."PaymentMethod" NOT NULL,
    "referenceNumber" text,
    "bankAccountId" text,
    "totalAmount" numeric(15,2) NOT NULL,
    status public."VendorPaymentStatus" DEFAULT 'DRAFT'::public."VendorPaymentStatus" NOT NULL,
    "clearedAt" timestamp(3) without time zone,
    "journalEntryId" text,
    notes text,
    "notesId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" text NOT NULL,
    "updatedBy" text
);


ALTER TABLE public.vendor_payments OWNER TO invoiceuser;

--
-- Name: vendors; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.vendors (
    id text NOT NULL,
    "vendorCode" text NOT NULL,
    name text NOT NULL,
    "nameId" text,
    "vendorType" public."VendorType" NOT NULL,
    "industryType" text,
    "contactPerson" text,
    email text,
    phone text,
    address text,
    city text,
    province text,
    "postalCode" text,
    country text DEFAULT 'Indonesia'::text NOT NULL,
    npwp text,
    "pkpStatus" public."PKPStatus" DEFAULT 'NON_PKP'::public."PKPStatus" NOT NULL,
    "taxAddress" text,
    "bankName" text,
    "bankAccountNumber" text,
    "bankAccountName" text,
    "bankBranch" text,
    "swiftCode" text,
    "paymentTerms" text DEFAULT 'NET 30'::text NOT NULL,
    "creditLimit" numeric(15,2),
    currency text DEFAULT 'IDR'::text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "isPKP" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" text NOT NULL,
    "updatedBy" text
);


ALTER TABLE public.vendors OWNER TO invoiceuser;

--
-- Name: work_in_progress; Type: TABLE; Schema: public; Owner: invoiceuser
--

CREATE TABLE public.work_in_progress (
    id text NOT NULL,
    "projectId" text NOT NULL,
    "periodDate" timestamp(3) without time zone NOT NULL,
    "fiscalPeriodId" text,
    "directMaterialCost" numeric(15,2) DEFAULT 0 NOT NULL,
    "directLaborCost" numeric(15,2) DEFAULT 0 NOT NULL,
    "directExpenses" numeric(15,2) DEFAULT 0 NOT NULL,
    "allocatedOverhead" numeric(15,2) DEFAULT 0 NOT NULL,
    "totalCost" numeric(15,2) DEFAULT 0 NOT NULL,
    "billedToDate" numeric(15,2) DEFAULT 0 NOT NULL,
    "recognizedRevenue" numeric(15,2) DEFAULT 0 NOT NULL,
    "unbilledRevenue" numeric(15,2) DEFAULT 0 NOT NULL,
    "completionPercentage" numeric(5,2) DEFAULT 0 NOT NULL,
    "isCompleted" boolean DEFAULT false NOT NULL,
    "costJournalId" text,
    "revenueJournalId" text,
    notes text,
    "notesId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" text
);


ALTER TABLE public.work_in_progress OWNER TO invoiceuser;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
c6c8b0de-120b-433d-bb6c-6a3dd98ef48f	75ea442230f60240eda51cc18008a21a16e0262ad0f8c5f22738c6d083af2ab6	2025-11-16 17:40:29.096716+00	20251111111000_add_asset_useful_life_years	\N	\N	2025-11-16 17:40:29.08292+00	1
fdf62a8f-e80e-41cf-b90b-72e7f920dcdb	70a0150d9e7685f2e55a4b05efe1665cd153b3ff4f920317345123395d63ff10	2025-11-16 17:40:28.228678+00	20251107173854_init_baseline	\N	\N	2025-11-16 17:40:23.704361+00	1
55f46817-cd18-4f46-be5a-845e2022ddc6	8f46bbd65151fbf9cf849b61b6cc66d1a22eb3418520d3e6beebb6eb666118ff	2025-11-16 17:40:28.280272+00	20251108060706_add_performance_indexes	\N	\N	2025-11-16 17:40:28.232412+00	1
495723cf-506a-499f-ae8e-eb82495ae2e0	95e6ad7aaceffe0ca9d70ef2bf9ae9c6ff3599d4671de220933e3af362843115	2025-11-17 09:10:32.702896+00	20251117091020_add_folders_to_media_assets	\N	\N	2025-11-17 09:10:32.672449+00	1
71a5f8d0-15aa-4127-9499-38461d1fcd0f	f41cd0f4d7078402e66e05b6e07a55b52e7bad16d7784aedd0ddcb826d34ab16	2025-11-16 17:40:28.307075+00	20251108061200_fix_milestone_invoice_race_condition	\N	\N	2025-11-16 17:40:28.283769+00	1
f0812048-c427-47da-a2e6-6d6473806b40	13603074c615243da91f72eda42decca1fcdc1de1555e5efe43612127eaf2fb9	2025-11-16 17:40:29.115136+00	20251111185555_add_video_thumbnails	\N	\N	2025-11-16 17:40:29.101252+00	1
cd57f80e-5429-4c75-b940-fd581c5ead92	f5fddc1a1521c7d29cf9a897b187d224526d6ae2bbd8141301886f5159a0fe1a	2025-11-16 17:40:28.707912+00	20251108094336_add_social_media_ads_reporting	\N	\N	2025-11-16 17:40:28.311158+00	1
7c8d6b42-ca41-40af-84ae-d3c994aeca7b	4e7bf067050beeea2a74f54687730f80d8c7a95c0b9645053f23dc5208b7d5b1	2025-11-16 17:40:28.726903+00	20251108095500_auto_expense_category_trigger	\N	\N	2025-11-16 17:40:28.711305+00	1
c5edd2dc-694b-4fab-99b4-1f959f2b8fc2	e7ec736f6a11a027478d66b09a1aa8008106e801e0883372c5cc8c2b282c99ee	2025-11-16 17:40:28.841261+00	20251108103500_add_content_planning_calendar	\N	\N	2025-11-16 17:40:28.730251+00	1
7a8534dd-6d3f-48a6-83af-fd347c997564	0c2173a5867589f749205d2ddcfe4b349f66e6947a873e1ced7d17b8e3f514ad	2025-11-16 17:40:29.14487+00	20251111200000_add_media_order_for_carousel	\N	\N	2025-11-16 17:40:29.118912+00	1
430045ce-94aa-45dd-9e91-3850a6688dbf	6fbba960d9630863d16761187fd4f9ea0d1e9bc36b907596526311b06f329666	2025-11-16 17:40:28.856088+00	20251108120000_add_tax_fields_to_quotations	\N	\N	2025-11-16 17:40:28.844447+00	1
4df30243-91de-4c43-9c39-941bb79dbba8	0bfc7c1d287c7e803aadad3d93fb60c0cd047b25c245d91892c73590adf75940	2025-11-16 17:40:28.93837+00	20251109140923_add_universal_social_media_reporting	\N	\N	2025-11-16 17:40:28.859875+00	1
9cf28b34-b553-4784-a70b-8ebae1cb9e79	088269ca1035c9c7911978bcc3e6daa9641343f8539417cf7e9fd39fff75ec81	2025-11-16 17:40:28.99215+00	20251109142637_remove_campaign_system	\N	\N	2025-11-16 17:40:28.941461+00	1
65c74f33-824d-4e9c-a4f3-b440b8bacb26	fc4fb46d1d762793f776d82975ba24f8b8127e7bb1fa57233cd58acae6ec9bae	2025-11-16 17:40:29.164562+00	20251111230000_replace_title_description_with_caption	\N	\N	2025-11-16 17:40:29.149193+00	1
5e0d15ea-5767-4935-84c7-03eb4430aea0	625059fb9411a78cb54b225cd6211c2056b16af3b10d00aae2b70ccb898dd889	2025-11-16 17:40:29.04618+00	20251109233000_add_cash_bank_balance_table	\N	\N	2025-11-16 17:40:28.995386+00	1
1a8ea71c-9102-4e32-877c-238b0d9da170	0e7138479282526d65d8a4746fcc1f1a39cd932150da8b10787f4babbc031a86	2025-11-16 17:40:29.061784+00	20251111100000_add_layout_and_default_values	\N	\N	2025-11-16 17:40:29.049495+00	1
b8c99561-069b-45c5-84cb-0d3d15a4932f	cc391b9582b8140ad22c5b89936d4cf70ae4cc8dbaca3d5fd7c73ad437fcbdf2	2025-11-18 13:00:58.3753+00	20251118130058_add_cascade_delete_to_payments	\N	\N	2025-11-18 13:00:58.355288+00	1
e103acad-8e4e-4053-a8d9-3ea106252512	46d4f4f346c21fe4ea021eb702e6bd612619b1e991f769324f066c16bf191350	2025-11-16 17:40:29.079108+00	20251111110000_fix_schema_defaults_and_nullables	\N	\N	2025-11-16 17:40:29.065507+00	1
3e36adca-b19a-4fc0-802b-2dc44b2b8acc	fe52def446f4b1919f5c53e50cff79b8bf9b8a2b5bff7c23c0722e1642f12f3f	2025-11-16 17:40:29.180517+00	20251116100000_add_client_tax_bank_notes_fields	\N	\N	2025-11-16 17:40:29.168032+00	1
77f120ef-21b2-4952-9ea2-e602fb6c5788	bc2ba684ed04f3a1060cd9e57111957aa5b541df4f4bb4fbddf2a151b5b6f3e4	2025-11-16 17:41:45.993338+00	20251116174120_add_cogs_to_expense_class_enum	\N	\N	2025-11-16 17:41:45.446367+00	1
2b68f7d6-8b64-4030-b6b1-cdee4a3e3626	9a3850bddc6fdfac834096a8ea1e95d1abbbbd5769ef783efdb9c22c113e0448	2025-11-20 14:46:18.31268+00	20251120144618_add_refresh_tokens	\N	\N	2025-11-20 14:46:18.23996+00	1
f1a8677e-c825-4605-965a-9862fb057f04	0af6ad1bd53f872e63ad9ac92de5ffe9e731245e45af7e482b1d6ae1e86563cd	2025-11-17 07:11:45.699159+00	20251117000000_add_guest_collaboration_support	\N	\N	2025-11-17 07:11:45.643703+00	1
15aacab5-5a34-4829-98db-9c3a8cb1c880	510b4c8a26b17f43f2069775b184335f2b7bedd564c682b35dfaccb87e1b7e6e	2025-11-17 07:28:20.960436+00	20251117000001_add_public_sharing_to_media_projects	\N	\N	2025-11-17 07:28:20.847914+00	1
\.


--
-- Data for Name: account_balances; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.account_balances (id, "accountId", "fiscalPeriodId", "beginningBalance", "debitTotal", "creditTotal", "endingBalance", "isClosed", "closedAt", "lastUpdated") FROM stdin;
\.


--
-- Data for Name: accounts_payable; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.accounts_payable (id, "apNumber", "vendorId", "sourceType", "vendorInvoiceId", "expenseId", "originalAmount", "paidAmount", "outstandingAmount", "invoiceDate", "dueDate", "paymentStatus", "daysOutstanding", "agingBucket", "journalEntryId", "createdAt", "updatedAt", "createdBy", "updatedBy") FROM stdin;
\.


--
-- Data for Name: allowance_for_doubtful_accounts; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.allowance_for_doubtful_accounts (id, "invoiceId", "calculationDate", "fiscalPeriodId", "agingBucket", "daysPastDue", "outstandingAmount", "eclRate", "eclAmount", "previousEclAmount", "adjustmentAmount", "eclModel", "lossRateSource", "provisionStatus", "journalEntryId", "writtenOffAt", "writtenOffBy", "writeOffReason", "writeOffAmount", "recoveredAt", "recoveredAmount", "recoveryJournalId", notes, "notesId", "createdAt", "updatedAt", "createdBy") FROM stdin;
\.


--
-- Data for Name: asset_kit_items; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.asset_kit_items (id, "kitId", "assetId", quantity) FROM stdin;
\.


--
-- Data for Name: asset_kits; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.asset_kits (id, name, description, "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: asset_metadata; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.asset_metadata (id, "assetId", "assigneeId", "dueDate", platforms, tags, "customFields", "cameraModel", "cameraMake", lens, iso, aperture, "shutterSpeed", "focalLength", "capturedAt", "gpsLatitude", "gpsLongitude", copyright, "createdAt", "updatedAt") FROM stdin;
cmi2cc8h7000398jkjlzvut6d	cmi2cc8gh000198jkv0d1jsi2	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-11-16 23:22:30.762	2025-11-16 23:22:30.762
\.


--
-- Data for Name: asset_reservations; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.asset_reservations (id, "assetId", "userId", "projectId", "startDate", "endDate", purpose, status, notes, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: assets; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.assets (id, "assetCode", name, category, subcategory, manufacturer, model, "serialNumber", specifications, "purchaseDate", "purchasePrice", supplier, "invoiceNumber", "warrantyExpiration", "currentValue", "notesFinancial", status, condition, location, photos, documents, "qrCode", "rfidTag", tags, notes, "createdAt", "updatedAt", "createdById", "vendorId", "purchaseOrderId", "goodsReceiptId", "vendorInvoiceId", "residualValue", "usefulLifeYears") FROM stdin;
cmi7jvriu0051ipqmui7oufmw	CAM-202501-001	Sony A7S III	Camera	Mirrorless	Sony	A7S III	SN-A7S3-12345	\N	2024-03-15 00:00:00	55000000.00	PT Kamera Pro Indonesia	\N	\N	\N	\N	AVAILABLE	EXCELLENT	Equipment Room A	\N	\N	\N	\N	\N	Kamera utama untuk produksi video 4K	2025-11-20 14:52:30.102	2025-11-20 14:52:30.102	cmi204j490000gecr55vtk127	\N	\N	\N	\N	\N	\N
cmi7jvriz0053ipqmjv3uq45b	CAM-202501-002	Canon EOS R5	Camera	Mirrorless	Canon	EOS R5	SN-R5-67890	\N	2024-05-10 00:00:00	65000000.00	PT Kamera Pro Indonesia	\N	\N	\N	\N	CHECKED_OUT	EXCELLENT	Out - Project SM-001	\N	\N	\N	\N	\N	Sedang digunakan untuk project social media	2025-11-20 14:52:30.108	2025-11-20 14:52:30.108	cmi204j490000gecr55vtk127	\N	\N	\N	\N	\N	\N
cmi7jvrj40055ipqm62099iu9	LEN-202501-001	Sony FE 24-70mm f/2.8 GM II	Lens	Zoom Lens	Sony	SEL2470GM2	SN-LENS-11111	\N	2024-03-15 00:00:00	32000000.00	PT Kamera Pro Indonesia	\N	\N	\N	\N	AVAILABLE	EXCELLENT	Equipment Room A	\N	\N	\N	\N	\N	Lensa zoom serbaguna untuk Sony A7S III	2025-11-20 14:52:30.112	2025-11-20 14:52:30.112	cmi204j490000gecr55vtk127	\N	\N	\N	\N	\N	\N
cmi7jvrj80057ipqm6wwg57l1	LEN-202501-002	Canon RF 70-200mm f/2.8L	Lens	Telephoto Lens	Canon	RF70200F28L	SN-LENS-22222	\N	2024-05-10 00:00:00	42000000.00	PT Kamera Pro Indonesia	\N	\N	\N	\N	AVAILABLE	GOOD	Equipment Room A	\N	\N	\N	\N	\N	Lensa telephoto untuk Canon R5	2025-11-20 14:52:30.116	2025-11-20 14:52:30.116	cmi204j490000gecr55vtk127	\N	\N	\N	\N	\N	\N
cmi7jvrjd0059ipqmdwgql24t	LIG-202501-001	Godox SL-60W LED Light	Lighting	LED Panel	Godox	SL-60W	SN-LIGHT-33333	\N	2024-06-20 00:00:00	3500000.00	Toko Lighting Jakarta	\N	\N	\N	\N	AVAILABLE	EXCELLENT	Studio B	\N	\N	\N	\N	\N	Lampu LED untuk studio photography	2025-11-20 14:52:30.121	2025-11-20 14:52:30.121	cmi204j490000gecr55vtk127	\N	\N	\N	\N	\N	\N
cmi7jvrjh005bipqmuash58tq	LIG-202501-002	Aputure 300D Mark II	Lighting	LED Light	Aputure	300D Mark II	SN-APU-44444	\N	2024-07-15 00:00:00	12000000.00	Toko Lighting Jakarta	\N	\N	\N	\N	IN_MAINTENANCE	FAIR	Maintenance Workshop	\N	\N	\N	\N	\N	Dalam perbaikan - mounting bracket rusak	2025-11-20 14:52:30.125	2025-11-20 14:52:30.125	cmi204j490000gecr55vtk127	\N	\N	\N	\N	\N	\N
cmi7jvrjm005dipqmali4sreh	AUD-202501-001	Rode VideoMic Pro Plus	Audio	Microphone	Rode	VideoMic Pro+	SN-RODE-55555	\N	2024-04-10 00:00:00	4500000.00	Audio Equipment Store	\N	\N	\N	\N	AVAILABLE	EXCELLENT	Equipment Room A	\N	\N	\N	\N	\N	Microphone shotgun untuk video production	2025-11-20 14:52:30.13	2025-11-20 14:52:30.13	cmi204j490000gecr55vtk127	\N	\N	\N	\N	\N	\N
cmi7jvrjq005fipqmyk7rj1lh	COM-202501-001	MacBook Pro 16" M2 Max	Computer	Laptop	Apple	MacBook Pro 16 M2 Max	SN-MAC-66666	\N	2024-02-01 00:00:00	48000000.00	iStore Jakarta	\N	\N	\N	\N	RESERVED	EXCELLENT	Editor Desk 1	\N	\N	\N	\N	\N	Reserved untuk video editing project besar	2025-11-20 14:52:30.134	2025-11-20 14:52:30.134	cmi204j490000gecr55vtk127	\N	\N	\N	\N	\N	\N
cmi7jvrju005hipqmguy57oko	ACC-202501-001	DJI Ronin RSC 2	Accessories	Gimbal	DJI	Ronin RSC 2	SN-DJI-77777	\N	2024-08-05 00:00:00	8500000.00	DJI Store Jakarta	\N	\N	\N	\N	AVAILABLE	GOOD	Equipment Room B	\N	\N	\N	\N	\N	Gimbal 3-axis untuk camera mirrorless	2025-11-20 14:52:30.138	2025-11-20 14:52:30.138	cmi204j490000gecr55vtk127	\N	\N	\N	\N	\N	\N
cmi7jvrjy005jipqmkce80t2b	ACC-202501-002	Manfrotto MT055XPRO3 Tripod	Accessories	Tripod	Manfrotto	MT055XPRO3	SN-MAN-88888	\N	2024-01-20 00:00:00	6500000.00	Photography Equipment Store	\N	\N	\N	\N	AVAILABLE	EXCELLENT	Equipment Room A	\N	\N	\N	\N	\N	Tripod aluminum professional untuk camera berat	2025-11-20 14:52:30.142	2025-11-20 14:52:30.142	cmi204j490000gecr55vtk127	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.audit_logs (id, action, "entityType", "entityId", "oldValues", "newValues", "userId", "ipAddress", "userAgent", "createdAt") FROM stdin;
cmi7jvrir004wipqmf5kdxx6n	CREATE	quotation	quotation-1	\N	{"status": "DRAFT", "totalAmount": 75000000.0, "quotationNumber": "QT-202501-001"}	cmi204j490000gecr55vtk127	127.0.0.1	Seed Script	2025-11-20 14:52:30.099
cmi7jvrir004xipqmakdic1mv	UPDATE	quotation	quotation-1	{"status": "DRAFT"}	{"status": "APPROVED"}	cmi204j490000gecr55vtk127	127.0.0.1	Seed Script	2025-11-20 14:52:30.099
cmi7jvrir004yipqmoqyrv67h	CREATE	invoice	invoice-1	\N	{"status": "DRAFT", "totalAmount": 75000000.0, "invoiceNumber": "INV-202501-001"}	cmi204j490000gecr55vtk127	127.0.0.1	Seed Script	2025-11-20 14:52:30.099
cmi7jvrir004zipqmt3k5dpr9	UPDATE	invoice	invoice-2	{"status": "SENT"}	{"status": "PAID"}	cmi204j490000gecr55vtk127	127.0.0.1	Seed Script	2025-11-20 14:52:30.099
\.


--
-- Data for Name: bank_reconciliation_items; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.bank_reconciliation_items (id, "reconciliationId", "itemDate", "itemType", description, "descriptionId", amount, "isMatched", "matchedTransactionId", "matchedAt", "matchedBy", status, "requiresAdjustment", "adjustmentJournalId", "adjustedAt", "checkNumber", reference, "createdAt", "updatedAt", "createdBy", notes) FROM stdin;
\.


--
-- Data for Name: bank_reconciliations; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.bank_reconciliations (id, "reconciliationNumber", "bankAccountId", "statementDate", "periodStartDate", "periodEndDate", "bookBalanceStart", "bookBalanceEnd", "statementBalance", "depositsInTransit", "outstandingChecks", "bankCharges", "bankInterest", "otherAdjustments", "adjustedBookBalance", "adjustedBankBalance", difference, "isBalanced", "statementReference", "statementFilePath", status, "reviewedBy", "reviewedAt", "approvedBy", "approvedAt", "rejectedBy", "rejectedAt", "rejectionReason", "adjustmentJournalId", "createdAt", "updatedAt", "createdBy", "updatedBy", notes, "notesId") FROM stdin;
\.


--
-- Data for Name: bank_transfers; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.bank_transfers (id, "transferNumber", "transferDate", amount, currency, "originalAmount", "exchangeRate", "idrAmount", "fromAccountId", "toAccountId", description, "descriptionId", "descriptionEn", reference, "transferFee", "feeAccountId", "feePaymentMethod", "transferMethod", "bankReference", "confirmationCode", "projectId", "clientId", "journalEntryId", status, "approvedBy", "approvedAt", "rejectedBy", "rejectedAt", "rejectionReason", "completedAt", "completedBy", "createdAt", "updatedAt", "createdBy", "updatedBy", notes, "notesId") FROM stdin;
\.


--
-- Data for Name: business_journey_event_metadata; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.business_journey_event_metadata (id, "eventId", "userCreated", "userModified", source, priority, tags, "relatedDocuments", notes, "ipAddress", "userAgent", "materaiRequired", "materaiAmount", "complianceStatus", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: business_journey_events; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.business_journey_events (id, type, title, description, status, amount, "clientId", "projectId", "quotationId", "invoiceId", "paymentId", "createdBy", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: cash_bank_balances; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.cash_bank_balances (id, period, "periodDate", year, month, "openingBalance", "closingBalance", "totalInflow", "totalOutflow", "netChange", "calculatedAt", "calculatedBy", "createdAt", "updatedAt", "createdBy", "updatedBy", notes) FROM stdin;
\.


--
-- Data for Name: cash_transactions; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.cash_transactions (id, "transactionNumber", "transactionType", category, "transactionDate", amount, currency, "originalAmount", "exchangeRate", "idrAmount", "cashAccountId", "offsetAccountId", description, "descriptionId", "descriptionEn", reference, "paymentMethod", "checkNumber", "bankReference", "projectId", "clientId", "journalEntryId", status, "approvedBy", "approvedAt", "rejectedBy", "rejectedAt", "rejectionReason", "createdAt", "updatedAt", "createdBy", "updatedBy", notes, "notesId") FROM stdin;
\.


--
-- Data for Name: chart_of_accounts; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.chart_of_accounts (id, code, name, "nameId", "accountType", "accountSubType", "normalBalance", "parentId", "isControlAccount", "isTaxAccount", "taxType", currency, "isCurrencyAccount", "isActive", "isSystemAccount", description, "descriptionId", "createdAt", "updatedAt") FROM stdin;
cmi7jvr18000oipqm3ahta4vo	1-1010	Cash	Kas	ASSET	CURRENT_ASSET	DEBIT	\N	t	f	\N	IDR	t	t	t	Cash on hand	Kas ditangan	2025-11-20 14:52:29.469	2025-11-20 14:52:29.469
cmi7jvr1f000pipqmm8rpksgv	1-1020	Bank Account	Rekening Bank	ASSET	CURRENT_ASSET	DEBIT	\N	t	f	\N	IDR	t	t	t	Bank accounts (BCA, Mandiri, BNI)	Rekening bank (BCA, Mandiri, BNI)	2025-11-20 14:52:29.476	2025-11-20 14:52:29.476
cmi7jvr1j000qipqmzjo3psbt	1-1021	USD Bank Account	Rekening Bank USD	ASSET	CURRENT_ASSET	DEBIT	\N	f	f	\N	USD	t	t	f	USD denominated bank accounts	Rekening bank dalam mata uang USD	2025-11-20 14:52:29.479	2025-11-20 14:52:29.479
cmi7jvr1m000ripqm8ocxcrkf	1-1022	USDT Crypto Wallet	Dompet Kripto USDT	ASSET	CURRENT_ASSET	DEBIT	\N	f	f	\N	USDT	t	t	f	USDT (Tether) cryptocurrency wallet - FASB ASU 2023-08 compliant	Dompet cryptocurrency USDT (Tether) - Sesuai FASB ASU 2023-08	2025-11-20 14:52:29.482	2025-11-20 14:52:29.482
cmi7jvr1p000sipqm3ca25hpp	1-2010	Accounts Receivable	Piutang Usaha	ASSET	CURRENT_ASSET	DEBIT	\N	t	f	\N	IDR	f	t	t	Accounts receivable from customers	Piutang dari pelanggan	2025-11-20 14:52:29.485	2025-11-20 14:52:29.485
cmi7jvr1s000tipqmfwqxoav4	1-3010	Prepaid Expenses	Biaya Dibayar Dimuka	ASSET	CURRENT_ASSET	DEBIT	\N	f	f	\N	IDR	f	t	f	Prepaid rent, insurance, etc.	Sewa, asuransi, dll yang dibayar dimuka	2025-11-20 14:52:29.489	2025-11-20 14:52:29.489
cmi7jvr1w000uipqmu1od5vo0	1-4010	Equipment	Peralatan	ASSET	FIXED_ASSET	DEBIT	\N	f	f	\N	IDR	f	t	f	Computer equipment, furniture, etc.	Komputer, mebel, dll	2025-11-20 14:52:29.492	2025-11-20 14:52:29.492
cmi7jvr1z000vipqm8lzqnrpc	1-4020	Accumulated Depreciation	Akumulasi Penyusutan	ASSET	FIXED_ASSET	CREDIT	\N	f	f	\N	IDR	f	t	t	Accumulated depreciation on equipment (PSAK 16)	Akumulasi penyusutan peralatan (PSAK 16)	2025-11-20 14:52:29.495	2025-11-20 14:52:29.495
cmi7jvr22000wipqmeasy3n56	1-2015	Allowance for Doubtful Accounts	Penyisihan Piutang Tak Tertagih	ASSET	CURRENT_ASSET	CREDIT	\N	f	f	\N	IDR	f	t	t	Expected credit loss provision for accounts receivable (PSAK 71)	Penyisihan kerugian kredit ekspektasian untuk piutang usaha (PSAK 71)	2025-11-20 14:52:29.499	2025-11-20 14:52:29.499
cmi7jvr26000xipqmfhfpdtv1	2-1010	Accounts Payable	Hutang Usaha	LIABILITY	CURRENT_LIABILITY	CREDIT	\N	t	f	\N	IDR	f	t	t	Accounts payable to vendors	Hutang kepada vendor	2025-11-20 14:52:29.502	2025-11-20 14:52:29.502
cmi7jvr29000yipqmzlrzx6dj	2-2010	PPN Payable	Hutang PPN	LIABILITY	CURRENT_LIABILITY	CREDIT	\N	f	t	PPN_OUT	IDR	f	t	t	VAT payable to tax authority	PPN yang harus dibayar ke DJP	2025-11-20 14:52:29.505	2025-11-20 14:52:29.505
cmi7jvr2d000zipqm0osurk0c	2-2020	PPh Payable	Hutang PPh	LIABILITY	CURRENT_LIABILITY	CREDIT	\N	f	t	PPH23	IDR	f	t	t	Withholding tax payable	PPh yang harus dibayar	2025-11-20 14:52:29.509	2025-11-20 14:52:29.509
cmi7jvr2g0010ipqmeoo6o9vk	3-1010	Owner Capital	Modal Pemilik	EQUITY	CAPITAL	CREDIT	\N	f	f	\N	IDR	f	t	t	Owner's capital investment	Modal yang disetorkan pemilik	2025-11-20 14:52:29.512	2025-11-20 14:52:29.512
cmi7jvr2j0011ipqmautscc8a	3-2010	Retained Earnings	Laba Ditahan	EQUITY	RETAINED_EARNINGS	CREDIT	\N	f	f	\N	IDR	f	t	t	Accumulated retained earnings	Akumulasi laba yang ditahan	2025-11-20 14:52:29.515	2025-11-20 14:52:29.515
cmi7jvr2m0012ipqmthqc7sg0	3-3010	Current Year Profit/Loss	Laba/Rugi Tahun Berjalan	EQUITY	CURRENT_EARNINGS	CREDIT	\N	f	f	\N	IDR	f	t	t	Current year profit or loss	Laba/rugi tahun berjalan	2025-11-20 14:52:29.518	2025-11-20 14:52:29.518
cmi7jvr2p0013ipqmr0nfazw3	3-4010	Owner's Drawing	Prive Pemilik	EQUITY	DRAWING	DEBIT	\N	f	f	\N	IDR	f	t	t	Owner withdrawals	Pengambilan pemilik	2025-11-20 14:52:29.521	2025-11-20 14:52:29.521
cmi7jvr2s0014ipqmsm3ldmyz	4-1010	Service Revenue	Pendapatan Jasa	REVENUE	OPERATING_REVENUE	CREDIT	\N	f	f	\N	IDR	f	t	t	Revenue from services rendered	Pendapatan dari jasa yang diberikan	2025-11-20 14:52:29.525	2025-11-20 14:52:29.525
cmi7jvr2w0015ipqmhkcr5jq1	4-2010	Sales Revenue	Pendapatan Penjualan	REVENUE	OPERATING_REVENUE	CREDIT	\N	f	f	\N	IDR	f	t	f	Revenue from sales	Pendapatan dari penjualan	2025-11-20 14:52:29.528	2025-11-20 14:52:29.528
cmi7jvr2z0016ipqmybzvbmxt	4-9010	Other Income	Pendapatan Lain-Lain	REVENUE	OTHER_INCOME	CREDIT	\N	f	f	\N	IDR	f	t	t	Other income from non-operating activities	Pendapatan lain-lain dari aktivitas non-operasional	2025-11-20 14:52:29.531	2025-11-20 14:52:29.531
cmi7jvr320017ipqmcw9e2st9	6-1010	Sales Salaries	Gaji Penjualan	EXPENSE	SELLING_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Salaries and allowances for sales staff	Gaji dan tunjangan karyawan penjualan	2025-11-20 14:52:29.534	2025-11-20 14:52:29.534
cmi7jvr360018ipqmbjdacnw9	6-1030	Advertising & Promotion	Iklan dan Promosi	EXPENSE	SELLING_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Advertising, promotion, and marketing costs	Biaya iklan, promosi, dan marketing	2025-11-20 14:52:29.539	2025-11-20 14:52:29.539
cmi7jvr3a0019ipqmr2t56d9p	6-1070	Digital Marketing	Marketing Digital	EXPENSE	SELLING_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Online marketing costs	Biaya marketing online	2025-11-20 14:52:29.542	2025-11-20 14:52:29.542
cmi7jvr3e001aipqm5ag4er7r	6-2020	Office Rent	Sewa Kantor	EXPENSE	ADMIN_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Office rental costs	Biaya sewa kantor	2025-11-20 14:52:29.546	2025-11-20 14:52:29.546
cmi7jvr3i001bipqmdzdy9742	6-2030	Electricity & Water	Listrik dan Air	EXPENSE	ADMIN_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Electricity and water costs	Biaya listrik dan air	2025-11-20 14:52:29.55	2025-11-20 14:52:29.55
cmi7jvr3l001cipqm0u43s705	6-2050	Office Supplies	Perlengkapan Kantor	EXPENSE	ADMIN_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Stationery and office supplies	Alat tulis dan perlengkapan kantor	2025-11-20 14:52:29.553	2025-11-20 14:52:29.553
cmi7jvr3o001dipqmm18pkdud	6-2070	Professional Services	Jasa Profesional	EXPENSE	ADMIN_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Professional service fees	Biaya jasa profesional	2025-11-20 14:52:29.557	2025-11-20 14:52:29.557
cmi7jvr3r001eipqm0ztpqjmb	6-2130	Software & Licenses	Software dan Lisensi	EXPENSE	ADMIN_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Software and license costs	Biaya software dan lisensi	2025-11-20 14:52:29.56	2025-11-20 14:52:29.56
cmi7jvr3u001fipqm2ebk86xq	6-2160	Bank Charges	Biaya Bank	EXPENSE	ADMIN_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Bank fees and charges	Biaya administrasi bank	2025-11-20 14:52:29.563	2025-11-20 14:52:29.563
cmi7jvr3x001gipqm2p4vw8xf	6-2190	Miscellaneous Expenses	Biaya Lain-Lain	EXPENSE	ADMIN_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Miscellaneous expenses	Biaya lain-lain	2025-11-20 14:52:29.566	2025-11-20 14:52:29.566
cmi7jvr40001hipqm37swkn5a	6-3010	Depreciation Expense	Beban Penyusutan	EXPENSE	ADMIN_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	t	Depreciation expense on fixed assets (PSAK 16)	Beban penyusutan aset tetap (PSAK 16)	2025-11-20 14:52:29.569	2025-11-20 14:52:29.569
cmi7jvr44001iipqmbnjdgflv	8-1010	Bad Debt Expense	Beban Piutang Tak Tertagih	EXPENSE	OTHER_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	t	Bad debt expense and ECL provision (PSAK 71)	Beban piutang tak tertagih dan penyisihan kerugian kredit (PSAK 71)	2025-11-20 14:52:29.572	2025-11-20 14:52:29.572
cmi7jvr47001jipqm306hbpc1	8-2010	Other Expenses	Beban Lain-Lain	EXPENSE	OTHER_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Other non-operating expenses	Beban lain-lain diluar operasional	2025-11-20 14:52:29.575	2025-11-20 14:52:29.575
cmi7jvr4a001kipqmryatzdlq	1-1510	Inventory - Raw Materials	Persediaan Bahan Baku	ASSET	CURRENT_ASSET	DEBIT	\N	t	f	\N	IDR	f	t	f	Raw materials inventory	Persediaan bahan baku untuk produksi	2025-11-20 14:52:29.578	2025-11-20 14:52:29.578
cmi7jvr4c001lipqmvb0i5614	1-1520	Inventory - Work in Progress	Persediaan Barang Dalam Proses	ASSET	CURRENT_ASSET	DEBIT	\N	f	f	\N	IDR	f	t	f	Work in progress inventory	Persediaan barang yang masih dalam proses produksi	2025-11-20 14:52:29.581	2025-11-20 14:52:29.581
cmi7jvr4f001mipqm6zcc6ewx	1-1530	Inventory - Finished Goods	Persediaan Barang Jadi	ASSET	CURRENT_ASSET	DEBIT	\N	t	f	\N	IDR	f	t	f	Finished goods inventory	Persediaan barang jadi siap dijual	2025-11-20 14:52:29.583	2025-11-20 14:52:29.583
cmi7jvr4i001nipqme05by57a	1-2510	Prepaid PPh 23	PPh Pasal 23 Dibayar Dimuka	ASSET	CURRENT_ASSET	DEBIT	\N	f	t	PPh_23	IDR	f	t	f	Prepaid income tax article 23	Pajak penghasilan pasal 23 yang dibayar dimuka	2025-11-20 14:52:29.586	2025-11-20 14:52:29.586
cmi7jvr4l001oipqmn4excb2i	1-2520	Prepaid PPh 25	PPh Pasal 25 Dibayar Dimuka	ASSET	CURRENT_ASSET	DEBIT	\N	f	t	PPh_25	IDR	f	t	f	Prepaid income tax article 25 (monthly installment)	Pajak penghasilan pasal 25 (angsuran bulanan)	2025-11-20 14:52:29.589	2025-11-20 14:52:29.589
cmi7jvr4o001pipqm57b19p4g	1-2530	Prepaid PPN	PPN Masukan	ASSET	CURRENT_ASSET	DEBIT	\N	f	t	VAT_IN	IDR	f	t	f	Prepaid VAT (input VAT)	PPN yang dibayar saat pembelian (PPN Masukan)	2025-11-20 14:52:29.592	2025-11-20 14:52:29.592
cmi7jvr4r001qipqml02x64np	1-4110	Land	Tanah	ASSET	FIXED_ASSET	DEBIT	\N	f	f	\N	IDR	f	t	f	Land (not depreciated)	Tanah (tidak disusutkan)	2025-11-20 14:52:29.595	2025-11-20 14:52:29.595
cmi7jvr4t001ripqmha7qjocz	1-4210	Buildings	Bangunan	ASSET	FIXED_ASSET	DEBIT	\N	f	f	\N	IDR	f	t	f	Buildings and structures	Bangunan dan gedung	2025-11-20 14:52:29.598	2025-11-20 14:52:29.598
cmi7jvr4w001sipqmqavcfc45	1-4220	Accumulated Depreciation - Buildings	Akumulasi Penyusutan Bangunan	ASSET	FIXED_ASSET	CREDIT	\N	f	f	\N	IDR	f	t	f	Accumulated depreciation for buildings	Akumulasi penyusutan bangunan	2025-11-20 14:52:29.601	2025-11-20 14:52:29.601
cmi7jvr4z001tipqm9oavvjk4	1-4310	Vehicles	Kendaraan	ASSET	FIXED_ASSET	DEBIT	\N	f	f	\N	IDR	f	t	f	Vehicles and transportation equipment	Kendaraan dan alat transportasi	2025-11-20 14:52:29.604	2025-11-20 14:52:29.604
cmi7jvr52001uipqm5mj6dvxn	1-4320	Accumulated Depreciation - Vehicles	Akumulasi Penyusutan Kendaraan	ASSET	FIXED_ASSET	CREDIT	\N	f	f	\N	IDR	f	t	f	Accumulated depreciation for vehicles	Akumulasi penyusutan kendaraan	2025-11-20 14:52:29.607	2025-11-20 14:52:29.607
cmi7jvr55001vipqmwcdzn3qc	1-4410	Furniture & Fixtures	Perabotan Kantor	ASSET	FIXED_ASSET	DEBIT	\N	f	f	\N	IDR	f	t	f	Office furniture and fixtures	Perabotan dan perlengkapan kantor	2025-11-20 14:52:29.61	2025-11-20 14:52:29.61
cmi7jvr58001wipqmp8ggq8fg	1-4420	Accumulated Depreciation - Furniture	Akumulasi Penyusutan Perabotan	ASSET	FIXED_ASSET	CREDIT	\N	f	f	\N	IDR	f	t	f	Accumulated depreciation for furniture	Akumulasi penyusutan perabotan	2025-11-20 14:52:29.613	2025-11-20 14:52:29.613
cmi7jvr5c001xipqmev5zdt9p	1-5010	Goodwill	Goodwill	ASSET	INTANGIBLE_ASSET	DEBIT	\N	f	f	\N	IDR	f	t	f	Goodwill and brand value	Goodwill dan nilai merek	2025-11-20 14:52:29.616	2025-11-20 14:52:29.616
cmi7jvr5f001yipqm2eo0s9v4	1-5020	Patents & Trademarks	Hak Paten dan Merek Dagang	ASSET	INTANGIBLE_ASSET	DEBIT	\N	f	f	\N	IDR	f	t	f	Patents, trademarks, and intellectual property	Hak paten, merek dagang, dan kekayaan intelektual	2025-11-20 14:52:29.619	2025-11-20 14:52:29.619
cmi7jvr5i001zipqm4pi0pdvj	1-5030	Software Licenses	Lisensi Perangkat Lunak	ASSET	INTANGIBLE_ASSET	DEBIT	\N	f	f	\N	IDR	f	t	f	Long-term software licenses	Lisensi perangkat lunak jangka panjang	2025-11-20 14:52:29.622	2025-11-20 14:52:29.622
cmi7jvr5l0020ipqmc1bwftls	2-1110	Wages Payable	Hutang Gaji	LIABILITY	CURRENT_LIABILITY	CREDIT	\N	t	f	\N	IDR	f	t	f	Accrued wages and salaries payable	Hutang gaji dan upah karyawan	2025-11-20 14:52:29.626	2025-11-20 14:52:29.626
cmi7jvr5p0021ipqm9b8kt836	2-1120	Accrued Expenses	Biaya Yang Masih Harus Dibayar	LIABILITY	CURRENT_LIABILITY	CREDIT	\N	f	f	\N	IDR	f	t	f	Accrued expenses not yet paid	Biaya yang sudah terjadi tetapi belum dibayar	2025-11-20 14:52:29.629	2025-11-20 14:52:29.629
cmi7jvr5s0022ipqmusfkbp1z	2-1130	Customer Deposits	Uang Muka Pelanggan	LIABILITY	CURRENT_LIABILITY	CREDIT	\N	f	f	\N	IDR	f	t	f	Advance payments from customers	Uang muka yang diterima dari pelanggan	2025-11-20 14:52:29.633	2025-11-20 14:52:29.633
cmi7jvr5w0023ipqm6dzyxurc	2-2110	PPh 21 Payable	Hutang PPh Pasal 21	LIABILITY	CURRENT_LIABILITY	CREDIT	\N	f	t	PPh_21	IDR	f	t	f	Income tax article 21 (employee withholding) payable	Hutang pajak penghasilan pasal 21 (pemotongan gaji karyawan)	2025-11-20 14:52:29.637	2025-11-20 14:52:29.637
cmi7jvr600024ipqm6016bcak	2-2120	PPh 23 Payable	Hutang PPh Pasal 23	LIABILITY	CURRENT_LIABILITY	CREDIT	\N	f	t	PPh_23	IDR	f	t	f	Income tax article 23 (service withholding) payable	Hutang pajak penghasilan pasal 23 (pemotongan jasa)	2025-11-20 14:52:29.641	2025-11-20 14:52:29.641
cmi7jvr640025ipqmq1q69jz2	2-2130	PPh 25 Payable	Hutang PPh Pasal 25	LIABILITY	CURRENT_LIABILITY	CREDIT	\N	f	t	PPh_25	IDR	f	t	f	Income tax article 25 (monthly corporate tax) payable	Hutang pajak penghasilan pasal 25 (angsuran pajak badan)	2025-11-20 14:52:29.644	2025-11-20 14:52:29.644
cmi7jvr680026ipqmjr8251m2	2-2140	PPh 29 Payable	Hutang PPh Pasal 29	LIABILITY	CURRENT_LIABILITY	CREDIT	\N	f	t	PPh_29	IDR	f	t	f	Income tax article 29 (final annual tax) payable	Hutang pajak penghasilan pasal 29 (kurang bayar tahunan)	2025-11-20 14:52:29.648	2025-11-20 14:52:29.648
cmi7jvr6c0027ipqm84w4mrr2	2-2150	PPN Output	PPN Keluaran	LIABILITY	CURRENT_LIABILITY	CREDIT	\N	f	t	VAT_OUT	IDR	f	t	f	VAT collected from sales (output VAT)	PPN yang dipungut dari penjualan (PPN Keluaran)	2025-11-20 14:52:29.652	2025-11-20 14:52:29.652
cmi7jvr6g0028ipqmwmi0nv3x	2-3010	Bank Loans	Pinjaman Bank	LIABILITY	LONG_TERM_LIABILITY	CREDIT	\N	f	f	\N	IDR	f	t	f	Long-term bank loans	Pinjaman bank jangka panjang	2025-11-20 14:52:29.656	2025-11-20 14:52:29.656
cmi7jvr6k0029ipqmxq50mw88	2-3020	Bonds Payable	Hutang Obligasi	LIABILITY	LONG_TERM_LIABILITY	CREDIT	\N	f	f	\N	IDR	f	t	f	Bonds and debentures payable	Hutang obligasi dan surat utang	2025-11-20 14:52:29.66	2025-11-20 14:52:29.66
cmi7jvr6o002aipqmjnbuurrv	4-1020	Product Sales	Penjualan Produk	REVENUE	OPERATING_REVENUE	CREDIT	\N	f	f	\N	IDR	f	t	f	Revenue from product sales	Pendapatan dari penjualan produk	2025-11-20 14:52:29.664	2025-11-20 14:52:29.664
cmi7jvr6s002bipqmlezeute7	4-1030	Consulting Revenue	Pendapatan Konsultasi	REVENUE	OPERATING_REVENUE	CREDIT	\N	f	f	\N	IDR	f	t	f	Revenue from consulting services	Pendapatan dari jasa konsultasi	2025-11-20 14:52:29.668	2025-11-20 14:52:29.668
cmi7jvr6w002cipqmbolx093z	4-1040	Training Revenue	Pendapatan Pelatihan	REVENUE	OPERATING_REVENUE	CREDIT	\N	f	f	\N	IDR	f	t	f	Revenue from training services	Pendapatan dari jasa pelatihan	2025-11-20 14:52:29.672	2025-11-20 14:52:29.672
cmi7jvr70002dipqmbsalzoyv	4-8010	Interest Income	Pendapatan Bunga	REVENUE	OTHER_INCOME	CREDIT	\N	f	f	\N	IDR	f	t	f	Interest income from deposits	Pendapatan bunga dari deposito	2025-11-20 14:52:29.676	2025-11-20 14:52:29.676
cmi7jvr74002eipqmc1gkwvd2	4-8020	Foreign Exchange Gain	Keuntungan Selisih Kurs	REVENUE	OTHER_INCOME	CREDIT	\N	f	f	\N	IDR	f	t	f	Realized foreign exchange gains	Keuntungan selisih kurs yang terealisasi	2025-11-20 14:52:29.68	2025-11-20 14:52:29.68
cmi7jvr78002fipqmrgc6yzrz	4-8030	Gain on Asset Sales	Keuntungan Penjualan Aset	REVENUE	OTHER_INCOME	CREDIT	\N	f	f	\N	IDR	f	t	f	Gains from sale of fixed assets	Keuntungan dari penjualan aset tetap	2025-11-20 14:52:29.684	2025-11-20 14:52:29.684
cmi7jvr7c002gipqmwdk53dvr	5-1010	Cost of Goods Sold	Harga Pokok Penjualan	EXPENSE	COGS	DEBIT	\N	t	f	\N	IDR	f	t	f	Cost of goods sold	Harga pokok barang yang terjual	2025-11-20 14:52:29.688	2025-11-20 14:52:29.688
cmi7jvr7h002hipqmbni0jt77	5-1020	Direct Labor	Biaya Tenaga Kerja Langsung	EXPENSE	COGS	DEBIT	\N	f	f	\N	IDR	f	t	f	Direct labor costs for production	Biaya tenaga kerja langsung untuk produksi	2025-11-20 14:52:29.693	2025-11-20 14:52:29.693
cmi7jvr7l002iipqmkvi7mpng	5-1030	Manufacturing Overhead	Biaya Overhead Pabrik	EXPENSE	COGS	DEBIT	\N	f	f	\N	IDR	f	t	f	Manufacturing overhead costs	Biaya overhead produksi	2025-11-20 14:52:29.697	2025-11-20 14:52:29.697
cmi7jvr7p002jipqmitzaoesg	6-5010	Salaries - Management	Gaji Manajemen	EXPENSE	ADMIN_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Management salaries and compensation	Gaji dan kompensasi manajemen	2025-11-20 14:52:29.702	2025-11-20 14:52:29.702
cmi7jvr7u002kipqm5ydfz8y3	6-5020	Salaries - Administrative	Gaji Administrasi	EXPENSE	ADMIN_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Administrative staff salaries	Gaji karyawan administrasi	2025-11-20 14:52:29.706	2025-11-20 14:52:29.706
cmi7jvr7y002lipqmy5bjjzfj	6-5030	Employee Benefits	Tunjangan Karyawan	EXPENSE	ADMIN_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Employee benefits (BPJS, insurance, allowances)	Tunjangan karyawan (BPJS, asuransi, tunjangan)	2025-11-20 14:52:29.71	2025-11-20 14:52:29.71
cmi7jvr82002mipqmciq87was	6-5040	Severance Pay	Pesangon	EXPENSE	ADMIN_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Employee severance and termination benefits	Pesangon dan uang pisah karyawan	2025-11-20 14:52:29.715	2025-11-20 14:52:29.715
cmi7jvr86002nipqmtew72o2d	6-4010	Income Tax Expense	Beban Pajak Penghasilan	EXPENSE	TAX_EXPENSE	DEBIT	\N	f	t	\N	IDR	f	t	f	Corporate income tax expense	Beban pajak penghasilan badan	2025-11-20 14:52:29.719	2025-11-20 14:52:29.719
cmi7jvr8b002oipqm806pqbbx	6-4020	Property Tax	Pajak Bumi dan Bangunan (PBB)	EXPENSE	TAX_EXPENSE	DEBIT	\N	f	t	\N	IDR	f	t	f	Property tax (PBB)	Pajak bumi dan bangunan	2025-11-20 14:52:29.723	2025-11-20 14:52:29.723
cmi7jvr8f002pipqmg85tvkjt	8-3010	Interest Expense	Beban Bunga	EXPENSE	OTHER_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Interest expense on loans	Beban bunga pinjaman	2025-11-20 14:52:29.727	2025-11-20 14:52:29.727
cmi7jvr8j002qipqmsafcvrup	8-3020	Foreign Exchange Loss	Rugi Selisih Kurs	EXPENSE	OTHER_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Realized foreign exchange losses	Kerugian selisih kurs yang terealisasi	2025-11-20 14:52:29.731	2025-11-20 14:52:29.731
cmi7jvr8n002ripqm2s173xxi	8-3030	Loss on Asset Sales	Kerugian Penjualan Aset	EXPENSE	OTHER_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Losses from sale of fixed assets	Kerugian dari penjualan aset tetap	2025-11-20 14:52:29.735	2025-11-20 14:52:29.735
cmi7jvr8v002tipqmtuyzc9cs	4-2020	Photography Revenue	Pendapatan Fotografi	REVENUE	OPERATING_REVENUE	CREDIT	\N	f	f	\N	IDR	f	t	f	Revenue from photography services	Pendapatan dari jasa fotografi	2025-11-20 14:52:29.744	2025-11-20 14:52:29.744
cmi7jvr8z002uipqmvpjd182c	4-2030	Graphic Design Revenue	Pendapatan Desain Grafis	REVENUE	OPERATING_REVENUE	CREDIT	\N	f	f	\N	IDR	f	t	f	Revenue from graphic design services	Pendapatan dari jasa desain grafis	2025-11-20 14:52:29.747	2025-11-20 14:52:29.747
cmi7jvr93002vipqm812b7o5w	4-2040	Web Development Revenue	Pendapatan Pengembangan Website	REVENUE	OPERATING_REVENUE	CREDIT	\N	f	f	\N	IDR	f	t	f	Revenue from web development services	Pendapatan dari jasa pembuatan website	2025-11-20 14:52:29.752	2025-11-20 14:52:29.752
cmi7jvr97002wipqme7ubz6gm	4-2050	Social Media Management Revenue	Pendapatan Manajemen Media Sosial	REVENUE	OPERATING_REVENUE	CREDIT	\N	f	f	\N	IDR	f	t	f	Revenue from social media management services	Pendapatan dari jasa manajemen media sosial	2025-11-20 14:52:29.755	2025-11-20 14:52:29.755
cmi7jvr9b002xipqm7wgo92g1	4-2060	Content Creation Revenue	Pendapatan Pembuatan Konten	REVENUE	OPERATING_REVENUE	CREDIT	\N	f	f	\N	IDR	f	t	f	Revenue from content creation services	Pendapatan dari jasa pembuatan konten	2025-11-20 14:52:29.759	2025-11-20 14:52:29.759
cmi7jvr9e002yipqmzh10nm7w	4-2070	Video Editing Revenue	Pendapatan Editing Video	REVENUE	OPERATING_REVENUE	CREDIT	\N	f	f	\N	IDR	f	t	f	Revenue from video editing services	Pendapatan dari jasa editing video	2025-11-20 14:52:29.762	2025-11-20 14:52:29.762
cmi7jvr9h002zipqmj5sd2dkf	4-2080	Animation Revenue	Pendapatan Animasi	REVENUE	OPERATING_REVENUE	CREDIT	\N	f	f	\N	IDR	f	t	f	Revenue from animation services	Pendapatan dari jasa animasi	2025-11-20 14:52:29.765	2025-11-20 14:52:29.765
cmi7jvr9k0030ipqmrnuuzzpe	4-2090	Branding & Identity Revenue	Pendapatan Branding & Identitas	REVENUE	OPERATING_REVENUE	CREDIT	\N	f	f	\N	IDR	f	t	f	Revenue from branding and corporate identity services	Pendapatan dari jasa branding dan identitas korporat	2025-11-20 14:52:29.768	2025-11-20 14:52:29.768
cmi7jvr9n0031ipqm52rhza3b	5-2010	Freelancer - Videographer	Freelancer Videografer	EXPENSE	COGS	DEBIT	\N	f	f	\N	IDR	f	t	f	Freelance videographer costs	Biaya videografer freelance	2025-11-20 14:52:29.771	2025-11-20 14:52:29.771
cmi7jvr9q0032ipqm2vaohdta	5-2020	Freelancer - Photographer	Freelancer Fotografer	EXPENSE	COGS	DEBIT	\N	f	f	\N	IDR	f	t	f	Freelance photographer costs	Biaya fotografer freelance	2025-11-20 14:52:29.774	2025-11-20 14:52:29.774
cmi7jvr9u0033ipqmtly92w0y	5-2030	Freelancer - Graphic Designer	Freelancer Desainer Grafis	EXPENSE	COGS	DEBIT	\N	f	f	\N	IDR	f	t	f	Freelance graphic designer costs	Biaya desainer grafis freelance	2025-11-20 14:52:29.778	2025-11-20 14:52:29.778
cmi7jvr9x0034ipqmn2qb55xs	5-2040	Freelancer - Web Developer	Freelancer Developer Website	EXPENSE	COGS	DEBIT	\N	f	f	\N	IDR	f	t	f	Freelance web developer costs	Biaya developer website freelance	2025-11-20 14:52:29.781	2025-11-20 14:52:29.781
cmi7jvra00035ipqmq78i9lxd	5-2050	Freelancer - Video Editor	Freelancer Editor Video	EXPENSE	COGS	DEBIT	\N	f	f	\N	IDR	f	t	f	Freelance video editor costs	Biaya editor video freelance	2025-11-20 14:52:29.785	2025-11-20 14:52:29.785
cmi7jvra30036ipqm762zpidw	5-2060	Freelancer - Content Writer	Freelancer Penulis Konten	EXPENSE	COGS	DEBIT	\N	f	f	\N	IDR	f	t	f	Freelance content writer costs	Biaya penulis konten freelance	2025-11-20 14:52:29.788	2025-11-20 14:52:29.788
cmi7jvra60037ipqmxvuxu43q	5-3010	Stock Footage & Music	Footage & Musik Stok	EXPENSE	COGS	DEBIT	\N	f	f	\N	IDR	f	t	f	Stock footage, music, and media assets	Biaya footage, musik, dan aset media stok	2025-11-20 14:52:29.791	2025-11-20 14:52:29.791
cmi7jvra90038ipqmp3cr9e14	5-3020	Props & Equipment Rental	Sewa Properti & Peralatan	EXPENSE	COGS	DEBIT	\N	f	f	\N	IDR	f	t	f	Props and equipment rental for productions	Biaya sewa properti dan peralatan untuk produksi	2025-11-20 14:52:29.794	2025-11-20 14:52:29.794
cmi7jvrac0039ipqmtibjur2r	5-3030	Location Rental	Sewa Lokasi	EXPENSE	COGS	DEBIT	\N	f	f	\N	IDR	f	t	f	Location rental for shoots	Biaya sewa lokasi untuk pengambilan gambar	2025-11-20 14:52:29.797	2025-11-20 14:52:29.797
cmi7jvraf003aipqmfh89674b	5-3040	Talent & Models	Talent & Model	EXPENSE	COGS	DEBIT	\N	f	f	\N	IDR	f	t	f	Talent and model fees	Biaya talent dan model	2025-11-20 14:52:29.8	2025-11-20 14:52:29.8
cmi7jvral003cipqmmb0bdu0b	6-3020	Cloud Storage (Dropbox/Google)	Penyimpanan Cloud	EXPENSE	ADMIN_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Cloud storage subscription for project files	Langganan penyimpanan cloud untuk file proyek	2025-11-20 14:52:29.805	2025-11-20 14:52:29.805
cmi7jvran003dipqmx2691skk	6-3030	Project Management Software	Software Manajemen Proyek	EXPENSE	ADMIN_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Project management tools (Asana, Trello, Monday)	Tools manajemen proyek (Asana, Trello, Monday)	2025-11-20 14:52:29.808	2025-11-20 14:52:29.808
cmi7jvraq003eipqmytit22jt	6-3040	Stock Photo Subscriptions	Langganan Foto Stok	EXPENSE	ADMIN_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Stock photo subscriptions (Shutterstock, Unsplash Pro)	Langganan foto stok (Shutterstock, Unsplash Pro)	2025-11-20 14:52:29.811	2025-11-20 14:52:29.811
cmi7jvrat003fipqmtszkcxdb	6-3050	Video Hosting & Streaming	Hosting & Streaming Video	EXPENSE	ADMIN_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Video hosting services (Vimeo Pro, YouTube Premium)	Layanan hosting video (Vimeo Pro, YouTube Premium)	2025-11-20 14:52:29.814	2025-11-20 14:52:29.814
cmi7jvraw003gipqmkf976p7q	6-3060	Equipment Maintenance & Repair	Pemeliharaan & Perbaikan Peralatan	EXPENSE	ADMIN_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Camera, lens, and equipment maintenance	Pemeliharaan kamera, lensa, dan peralatan	2025-11-20 14:52:29.817	2025-11-20 14:52:29.817
cmi7jvraz003hipqm0dk35m1j	6-3070	Internet & Bandwidth	Internet & Bandwidth	EXPENSE	ADMIN_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	High-speed internet for uploads and downloads	Internet berkecepatan tinggi untuk upload dan download	2025-11-20 14:52:29.82	2025-11-20 14:52:29.82
cmi7jvrb2003iipqmqel1ainh	6-3080	Portfolio Website Hosting	Hosting Website Portfolio	EXPENSE	ADMIN_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Portfolio website hosting and domain	Hosting dan domain website portfolio	2025-11-20 14:52:29.823	2025-11-20 14:52:29.823
cmi7jvrb5003jipqmdumv9xrt	4-3010	SEO & SEM Services Revenue	Pendapatan Layanan SEO & SEM	REVENUE	OPERATING_REVENUE	CREDIT	\N	f	f	\N	IDR	f	t	f	Revenue from SEO and search engine marketing services	Pendapatan dari layanan SEO dan marketing mesin pencari	2025-11-20 14:52:29.825	2025-11-20 14:52:29.825
cmi7jvrb8003kipqmdb69eksg	4-3020	UI/UX Design Revenue	Pendapatan Desain UI/UX	REVENUE	OPERATING_REVENUE	CREDIT	\N	f	f	\N	IDR	f	t	f	Revenue from user interface and experience design	Pendapatan dari desain antarmuka dan pengalaman pengguna	2025-11-20 14:52:29.828	2025-11-20 14:52:29.828
cmi7jvrbb003lipqmjasjrqri	4-3030	Mobile App Development Revenue	Pendapatan Pengembangan Aplikasi Mobile	REVENUE	OPERATING_REVENUE	CREDIT	\N	f	f	\N	IDR	f	t	f	Revenue from mobile application development	Pendapatan dari pembuatan aplikasi mobile (iOS/Android)	2025-11-20 14:52:29.831	2025-11-20 14:52:29.831
cmi7jvrbe003mipqmpaj7607g	4-3040	Influencer Marketing Revenue	Pendapatan Marketing Influencer	REVENUE	OPERATING_REVENUE	CREDIT	\N	f	f	\N	IDR	f	t	f	Revenue from influencer marketing campaign management	Pendapatan dari manajemen kampanye influencer marketing	2025-11-20 14:52:29.834	2025-11-20 14:52:29.834
cmi7jvrbh003nipqm2xj0a7a5	4-3050	Podcast Production Revenue	Pendapatan Produksi Podcast	REVENUE	OPERATING_REVENUE	CREDIT	\N	f	f	\N	IDR	f	t	f	Revenue from podcast recording and production services	Pendapatan dari jasa rekaman dan produksi podcast	2025-11-20 14:52:29.837	2025-11-20 14:52:29.837
cmi7jvrbj003oipqmvrtincf4	4-3060	Livestreaming Services Revenue	Pendapatan Jasa Livestreaming	REVENUE	OPERATING_REVENUE	CREDIT	\N	f	f	\N	IDR	f	t	f	Revenue from live event streaming services	Pendapatan dari jasa siaran langsung acara	2025-11-20 14:52:29.84	2025-11-20 14:52:29.84
cmi7jvrbm003pipqmr47sxj9i	4-3070	3D Modeling & Rendering Revenue	Pendapatan Modeling & Rendering 3D	REVENUE	OPERATING_REVENUE	CREDIT	\N	f	f	\N	IDR	f	t	f	Revenue from 3D modeling and rendering services	Pendapatan dari jasa modeling dan rendering 3D	2025-11-20 14:52:29.843	2025-11-20 14:52:29.843
cmi7jvrbp003qipqmdvju7w16	4-3080	Email Marketing Services Revenue	Pendapatan Jasa Email Marketing	REVENUE	OPERATING_REVENUE	CREDIT	\N	f	f	\N	IDR	f	t	f	Revenue from email marketing campaign management	Pendapatan dari manajemen kampanye email marketing	2025-11-20 14:52:29.846	2025-11-20 14:52:29.846
cmi7jvrbs003ripqmtijubjxl	1-4510	Camera & Photography Equipment	Kamera & Peralatan Fotografi	ASSET	FIXED_ASSET	DEBIT	\N	f	f	\N	IDR	f	t	f	Cameras, lenses, tripods, and photography accessories	Kamera, lensa, tripod, dan aksesoris fotografi	2025-11-20 14:52:29.849	2025-11-20 14:52:29.849
cmi7jvrbw003sipqmttx5ifvr	1-4520	Accumulated Depreciation - Camera Equipment	Akumulasi Penyusutan Peralatan Kamera	ASSET	FIXED_ASSET	CREDIT	\N	f	f	\N	IDR	f	t	f	Accumulated depreciation for camera equipment	Akumulasi penyusutan peralatan kamera	2025-11-20 14:52:29.852	2025-11-20 14:52:29.852
cmi7jvrbz003tipqm4tbnvn7h	1-4530	Video & Audio Production Equipment	Peralatan Produksi Video & Audio	ASSET	FIXED_ASSET	DEBIT	\N	f	f	\N	IDR	f	t	f	Video cameras, microphones, audio recorders, mixers	Kamera video, mikrofon, perekam audio, mixer	2025-11-20 14:52:29.855	2025-11-20 14:52:29.855
cmi7jvrc3003uipqmruw1ubkk	1-4540	Accumulated Depreciation - Video/Audio Equipment	Akumulasi Penyusutan Peralatan Video/Audio	ASSET	FIXED_ASSET	CREDIT	\N	f	f	\N	IDR	f	t	f	Accumulated depreciation for video and audio equipment	Akumulasi penyusutan peralatan video dan audio	2025-11-20 14:52:29.859	2025-11-20 14:52:29.859
cmi7jvrc7003vipqmgzf6nsuh	1-4550	Lighting Equipment	Peralatan Pencahayaan	ASSET	FIXED_ASSET	DEBIT	\N	f	f	\N	IDR	f	t	f	Studio lights, LED panels, reflectors, and lighting accessories	Lampu studio, panel LED, reflektor, dan aksesoris pencahayaan	2025-11-20 14:52:29.863	2025-11-20 14:52:29.863
cmi7jvrcb003wipqmqg59uske	1-4560	Accumulated Depreciation - Lighting Equipment	Akumulasi Penyusutan Peralatan Pencahayaan	ASSET	FIXED_ASSET	CREDIT	\N	f	f	\N	IDR	f	t	f	Accumulated depreciation for lighting equipment	Akumulasi penyusutan peralatan pencahayaan	2025-11-20 14:52:29.867	2025-11-20 14:52:29.867
cmi7jvrcg003xipqmy5ik1myu	1-4570	Editing Workstations & Computers	Workstation Editing & Komputer	ASSET	FIXED_ASSET	DEBIT	\N	f	f	\N	IDR	f	t	f	High-performance computers for video/photo editing and rendering	Komputer performa tinggi untuk editing video/foto dan rendering	2025-11-20 14:52:29.872	2025-11-20 14:52:29.872
cmi7jvrcn003yipqm91qfd13a	1-4580	Accumulated Depreciation - Computers	Akumulasi Penyusutan Komputer	ASSET	FIXED_ASSET	CREDIT	\N	f	f	\N	IDR	f	t	f	Accumulated depreciation for editing workstations	Akumulasi penyusutan workstation editing	2025-11-20 14:52:29.88	2025-11-20 14:52:29.88
cmi7jvrcs003zipqm2s8kgvkj	6-6010	Meta Ads (Facebook/Instagram)	Iklan Meta (Facebook/Instagram)	EXPENSE	SELLING_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Advertising spend on Meta platforms	Biaya iklan di platform Meta	2025-11-20 14:52:29.885	2025-11-20 14:52:29.885
cmi7jvrcz0040ipqm3bfkumn1	6-6020	Google Ads (Search/Display/YouTube)	Google Ads (Search/Display/YouTube)	EXPENSE	SELLING_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Advertising spend on Google platforms	Biaya iklan di platform Google	2025-11-20 14:52:29.891	2025-11-20 14:52:29.891
cmi7jvrd40041ipqm00t4gtis	6-6030	TikTok Ads	Iklan TikTok	EXPENSE	SELLING_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Advertising spend on TikTok platform	Biaya iklan di platform TikTok	2025-11-20 14:52:29.897	2025-11-20 14:52:29.897
cmi7jvrda0042ipqmw2d5pnuw	6-6040	LinkedIn Ads	Iklan LinkedIn	EXPENSE	SELLING_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Advertising spend on LinkedIn platform	Biaya iklan di platform LinkedIn	2025-11-20 14:52:29.902	2025-11-20 14:52:29.902
cmi7jvrdf0043ipqmr9o9ffv0	6-7010	Figma/Sketch Subscription	Langganan Figma/Sketch	EXPENSE	ADMIN_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	UI/UX design tool subscription	Langganan tools desain UI/UX	2025-11-20 14:52:29.908	2025-11-20 14:52:29.908
cmi7jvrdk0044ipqmu0tm0rzb	6-7020	Font & Typography Licenses	Lisensi Font & Tipografi	EXPENSE	ADMIN_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Premium font licenses for commercial use	Lisensi font premium untuk penggunaan komersial	2025-11-20 14:52:29.913	2025-11-20 14:52:29.913
cmi7jvrdp0045ipqmyqdnqpkb	6-7030	Music Licensing (Epidemic Sound, Artlist)	Lisensi Musik (Epidemic Sound, Artlist)	EXPENSE	ADMIN_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Music licensing for video production	Lisensi musik untuk produksi video	2025-11-20 14:52:29.917	2025-11-20 14:52:29.917
cmi7jvrds0046ipqmlbb8iml6	6-7040	3D Software (Blender/Cinema 4D)	Software 3D (Blender/Cinema 4D)	EXPENSE	ADMIN_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	3D modeling and rendering software subscriptions	Langganan software modeling dan rendering 3D	2025-11-20 14:52:29.921	2025-11-20 14:52:29.921
cmi7jvrdw0047ipqm739wpiev	6-7050	Color Grading Software (DaVinci Resolve)	Software Color Grading (DaVinci Resolve)	EXPENSE	ADMIN_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Professional color grading and finishing software	Software color grading dan finishing profesional	2025-11-20 14:52:29.924	2025-11-20 14:52:29.924
cmi7jvrdz0048ipqmvacmi0sl	6-7060	Analytics Tools (Google Analytics, Hotjar)	Tools Analitik (Google Analytics, Hotjar)	EXPENSE	ADMIN_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Website analytics and user behavior tracking tools	Tools analitik website dan pelacakan perilaku user	2025-11-20 14:52:29.927	2025-11-20 14:52:29.927
cmi7jvre20049ipqmjhbjh7j2	6-7070	Email Marketing Platform (Mailchimp, SendGrid)	Platform Email Marketing (Mailchimp, SendGrid)	EXPENSE	ADMIN_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Email marketing automation platform subscriptions	Langganan platform otomasi email marketing	2025-11-20 14:52:29.93	2025-11-20 14:52:29.93
cmi7jvre5004aipqmxb87aotm	6-7080	CRM Software (HubSpot, Salesforce)	Software CRM (HubSpot, Salesforce)	EXPENSE	ADMIN_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Customer relationship management software	Software manajemen hubungan pelanggan	2025-11-20 14:52:29.934	2025-11-20 14:52:29.934
cmi7jvre8004bipqm8ukkvp7i	6-7090	Social Media Scheduling Tools (Buffer, Hootsuite)	Tools Penjadwalan Sosmed (Buffer, Hootsuite)	EXPENSE	ADMIN_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Social media scheduling and management platforms	Platform penjadwalan dan manajemen media sosial	2025-11-20 14:52:29.937	2025-11-20 14:52:29.937
cmi7jvrec004cipqmma9z9sub	6-7100	Domain & SSL Certificates	Domain & Sertifikat SSL	EXPENSE	ADMIN_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Domain registrations and SSL certificate renewals	Registrasi domain dan perpanjangan sertifikat SSL	2025-11-20 14:52:29.94	2025-11-20 14:52:29.94
cmi7jvref004dipqmx90hc4oh	6-7110	Web Hosting Services	Layanan Web Hosting	EXPENSE	ADMIN_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	Web hosting for client projects and internal sites	Web hosting untuk proyek klien dan website internal	2025-11-20 14:52:29.943	2025-11-20 14:52:29.943
cmi7jvrei004eipqmxwo2upxt	6-7120	VPN & Security Software	VPN & Software Keamanan	EXPENSE	ADMIN_EXPENSE	DEBIT	\N	f	f	\N	IDR	f	t	f	VPN services and cybersecurity software subscriptions	Layanan VPN dan langganan software keamanan cyber	2025-11-20 14:52:29.946	2025-11-20 14:52:29.946
cmi7jvrel004fipqm7xv9d5v2	5-4010	Freelancer - Social Media Specialist	Freelancer Spesialis Media Sosial	EXPENSE	COGS	DEBIT	\N	f	f	\N	IDR	f	t	f	Freelance social media specialist costs	Biaya spesialis media sosial freelance	2025-11-20 14:52:29.949	2025-11-20 14:52:29.949
cmi7jvreo004gipqmqqlx9zci	5-4020	Freelancer - SEO Specialist	Freelancer Spesialis SEO	EXPENSE	COGS	DEBIT	\N	f	f	\N	IDR	f	t	f	Freelance SEO specialist costs	Biaya spesialis SEO freelance	2025-11-20 14:52:29.952	2025-11-20 14:52:29.952
cmi7jvrer004hipqmvibgscld	5-4030	Freelancer - UI/UX Designer	Freelancer Desainer UI/UX	EXPENSE	COGS	DEBIT	\N	f	f	\N	IDR	f	t	f	Freelance UI/UX designer costs	Biaya desainer UI/UX freelance	2025-11-20 14:52:29.956	2025-11-20 14:52:29.956
cmi7jvrev004iipqme7mq4wa6	5-4040	Freelancer - Motion Graphics Designer	Freelancer Desainer Motion Graphics	EXPENSE	COGS	DEBIT	\N	f	f	\N	IDR	f	t	f	Freelance motion graphics designer costs	Biaya desainer motion graphics freelance	2025-11-20 14:52:29.959	2025-11-20 14:52:29.959
cmi7jvrey004jipqmgjewrkxq	5-4050	Freelancer - Voice Over Artist	Freelancer Pengisi Suara	EXPENSE	COGS	DEBIT	\N	f	f	\N	IDR	f	t	f	Voice over artist fees for video narration	Biaya pengisi suara untuk narasi video	2025-11-20 14:52:29.962	2025-11-20 14:52:29.962
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.clients (id, name, email, phone, address, company, "contactPerson", "paymentTerms", status, "createdAt", "updatedAt", "taxNumber", "bankAccount", notes) FROM stdin;
client-1	PT Teknologi Maju	info@teknologimaju.co.id	021-1234567	Jl. Sudirman No. 123, Jakarta Pusat 10270	PT Teknologi Maju	Budi Santoso	NET 30	active	2025-11-20 14:52:29.413	2025-11-20 14:52:29.413	\N	\N	\N
client-2	CV Kreatif Digital	hello@kreatifdigital.com	021-9876543	Jl. Gatot Subroto No. 456, Jakarta Selatan 12930	CV Kreatif Digital	Sari Dewi	NET 14	active	2025-11-20 14:52:29.418	2025-11-20 14:52:29.418	\N	\N	\N
client-3	Toko Mandiri Sejahtera	owner@mandirisejahtera.com	021-5555678	Jl. Thamrin No. 789, Jakarta Pusat 10340	Toko Mandiri Sejahtera	Ahmad Wijaya	NET 21	active	2025-11-20 14:52:29.42	2025-11-20 14:52:29.42	\N	\N	\N
\.


--
-- Data for Name: collection_items; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.collection_items (id, "collectionId", "assetId", "order", "addedAt") FROM stdin;
\.


--
-- Data for Name: collections; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.collections (id, "projectId", name, description, "isDynamic", filters, "groupBy", "sortBy", "sortOrder", "isShared", "shareToken", "sharePassword", "createdBy", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: company_settings; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.company_settings (id, "companyName", address, phone, email, website, "taxNumber", currency, "bankBCA", "bankMandiri", "bankBNI", "createdAt", "updatedAt") FROM stdin;
default	Monomi Agency	Taman Cibaduyut Indah Blok E 232	085156662098	admin@monomiagency.com		000000000000000	IDR	3462676350			2025-11-16 17:40:35.961	2025-11-16 17:40:35.961
\.


--
-- Data for Name: content_calendar_items; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.content_calendar_items (id, "scheduledAt", "publishedAt", status, platforms, "clientId", "projectId", "createdBy", "createdAt", "updatedAt", caption) FROM stdin;
\.


--
-- Data for Name: content_media; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.content_media (id, url, key, type, "mimeType", size, width, height, duration, "originalName", "contentId", "uploadedAt", "thumbnailKey", "thumbnailUrl", "order") FROM stdin;
\.


--
-- Data for Name: deferred_revenue; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.deferred_revenue (id, "invoiceId", "paymentDate", "totalAmount", "recognitionDate", "recognizedAmount", "remainingAmount", status, "performanceObligation", "completionPercentage", "initialJournalId", "recognitionJournalId", "fiscalPeriodId", notes, "notesId", "createdAt", "updatedAt", "createdBy", "recognizedAt", "recognizedBy") FROM stdin;
\.


--
-- Data for Name: depreciation_entries; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.depreciation_entries (id, "assetId", "scheduleId", "periodDate", "fiscalPeriodId", "depreciationAmount", "accumulatedDepreciation", "bookValue", "journalEntryId", status, "calculatedAt", "postedAt", "postedBy", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: depreciation_schedules; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.depreciation_schedules (id, "assetId", method, "depreciableAmount", "residualValue", "usefulLifeMonths", "usefulLifeYears", "depreciationPerMonth", "depreciationPerYear", "annualRate", "startDate", "endDate", "isActive", "isFulfilled", notes, "notesId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.documents (id, "fileName", "originalFileName", "filePath", "fileSize", "mimeType", category, description, "invoiceId", "quotationId", "projectId", "uploadedBy", "uploadedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: exchange_rates; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.exchange_rates (id, "fromCurrency", "toCurrency", rate, "effectiveDate", "expiryDate", source, "isAutomatic", "isActive", "createdAt", "updatedAt", "createdBy", "updatedBy") FROM stdin;
\.


--
-- Data for Name: expense_approval_history; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.expense_approval_history (id, "expenseId", action, "actionBy", "previousStatus", "newStatus", comments, "commentsId", "commentsEn", "actionDate") FROM stdin;
\.


--
-- Data for Name: expense_budgets; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.expense_budgets (id, name, "nameId", description, "descriptionId", "categoryId", "projectId", "userId", amount, period, "startDate", "endDate", spent, remaining, "alertThreshold", "alertSent", "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: expense_categories; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.expense_categories (id, code, "accountCode", "expenseClass", name, "nameId", description, "descriptionId", "parentId", "defaultPPNRate", "isLuxuryGoods", "withholdingTaxType", "withholdingTaxRate", icon, color, "isActive", "isBillable", "requiresReceipt", "requiresEFaktur", "approvalRequired", "sortOrder", "createdAt", "updatedAt") FROM stdin;
cmi7jvr13000mipqmigof0u81	LABOR	6-2010	LABOR_COST	Labor Costs	Biaya Tenaga Kerja	Labor and personnel costs generated from time tracking	Biaya tenaga kerja dan personel dari pelacakan waktu	\N	0.0000	f	NONE	\N	team	#722ed1	t	f	t	f	t	10	2025-11-20 14:52:29.463	2025-11-20 14:52:29.463
cmi7jvr0b000dipqm39o3xzen	SELLING_SALARIES	6-1010	SELLING	Sales Salaries	Gaji Penjualan	Salaries and allowances for sales staff	Gaji dan tunjangan karyawan penjualan	\N	0.0000	f	NONE	\N	user	#1890ff	t	f	t	f	t	1	2025-11-20 14:52:29.435	2025-11-20 14:52:29.535
cmi7jvr0f000eipqmspnytrd1	ADVERTISING	6-1030	SELLING	Advertising & Promotion	Iklan dan Promosi	Advertising, promotion, and marketing costs	Biaya iklan, promosi, dan marketing	\N	0.1200	f	NONE	\N	sound	#fa8c16	t	t	t	t	t	3	2025-11-20 14:52:29.439	2025-11-20 14:52:29.539
cmi7jvr0i000fipqmkxv1sfug	DIGITAL_MARKETING	6-1070	SELLING	Digital Marketing	Marketing Digital	Online marketing costs (Google Ads, Facebook Ads, etc.)	Biaya marketing online (Google Ads, Facebook Ads, dll)	\N	0.1200	f	NONE	\N	global	#eb2f96	t	t	t	t	t	7	2025-11-20 14:52:29.442	2025-11-20 14:52:29.543
cmi7jvr0l000gipqm2ght3pv5	OFFICE_RENT	6-2020	GENERAL_ADMIN	Office Rent	Sewa Kantor	Office building or space rental costs	Biaya sewa gedung/ruang kantor	\N	0.1200	f	PPH4_2	0.1000	home	#52c41a	t	f	t	t	t	20	2025-11-20 14:52:29.445	2025-11-20 14:52:29.547
cmi7jvr0o000hipqm6p5c9yvq	UTILITIES	6-2030	GENERAL_ADMIN	Electricity & Water	Listrik dan Air	Electricity, water, and office utilities	Biaya listrik, air, dan utilitas kantor	\N	0.1200	f	NONE	\N	bulb	#faad14	t	f	t	t	t	30	2025-11-20 14:52:29.448	2025-11-20 14:52:29.551
cmi7jvr0r000iipqm8mrl4dca	OFFICE_SUPPLIES	6-2050	GENERAL_ADMIN	Office Supplies	Perlengkapan Kantor	Stationery and office supplies	Biaya alat tulis dan perlengkapan kantor	\N	0.1200	f	NONE	\N	file	#2f54eb	t	f	t	t	t	50	2025-11-20 14:52:29.451	2025-11-20 14:52:29.554
cmi7jvr0u000jipqm674uy10y	PROFESSIONAL_SERVICES	6-2070	GENERAL_ADMIN	Professional Services	Jasa Profesional	Professional services (accountants, auditors, etc.)	Biaya jasa profesional (akuntan, auditor, dll)	\N	0.1200	f	PPH23	0.0200	solution	#eb2f96	t	t	t	t	t	70	2025-11-20 14:52:29.454	2025-11-20 14:52:29.557
cmi7jvr0x000kipqm5vcyzmon	SOFTWARE	6-2130	GENERAL_ADMIN	Software & Licenses	Software dan Lisensi	Software, SaaS, and license costs	Biaya software, SaaS, dan lisensi	\N	0.1200	f	NONE	\N	cloud	#2f54eb	t	f	t	t	t	130	2025-11-20 14:52:29.457	2025-11-20 14:52:29.56
cmi7jvr10000lipqmrco6ck14	BANK_CHARGES	6-2160	GENERAL_ADMIN	Bank Charges	Biaya Bank	Bank administration and service fees	Biaya administrasi dan layanan bank	\N	0.0000	f	NONE	\N	transaction	#faad14	t	f	t	f	t	160	2025-11-20 14:52:29.46	2025-11-20 14:52:29.563
cmi7jvr15000nipqmtww5nux8	MISCELLANEOUS	6-2190	GENERAL_ADMIN	Miscellaneous Expenses	Biaya Lain-Lain	Miscellaneous expenses	Biaya lain-lain	\N	0.1200	f	NONE	\N	more	#8c8c8c	t	f	t	t	t	190	2025-11-20 14:52:29.466	2025-11-20 14:52:29.566
3f7cbe50-1285-4d66-bef4-68116e6dcb2e	6_3010	6-3010	OTHER	Depreciation Expense	Beban Penyusutan	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.569	2025-11-20 14:52:29.569
fdb47493-ed3b-44fd-b2fb-a5f851c1e4d3	5_1010	5-1010	COGS	Cost of Goods Sold	Harga Pokok Penjualan	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.689	2025-11-20 14:52:29.689
3a88bd40-e3d4-483c-8143-90c69d77206a	5_1020	5-1020	COGS	Direct Labor	Biaya Tenaga Kerja Langsung	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.694	2025-11-20 14:52:29.694
939b9501-e964-40c2-911f-b8826b5357a7	5_1030	5-1030	COGS	Manufacturing Overhead	Biaya Overhead Pabrik	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.698	2025-11-20 14:52:29.698
f17802bf-8676-4bc8-8aa6-a9fa03867cf6	6_5010	6-5010	OTHER	Salaries - Management	Gaji Manajemen	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.703	2025-11-20 14:52:29.703
dfcb9641-aef8-4bf3-8dc0-49af1703c088	6_5020	6-5020	OTHER	Salaries - Administrative	Gaji Administrasi	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.707	2025-11-20 14:52:29.707
51c29afb-6ef1-4f1b-bea3-55dd64cbde0f	6_5030	6-5030	OTHER	Employee Benefits	Tunjangan Karyawan	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.711	2025-11-20 14:52:29.711
714b119e-b48f-4d03-90fc-abe2c9c8a914	6_5040	6-5040	OTHER	Severance Pay	Pesangon	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.715	2025-11-20 14:52:29.715
e84e0abc-4b2d-412e-8e4e-203c66008b82	6_4010	6-4010	OTHER	Income Tax Expense	Beban Pajak Penghasilan	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.72	2025-11-20 14:52:29.72
aeb91530-6df7-4d97-969c-5de82cd7e53f	6_4020	6-4020	OTHER	Property Tax	Pajak Bumi dan Bangunan (PBB)	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.724	2025-11-20 14:52:29.724
c61913a4-79f4-4093-9497-27cdaa9c622f	5_2010	5-2010	COGS	Freelancer - Videographer	Freelancer Videografer	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.772	2025-11-20 14:52:29.772
e19188b9-40c0-4aef-be89-6955437430e5	5_2020	5-2020	COGS	Freelancer - Photographer	Freelancer Fotografer	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.775	2025-11-20 14:52:29.775
19509f8a-cfb7-4b71-aee8-98c40829465b	5_2030	5-2030	COGS	Freelancer - Graphic Designer	Freelancer Desainer Grafis	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.779	2025-11-20 14:52:29.779
671897f1-ef7a-407e-836f-e8962e6be4da	5_2040	5-2040	COGS	Freelancer - Web Developer	Freelancer Developer Website	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.782	2025-11-20 14:52:29.782
a518c7de-b3d3-4f9d-8ca4-f01c55912a03	5_2050	5-2050	COGS	Freelancer - Video Editor	Freelancer Editor Video	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.785	2025-11-20 14:52:29.785
31807b4c-aebc-47f1-bf73-f49c5d2b215d	5_2060	5-2060	COGS	Freelancer - Content Writer	Freelancer Penulis Konten	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.788	2025-11-20 14:52:29.788
2dc04d60-cdfe-423f-b1cc-be4e12c3a020	5_3010	5-3010	COGS	Stock Footage & Music	Footage & Musik Stok	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.791	2025-11-20 14:52:29.791
829cd48d-e21a-413b-b407-e94a79c241b3	5_3020	5-3020	COGS	Props & Equipment Rental	Sewa Properti & Peralatan	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.794	2025-11-20 14:52:29.794
5c7d43f6-9782-497c-849f-a7a58bc0c7e4	5_3030	5-3030	COGS	Location Rental	Sewa Lokasi	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.797	2025-11-20 14:52:29.797
ea10dd3d-d42d-4ed4-84d5-30506bb032ec	5_3040	5-3040	COGS	Talent & Models	Talent & Model	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.8	2025-11-20 14:52:29.8
8ccbdf3e-82a0-498a-b860-9e4987f85e86	6_3020	6-3020	OTHER	Cloud Storage (Dropbox/Google)	Penyimpanan Cloud	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.805	2025-11-20 14:52:29.805
a921009c-29c6-4afb-94f1-5e6b319cc535	6_3030	6-3030	OTHER	Project Management Software	Software Manajemen Proyek	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.808	2025-11-20 14:52:29.808
ca8d06ac-bb9a-4d1b-8608-66456a0ae606	6_3040	6-3040	OTHER	Stock Photo Subscriptions	Langganan Foto Stok	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.811	2025-11-20 14:52:29.811
16314019-8726-4fed-9b58-685e18f9ae9b	6_3050	6-3050	OTHER	Video Hosting & Streaming	Hosting & Streaming Video	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.814	2025-11-20 14:52:29.814
cae4caac-989c-4820-bbb6-c2606285bc93	6_3060	6-3060	OTHER	Equipment Maintenance & Repair	Pemeliharaan & Perbaikan Peralatan	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.817	2025-11-20 14:52:29.817
326960d8-b8c2-4ff2-92ac-59915e8d0543	6_3070	6-3070	OTHER	Internet & Bandwidth	Internet & Bandwidth	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.82	2025-11-20 14:52:29.82
62d1f59c-b3f0-4d07-9804-ccfb0a84d0c9	6_3080	6-3080	OTHER	Portfolio Website Hosting	Hosting Website Portfolio	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.823	2025-11-20 14:52:29.823
94717e4b-5378-47f1-987c-524dccbf97cb	6_6010	6-6010	OTHER	Meta Ads (Facebook/Instagram)	Iklan Meta (Facebook/Instagram)	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.886	2025-11-20 14:52:29.886
c7f5fb69-7c1a-45d1-915b-d470793408ae	6_6020	6-6020	OTHER	Google Ads (Search/Display/YouTube)	Google Ads (Search/Display/YouTube)	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.892	2025-11-20 14:52:29.892
f16cf14c-431d-48ad-859b-3e8a766367ed	6_6030	6-6030	OTHER	TikTok Ads	Iklan TikTok	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.898	2025-11-20 14:52:29.898
ff6e52c5-4083-43a7-9c7d-b1bf2b4ecbb7	6_6040	6-6040	OTHER	LinkedIn Ads	Iklan LinkedIn	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.903	2025-11-20 14:52:29.903
798d85c7-f2c7-42ce-83c7-1a6c21c077c3	6_7010	6-7010	OTHER	Figma/Sketch Subscription	Langganan Figma/Sketch	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.909	2025-11-20 14:52:29.909
c875ba25-ec79-41b4-9bad-3b2c9bd9fb3d	6_7020	6-7020	OTHER	Font & Typography Licenses	Lisensi Font & Tipografi	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.913	2025-11-20 14:52:29.913
004575d8-809e-4d83-bb85-f039bad2f6b5	6_7030	6-7030	OTHER	Music Licensing (Epidemic Sound, Artlist)	Lisensi Musik (Epidemic Sound, Artlist)	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.918	2025-11-20 14:52:29.918
cf4f8c3f-e168-46d9-9f71-63a74d222586	6_7040	6-7040	OTHER	3D Software (Blender/Cinema 4D)	Software 3D (Blender/Cinema 4D)	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.921	2025-11-20 14:52:29.921
d88677e0-35af-41a1-99c8-d61171a99967	6_7050	6-7050	OTHER	Color Grading Software (DaVinci Resolve)	Software Color Grading (DaVinci Resolve)	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.925	2025-11-20 14:52:29.925
c0d3bb5f-c255-4627-a329-e0e66e22627f	6_7060	6-7060	OTHER	Analytics Tools (Google Analytics, Hotjar)	Tools Analitik (Google Analytics, Hotjar)	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.928	2025-11-20 14:52:29.928
d1067601-103a-440c-abc4-40e052e8512b	6_7070	6-7070	OTHER	Email Marketing Platform (Mailchimp, SendGrid)	Platform Email Marketing (Mailchimp, SendGrid)	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.931	2025-11-20 14:52:29.931
969f22b7-bc38-4566-b91d-c5c48dcfd6b5	6_7080	6-7080	OTHER	CRM Software (HubSpot, Salesforce)	Software CRM (HubSpot, Salesforce)	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.934	2025-11-20 14:52:29.934
306ea4c4-f8fe-4cf8-bfc9-7c6294e940ff	6_7090	6-7090	OTHER	Social Media Scheduling Tools (Buffer, Hootsuite)	Tools Penjadwalan Sosmed (Buffer, Hootsuite)	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.937	2025-11-20 14:52:29.937
35aa3fc0-f419-429f-b312-7d2812a0db9d	6_7100	6-7100	OTHER	Domain & SSL Certificates	Domain & Sertifikat SSL	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.94	2025-11-20 14:52:29.94
df59d78e-ce5c-4206-b3ac-562642987fa8	6_7110	6-7110	OTHER	Web Hosting Services	Layanan Web Hosting	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.944	2025-11-20 14:52:29.944
47fa52fe-79fe-444d-a594-5dbed99dcde3	6_7120	6-7120	OTHER	VPN & Security Software	VPN & Software Keamanan	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.947	2025-11-20 14:52:29.947
efdc704e-9069-429c-91f9-4d400067a276	5_4010	5-4010	COGS	Freelancer - Social Media Specialist	Freelancer Spesialis Media Sosial	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.95	2025-11-20 14:52:29.95
0f6d5875-70f5-493f-b120-7732d02094a1	5_4020	5-4020	COGS	Freelancer - SEO Specialist	Freelancer Spesialis SEO	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.953	2025-11-20 14:52:29.953
dfd3cdd3-951d-41e1-bcd6-e08f6539638b	5_4030	5-4030	COGS	Freelancer - UI/UX Designer	Freelancer Desainer UI/UX	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.956	2025-11-20 14:52:29.956
08c5ec8d-72e7-4fe3-af55-858a9a3184d6	5_4040	5-4040	COGS	Freelancer - Motion Graphics Designer	Freelancer Desainer Motion Graphics	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.959	2025-11-20 14:52:29.959
5233a77e-9484-4828-a285-b9859fd2c628	5_4050	5-4050	COGS	Freelancer - Voice Over Artist	Freelancer Pengisi Suara	\N	\N	\N	0.1200	f	NONE	\N	\N	#1890ff	t	f	t	t	t	0	2025-11-20 14:52:29.963	2025-11-20 14:52:29.963
\.


--
-- Data for Name: expense_comments; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.expense_comments (id, "expenseId", "userId", comment, "commentId", "commentEn", "isInternal", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: expense_documents; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.expense_documents (id, "fileName", "originalFileName", "filePath", "fileSize", "mimeType", category, description, "expenseId", "uploadedBy", "uploadedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.expenses (id, "expenseNumber", "buktiPengeluaranNumber", "accountCode", "accountName", "accountNameEn", "expenseClass", description, "descriptionId", "descriptionEn", "ppnRate", "ppnAmount", "ppnCategory", "isLuxuryGoods", "eFakturNSFP", "eFakturQRCode", "eFakturApprovalCode", "eFakturStatus", "eFakturValidatedAt", "withholdingTaxType", "withholdingTaxRate", "withholdingTaxAmount", "buktiPotongNumber", "buktiPotongDate", "vendorName", "vendorNPWP", "vendorAddress", "vendorPhone", "vendorBank", "vendorAccountNo", "vendorAccountName", "grossAmount", "withholdingAmount", "netAmount", "totalAmount", "expenseDate", currency, "categoryId", tags, "isTaxDeductible", "userId", "projectId", "clientId", "isBillable", "billableAmount", "invoiceId", status, "submittedAt", "approvedAt", "approvedBy", "rejectedAt", "rejectionReason", "paymentStatus", "paidAt", "paymentMethod", "paymentReference", "paymentId", "journalEntryId", "paymentJournalId", notes, "notesId", "notesEn", "receiptNumber", "merchantName", location, "createdAt", "updatedAt", "createdBy", "updatedBy", "purchaseType", "purchaseSource", "vendorId", "purchaseOrderId", "vendorInvoiceId", "accountsPayableId", "dueDate") FROM stdin;
\.


--
-- Data for Name: feature_flag_events; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.feature_flag_events (id, "flagId", "userId", "eventType", metadata, "createdAt") FROM stdin;
\.


--
-- Data for Name: feature_flags; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.feature_flags (id, name, description, enabled, "globalEnabled", "targetUsers", "targetGroups", rules, "expiresAt", "disabledReason", "disabledAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: financial_statements; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.financial_statements (id, "statementType", "fiscalPeriodId", "startDate", "endDate", data, "generatedAt", "generatedBy", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: fiscal_periods; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.fiscal_periods (id, name, code, "periodType", "startDate", "endDate", status, "isActive", "closedAt", "closedBy", "closingNotes", "createdAt", "updatedAt") FROM stdin;
cmi7jvrfm004kipqmkmixfuxr	January 2025	2025-01	MONTHLY	2025-01-01 00:00:00	2025-01-31 23:59:59	OPEN	t	\N	\N	\N	2025-11-20 14:52:29.986	2025-11-20 14:52:29.986
cmi7jvrfq004lipqm1suzsij4	February 2025	2025-02	MONTHLY	2025-02-01 00:00:00	2025-02-28 23:59:59	OPEN	t	\N	\N	\N	2025-11-20 14:52:29.991	2025-11-20 14:52:29.991
cmi7jvrft004mipqm1ahsk1ei	March 2025	2025-03	MONTHLY	2025-03-01 00:00:00	2025-03-31 23:59:59	OPEN	t	\N	\N	\N	2025-11-20 14:52:29.994	2025-11-20 14:52:29.994
cmi7jvrfw004nipqmi4l2h0nf	April 2025	2025-04	MONTHLY	2025-04-01 00:00:00	2025-04-30 23:59:59	OPEN	t	\N	\N	\N	2025-11-20 14:52:29.997	2025-11-20 14:52:29.997
cmi7jvrfz004oipqm6mr0yz0f	May 2025	2025-05	MONTHLY	2025-05-01 00:00:00	2025-05-31 23:59:59	OPEN	t	\N	\N	\N	2025-11-20 14:52:30	2025-11-20 14:52:30
cmi7jvrg2004pipqmg7jc2l9s	June 2025	2025-06	MONTHLY	2025-06-01 00:00:00	2025-06-30 23:59:59	OPEN	t	\N	\N	\N	2025-11-20 14:52:30.003	2025-11-20 14:52:30.003
cmi7jvrg5004qipqmv6yndr0x	July 2025	2025-07	MONTHLY	2025-07-01 00:00:00	2025-07-31 23:59:59	OPEN	t	\N	\N	\N	2025-11-20 14:52:30.006	2025-11-20 14:52:30.006
cmi7jvrg8004ripqmh5z66qk3	August 2025	2025-08	MONTHLY	2025-08-01 00:00:00	2025-08-31 23:59:59	OPEN	t	\N	\N	\N	2025-11-20 14:52:30.008	2025-11-20 14:52:30.008
cmi7jvrgb004sipqmhl6tsivc	September 2025	2025-09	MONTHLY	2025-09-01 00:00:00	2025-09-30 23:59:59	OPEN	t	\N	\N	\N	2025-11-20 14:52:30.011	2025-11-20 14:52:30.011
cmi7jvrge004tipqmva1sgiln	October 2025	2025-10	MONTHLY	2025-10-01 00:00:00	2025-10-31 23:59:59	OPEN	t	\N	\N	\N	2025-11-20 14:52:30.014	2025-11-20 14:52:30.014
cmi7jvrgh004uipqmrvmewgto	November 2025	2025-11	MONTHLY	2025-11-01 00:00:00	2025-11-30 23:59:59	OPEN	t	\N	\N	\N	2025-11-20 14:52:30.017	2025-11-20 14:52:30.017
cmi7jvrgj004vipqml7mopu3f	December 2025	2025-12	MONTHLY	2025-12-01 00:00:00	2025-12-31 23:59:59	OPEN	t	\N	\N	\N	2025-11-20 14:52:30.02	2025-11-20 14:52:30.02
\.


--
-- Data for Name: frame_comments; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.frame_comments (id, "frameId", text, x, y, "parentId", "authorId", mentions, resolved, "resolvedBy", "resolvedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: frame_drawings; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.frame_drawings (id, "frameId", type, data, "createdBy", "createdAt") FROM stdin;
\.


--
-- Data for Name: general_ledger; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.general_ledger (id, "accountId", "entryDate", "postingDate", "journalEntryId", "journalEntryNumber", "lineNumber", debit, credit, balance, description, "descriptionId", "transactionType", "transactionId", "documentNumber", "projectId", "clientId", "fiscalPeriodId", "createdAt") FROM stdin;
\.


--
-- Data for Name: goods_receipt_items; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.goods_receipt_items (id, "grId", "poItemId", "lineNumber", "orderedQuantity", "receivedQuantity", "acceptedQuantity", "rejectedQuantity", "qualityStatus", "rejectionReason", "unitPrice", "lineTotal", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: goods_receipts; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.goods_receipts (id, "grNumber", "grDate", "poId", "vendorId", "deliveryNoteNumber", "receivedBy", "receivedAt", "warehouseLocation", "inspectionStatus", "inspectedBy", "inspectedAt", "inspectionNotes", status, "isPosted", "postedAt", notes, "notesId", "createdAt", "updatedAt", "createdBy", "updatedBy", "journalEntryId") FROM stdin;
\.


--
-- Data for Name: indonesian_holidays; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.indonesian_holidays (id, date, year, name, "nameIndonesian", description, type, region, "isLunarBased", "isSubstitute", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: invoice_counters; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.invoice_counters (id, year, month, sequence, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.invoices (id, "invoiceNumber", "creationDate", "dueDate", "quotationId", "clientId", "projectId", "amountPerProject", "totalAmount", "subtotalAmount", "taxRate", "taxAmount", "includeTax", "scopeOfWork", "priceBreakdown", "paymentInfo", "materaiRequired", "materaiApplied", "materaiAppliedAt", "materaiAppliedBy", "materaiAmount", terms, signature, status, "createdBy", "markedPaidBy", "markedPaidAt", "journalEntryId", "paymentJournalId", "paymentMilestoneId", "projectMilestoneId", "createdAt", "updatedAt") FROM stdin;
invoice-1	INV-202501-001	2025-01-10 00:00:00	2025-02-09 00:00:00	quotation-1	client-1	project-1	75000000.00	75000000.00	\N	\N	\N	f	\N	\N	Bank BCA: 1234567890 a.n. Sistem Manajemen Bisnis\nBank Mandiri: 0987654321 a.n. Sistem Manajemen Bisnis\nBank BNI: 1122334455 a.n. Sistem Manajemen Bisnis	t	t	\N	\N	\N	Pembayaran dapat dilakukan dalam 3 termin:\n- 30% setelah kontrak ditandatangani\n- 40% setelah development selesai\n- 30% setelah testing dan deployment	\N	SENT	cmi204j490000gecr55vtk127	\N	\N	\N	\N	\N	\N	2025-11-20 14:52:30.06	2025-11-20 14:52:30.06
invoice-2	INV-202501-002	2025-01-11 00:00:00	2025-02-10 00:00:00	quotation-2	client-2	project-2	15000000.00	15000000.00	\N	\N	\N	f	\N	\N	Bank BCA: 1234567890 a.n. Sistem Manajemen Bisnis\nBank Mandiri: 0987654321 a.n. Sistem Manajemen Bisnis\nBank BNI: 1122334455 a.n. Sistem Manajemen Bisnis	t	f	\N	\N	\N	Pembayaran bulanan di awal bulan.\nRevisi unlimited selama periode kontrak.	\N	PAID	cmi204j490000gecr55vtk127	\N	\N	\N	\N	\N	\N	2025-11-20 14:52:30.079	2025-11-20 14:52:30.079
invoice-3	INV-202501-003	2025-01-12 00:00:00	2025-02-11 00:00:00	\N	client-1	project-1	2500000.00	2500000.00	\N	\N	\N	f	\N	\N	Bank BCA: 1234567890 a.n. Sistem Manajemen Bisnis\nBank Mandiri: 0987654321 a.n. Sistem Manajemen Bisnis	f	f	\N	\N	\N	Pembayaran tambahan untuk fitur ekstra yang diminta klien.	\N	DRAFT	cmi204j4i0001gecr1cfd4x38	\N	\N	\N	\N	\N	\N	2025-11-20 14:52:30.087	2025-11-20 14:52:30.087
\.


--
-- Data for Name: journal_entries; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.journal_entries (id, "entryNumber", "entryDate", "postingDate", description, "descriptionId", "descriptionEn", "transactionType", "transactionId", "documentNumber", "documentDate", status, "isPosted", "postedAt", "postedBy", "fiscalPeriodId", "isReversing", "reversedEntryId", "createdBy", "updatedBy", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: journal_line_items; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.journal_line_items (id, "journalEntryId", "lineNumber", "accountId", debit, credit, description, "descriptionId", "projectId", "clientId", "departmentId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: labor_entries; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.labor_entries (id, "projectId", "teamMemberId", "userId", "workDate", "hoursWorked", "laborType", "laborTypeRate", "hourlyRate", "laborCost", "costType", "isDirect", description, "descriptionId", "taskPerformed", status, "submittedAt", "approvedBy", "approvedAt", "rejectedReason", "expenseId", "journalEntryId", "costAllocationId", "createdAt", "updatedAt", "createdBy", "updatedBy") FROM stdin;
\.


--
-- Data for Name: maintenance_records; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.maintenance_records (id, "assetId", "maintenanceType", "performedDate", "performedBy", cost, description, "partsReplaced", "nextMaintenanceDate", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: maintenance_schedules; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.maintenance_schedules (id, "assetId", "maintenanceType", frequency, "lastMaintenanceDate", "nextMaintenanceDate", "isActive", notes, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: media_assets; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.media_assets (id, "projectId", filename, "originalName", description, url, key, "thumbnailUrl", "mediaType", "mimeType", size, duration, fps, codec, bitrate, width, height, status, "starRating", "uploadedBy", "uploadedAt", "updatedAt", "folderId") FROM stdin;
cmi2cces8000598jkkw9wqzd3	cmi2bfiz30003bcnso9b0890a	content/2025-11-16/6373a9b5-21oct_gtt_tt1.mp4	21OCT_GTT_TT1.mp4	\N	/api/v1/media/proxy/content/2025-11-16/6373a9b5-21oct_gtt_tt1.mp4	content/2025-11-16/6373a9b5-21oct_gtt_tt1.mp4	/api/v1/media/proxy/thumbnails/2025-11-16/0e5c436e-thumb-21oct_gtt_tt1-mp4.jpg	VIDEO	video/mp4	13113412	10.286	30.00	h264	10199	1080	1920	DRAFT	1	cmi204j490000gecr55vtk127	2025-11-16 23:22:38.936	2025-11-17 14:06:40.874	\N
cmi2cc8gh000198jkv0d1jsi2	cmi2bfiz30003bcnso9b0890a	content/2025-11-16/4d888c70-4oct_gtt_poster_aar3.jpg	4OCT_GTT_POSTER_AAR3.jpg	\N	/api/v1/media/proxy/content/2025-11-16/4d888c70-4oct_gtt_poster_aar3.jpg	content/2025-11-16/4d888c70-4oct_gtt_poster_aar3.jpg	/api/v1/media/proxy/thumbnails/2025-11-16/84cb801c-thumb-4oct_gtt_poster_aar3.jpg	IMAGE	image/jpeg	283245	\N	\N	\N	\N	1080	1080	IN_REVIEW	1	cmi204j490000gecr55vtk127	2025-11-16 23:22:30.737	2025-11-17 14:06:43.35	\N
cmi2bfwbv0007bcnsbfn3hlwy	cmi2bfiz30003bcnso9b0890a	content/2025-11-16/926454e5-facebook-ads-report-2025-07-20-1249x1359.png	facebook-ads-report-2025-07-20-1249x1359.png	\N	/api/v1/media/proxy/content/2025-11-16/926454e5-facebook-ads-report-2025-07-20-1249x1359.png	content/2025-11-16/926454e5-facebook-ads-report-2025-07-20-1249x1359.png	/api/v1/media/proxy/thumbnails/2025-11-16/b20a4288-thumb-facebook-ads-report-2025-07-20-1249x1359.png	IMAGE	image/png	609867	\N	\N	\N	\N	2498	2718	IN_REVIEW	1	cmi204j490000gecr55vtk127	2025-11-16 22:57:22.027	2025-11-17 14:06:45.192	\N
\.


--
-- Data for Name: media_collaborators; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.media_collaborators (id, "projectId", "userId", role, "invitedBy", "addedAt", "guestEmail", "guestName", "inviteToken", status, "lastAccessAt", "expiresAt", "updatedAt") FROM stdin;
cmi2bfizm0005bcnsplqzg3o0	cmi2bfiz30003bcnso9b0890a	cmi204j490000gecr55vtk127	OWNER	cmi204j490000gecr55vtk127	2025-11-16 22:57:04.738	\N	\N	\N	ACCEPTED	\N	\N	2025-11-17 07:11:45.65
\.


--
-- Data for Name: media_folders; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.media_folders (id, name, "parentId", "createdAt", "updatedAt", "createdById", description, "projectId") FROM stdin;
cmi2z68sd0001bah42jnn3db6	10	\N	2025-11-17 10:01:42.397	2025-11-17 10:01:42.397	cmi204j490000gecr55vtk127	\N	cmi2bfiz30003bcnso9b0890a
\.


--
-- Data for Name: media_frames; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.media_frames (id, "assetId", "timestamp", "frameNumber", x, y, "thumbnailUrl", "createdBy", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: media_projects; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.media_projects (id, name, description, "clientId", "projectId", "folderId", "createdBy", "createdAt", "updatedAt", "isPublic", "publicShareToken", "publicShareUrl", "publicViewCount", "publicSharedAt", "publicAccessLevel") FROM stdin;
cmi2bfiz30003bcnso9b0890a	monomi-finance	\N	\N	\N	\N	cmi204j490000gecr55vtk127	2025-11-16 22:57:04.718	2025-11-18 22:32:03.808	t	WtJwM18nvo3DiStDLHi4kQ	http://localhost:3001/shared/WtJwM18nvo3DiStDLHi4kQ	37	2025-11-17 07:47:50.274	VIEW_ONLY
\.


--
-- Data for Name: media_versions; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.media_versions (id, "assetId", "versionNumber", filename, url, key, "thumbnailUrl", size, duration, width, height, "changeNotes", "uploadedBy", "uploadedAt") FROM stdin;
\.


--
-- Data for Name: payment_milestones; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.payment_milestones (id, "quotationId", "milestoneNumber", name, "nameId", description, "descriptionId", "paymentPercentage", "paymentAmount", "dueDate", "dueDaysFromPrev", deliverables, "isInvoiced", "projectMilestoneId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.payments (id, "invoiceId", amount, "paymentDate", "paymentMethod", "transactionRef", "bankDetails", status, "confirmedAt", "journalEntryId", "createdAt", "updatedAt") FROM stdin;
payment-1	invoice-2	15000000.00	2025-01-15 00:00:00	BANK_TRANSFER	TRX-20250115-001	Transfer dari Bank BCA rekening 9876543210 a.n. CV Kreatif Digital	CONFIRMED	2025-01-15 00:00:00	\N	2025-11-20 14:52:30.094	2025-11-20 14:52:30.094
\.


--
-- Data for Name: project_cost_allocations; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.project_cost_allocations (id, "projectId", "expenseId", "allocationDate", "allocationMethod", "allocationPercentage", "allocatedAmount", "journalEntryId", "costType", "isDirect", notes, "notesId", "createdAt", "updatedAt", "createdBy") FROM stdin;
\.


--
-- Data for Name: project_equipment_usage; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.project_equipment_usage (id, "projectId", "assetId", "startDate", "endDate", "returnDate", condition, notes, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: project_milestones; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.project_milestones (id, "projectId", "milestoneNumber", name, "nameId", description, "descriptionId", "plannedStartDate", "plannedEndDate", "actualStartDate", "actualEndDate", "completionPercentage", "plannedRevenue", "recognizedRevenue", "remainingRevenue", "estimatedCost", "actualCost", status, deliverables, "acceptedBy", "acceptedAt", "journalEntryId", notes, "notesId", priority, "predecessorId", "delayDays", "delayReason", "materaiRequired", "taxTreatment", "createdAt", "updatedAt", "createdBy") FROM stdin;
\.


--
-- Data for Name: project_team_members; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.project_team_members (id, "projectId", "userId", role, "roleId", "allocationPercent", "hourlyRate", "hourlyRateCurrency", "assignedDate", "startDate", "endDate", "isActive", notes, "notesId", "createdAt", "updatedAt", "createdBy", "updatedBy") FROM stdin;
\.


--
-- Data for Name: project_type_configs; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.project_type_configs (id, code, name, description, prefix, color, "isDefault", "isActive", "sortOrder", "createdAt", "updatedAt") FROM stdin;
cmi204j680008gecraygg2ste	PRODUCTION	Production Work	Website development, software development, and other production tasks	PH	#52c41a	t	t	1	2025-11-16 17:40:35.984	2025-11-16 17:40:35.984
cmi204j6f0009gecrcbl3jot5	SOCIAL_MEDIA	Social Media Management	Content creation, social media management, and digital marketing	SM	#1890ff	f	t	2	2025-11-16 17:40:35.991	2025-11-16 17:40:35.991
cmi204j6k000agecrquf012e9	CONSULTATION	Consultation Services	Business consultation, technical consultation, and advisory services	CS	#722ed1	f	t	3	2025-11-16 17:40:35.996	2025-11-16 17:40:35.996
cmi204j6p000bgecratycy7ox	MAINTENANCE	Maintenance & Support	System maintenance, bug fixes, and technical support	MT	#fa8c16	f	t	4	2025-11-16 17:40:36.002	2025-11-16 17:40:36.002
cmi204j6v000cgecrb17aahat	OTHER	Other Services	Miscellaneous services and custom projects	OT	#595959	f	t	5	2025-11-16 17:40:36.007	2025-11-16 17:40:36.007
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.projects (id, number, description, "scopeOfWork", output, "projectTypeId", "clientId", "startDate", "endDate", "estimatedBudget", "basePrice", "priceBreakdown", "estimatedExpenses", "projectedGrossMargin", "projectedNetMargin", "projectedProfit", "totalDirectCosts", "totalIndirectCosts", "totalAllocatedCosts", "totalInvoicedAmount", "totalPaidAmount", "grossProfit", "netProfit", "grossMarginPercent", "netMarginPercent", "budgetVariance", "budgetVariancePercent", "profitCalculatedAt", "profitCalculatedBy", status, "createdAt", "updatedAt") FROM stdin;
project-1	PRJ-PH-202501-001	Pembuatan Website E-commerce	\N	Website e-commerce lengkap dengan dashboard admin, sistem pembayaran, dan mobile responsive	cmi204j680008gecraygg2ste	client-1	2025-01-01 00:00:00	2025-03-31 00:00:00	75000000.00	75000000.00	{"design": 15000000, "testing": 10000000, "deployment": 5000000, "development": 45000000}	\N	\N	\N	\N	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	\N	\N	\N	IN_PROGRESS	2025-11-20 14:52:30.023	2025-11-20 14:52:30.023
project-2	PRJ-SM-202501-001	Konten Media Sosial Januari-Maret	\N	Konten Instagram, Facebook, dan TikTok untuk 3 bulan (90 post + 30 stories)	cmi204j6f0009gecrcbl3jot5	client-2	2025-01-01 00:00:00	2025-03-31 00:00:00	15000000.00	15000000.00	{"reporting": 2000000, "scheduling": 3000000, "contentCreation": 10000000}	\N	\N	\N	\N	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	\N	\N	\N	IN_PROGRESS	2025-11-20 14:52:30.028	2025-11-20 14:52:30.028
project-3	PRJ-PH-202501-002	Sistem Inventory Management	\N	Aplikasi desktop untuk manajemen stok, laporan penjualan, dan integrasi barcode	cmi204j680008gecraygg2ste	client-3	2025-02-01 00:00:00	2025-05-31 00:00:00	120000000.00	120000000.00	{"testing": 15000000, "analysis": 20000000, "training": 5000000, "development": 80000000}	\N	\N	\N	\N	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	\N	\N	\N	PLANNING	2025-11-20 14:52:30.032	2025-11-20 14:52:30.032
\.


--
-- Data for Name: purchase_order_items; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.purchase_order_items (id, "poId", "lineNumber", "itemType", "itemCode", description, "descriptionId", quantity, unit, "unitPrice", "discountPercent", "discountAmount", "lineTotal", "ppnAmount", "quantityReceived", "quantityInvoiced", "quantityOutstanding", "assetId", "expenseCategoryId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: purchase_orders; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.purchase_orders (id, "poNumber", "poDate", "vendorId", "projectId", subtotal, "discountAmount", "ppnAmount", "pphAmount", "totalAmount", "isPPNIncluded", "ppnRate", "withholdingTaxType", "withholdingTaxRate", "deliveryAddress", "deliveryDate", "paymentTerms", "dueDate", status, "approvalStatus", "requestedBy", "approvedBy", "approvedAt", "rejectedBy", "rejectedAt", "rejectionReason", "totalReceived", "totalInvoiced", "isClosed", "closedAt", "closedBy", "closureReason", description, "descriptionId", notes, "termsConditions", "createdAt", "updatedAt", "createdBy", "updatedBy", "journalEntryId") FROM stdin;
\.


--
-- Data for Name: quotation_counters; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.quotation_counters (id, year, month, sequence, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: quotations; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.quotations (id, "quotationNumber", date, "validUntil", "clientId", "projectId", "amountPerProject", "totalAmount", "scopeOfWork", "priceBreakdown", terms, "paymentType", "paymentTermsText", status, "createdBy", "approvedBy", "approvedAt", "rejectedBy", "rejectedAt", "createdAt", "updatedAt") FROM stdin;
quotation-1	QT-202501-001	2025-01-05 00:00:00	2025-01-20 00:00:00	client-1	project-1	75000000.00	75000000.00	\N	\N	Pembayaran dapat dilakukan dalam 3 termin:\n- 30% setelah kontrak ditandatangani\n- 40% setelah development selesai\n- 30% setelah testing dan deployment	FULL_PAYMENT	\N	APPROVED	cmi204j490000gecr55vtk127	\N	\N	\N	\N	2025-11-20 14:52:30.036	2025-11-20 14:52:30.036
quotation-2	QT-202501-002	2025-01-06 00:00:00	2025-01-21 00:00:00	client-2	project-2	15000000.00	15000000.00	\N	\N	Pembayaran bulanan di awal bulan.\nRevisi unlimited selama periode kontrak.	FULL_PAYMENT	\N	APPROVED	cmi204j490000gecr55vtk127	\N	\N	\N	\N	2025-11-20 14:52:30.041	2025-11-20 14:52:30.041
quotation-3	QT-202501-003	2025-01-07 00:00:00	2025-01-22 00:00:00	client-3	project-3	120000000.00	120000000.00	\N	\N	Pembayaran bertahap:\n- 40% setelah kontrak\n- 30% setelah analisis dan design\n- 20% setelah development\n- 10% setelah testing dan training	FULL_PAYMENT	\N	SENT	cmi204j490000gecr55vtk127	\N	\N	\N	\N	2025-11-20 14:52:30.046	2025-11-20 14:52:30.046
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.refresh_tokens (id, token, "userId", "expiresAt", "createdAt", "lastUsedAt", "isRevoked", "revokedAt", "revokedReason", "userAgent", "ipAddress", "deviceId", "replacedBy") FROM stdin;
cmi7o5w1o00037y4blr7gp20n	4d5f3324cc488879c1384cb08c5bdad41573fc67497402f0e5e0d6b0e43f889ac59c87ccf3a6a195fd9541e26d4478496aabb8ec2783fb95c46a9623a621c19e	cmi204j490000gecr55vtk127	2025-12-20 16:52:20.986	2025-11-20 16:52:20.987	2025-11-20 16:52:20.987	f	\N	\N	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	127.0.0.1	\N	\N
cmi7no3ia00017y4b9fxsyuil	5fb22e446ccc0256b73c75d8aa2ea4de78ca8111912b7143062a942c41baa85f10d64b62a15a9e293f612f8835415b2ba0b67f48c3793b14d73b8cbbcb0c5a11	cmi204j490000gecr55vtk127	2025-12-20 16:38:30.849	2025-11-20 16:38:30.85	2025-11-20 16:52:20.977	t	2025-11-20 16:52:20.998	replaced	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	127.0.0.1	\N	4d5f3324cc488879c1384cb08c5bdad41573fc67497402f0e5e0d6b0e43f889ac59c87ccf3a6a195fd9541e26d4478496aabb8ec2783fb95c46a9623a621c19e
\.


--
-- Data for Name: report_sections; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.report_sections (id, "reportId", "order", title, description, "csvFileName", "csvFilePath", "importedAt", "columnTypes", "rawData", "rowCount", visualizations, "createdAt", "updatedAt", layout, "layoutVersion") FROM stdin;
\.


--
-- Data for Name: social_media_reports; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.social_media_reports (id, "projectId", title, description, month, year, status, "pdfUrl", "pdfGeneratedAt", "pdfVersion", "emailedAt", "emailedTo", "createdAt", "updatedAt", "createdBy", "updatedBy") FROM stdin;
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.system_settings (id, "defaultPaymentTerms", "materaiThreshold", "invoicePrefix", "quotationPrefix", "autoBackup", "backupFrequency", "backupTime", "autoMateraiReminder", "defaultCurrency", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: user_preferences; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.user_preferences (id, "userId", timezone, language, currency, "emailNotifications", "pushNotifications", theme, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.users (id, email, password, name, role, "isActive", "createdAt", "updatedAt") FROM stdin;
cmi204j490000gecr55vtk127	admin@monomi.id	$2b$10$CnAzaVf/iOt/DcK0qkYaqO3EZo8byqQxWqspxrDGU5e0QgSvX5TAa	Admin Sistem (Legacy)	ADMIN	t	2025-11-16 17:40:35.914	2025-11-16 17:40:35.914
cmi204j4i0001gecr1cfd4x38	user@bisnis.co.id	$2b$10$CnAzaVf/iOt/DcK0qkYaqO3EZo8byqQxWqspxrDGU5e0QgSvX5TAa	User Bisnis (Legacy)	USER	t	2025-11-16 17:40:35.922	2025-11-16 17:40:35.922
cmi204j4p0002gecr9a9g1wmw	super.admin@monomi.id	$2b$10$j/wtTHZy4wgSCGoeGnpVAu1R6iWAmgvNQRA/tHPQb6Ctj0Ki/Fqlq	Super Admin	SUPER_ADMIN	t	2025-11-16 17:40:35.929	2025-11-16 17:40:35.929
cmi204j4u0003gecrety1toct	finance.manager@monomi.id	$2b$10$j/wtTHZy4wgSCGoeGnpVAu1R6iWAmgvNQRA/tHPQb6Ctj0Ki/Fqlq	Finance Manager	FINANCE_MANAGER	t	2025-11-16 17:40:35.935	2025-11-16 17:40:35.935
cmi204j500004gecrpxa6up16	accountant@monomi.id	$2b$10$j/wtTHZy4wgSCGoeGnpVAu1R6iWAmgvNQRA/tHPQb6Ctj0Ki/Fqlq	Accountant	ACCOUNTANT	t	2025-11-16 17:40:35.94	2025-11-16 17:40:35.94
cmi204j550005gecrn0vy1af2	project.manager@monomi.id	$2b$10$j/wtTHZy4wgSCGoeGnpVAu1R6iWAmgvNQRA/tHPQb6Ctj0Ki/Fqlq	Project Manager	PROJECT_MANAGER	t	2025-11-16 17:40:35.945	2025-11-16 17:40:35.945
cmi204j5a0006gecrdozpf5zx	staff@monomi.id	$2b$10$j/wtTHZy4wgSCGoeGnpVAu1R6iWAmgvNQRA/tHPQb6Ctj0Ki/Fqlq	Staff User	STAFF	t	2025-11-16 17:40:35.951	2025-11-16 17:40:35.951
cmi204j5f0007gecrgezynr3f	viewer@monomi.id	$2b$10$j/wtTHZy4wgSCGoeGnpVAu1R6iWAmgvNQRA/tHPQb6Ctj0Ki/Fqlq	Viewer	VIEWER	t	2025-11-16 17:40:35.956	2025-11-16 17:40:35.956
\.


--
-- Data for Name: ux_metrics; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.ux_metrics (id, "componentName", "eventType", "metricName", value, "userId", "sessionId", "clientId", url, "userAgent", "performanceData", "createdAt") FROM stdin;
\.


--
-- Data for Name: vendor_invoice_items; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.vendor_invoice_items (id, "viId", "poItemId", "lineNumber", description, "descriptionId", quantity, unit, "unitPrice", "discountAmount", "lineTotal", "ppnAmount", "isMatched", "varianceReason", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: vendor_invoices; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.vendor_invoices (id, "vendorInvoiceNumber", "internalNumber", "invoiceDate", "vendorId", "poId", "grId", subtotal, "discountAmount", "ppnAmount", "pphAmount", "totalAmount", "eFakturNSFP", "eFakturQRCode", "eFakturStatus", "eFakturUploadDate", "paymentTerms", "dueDate", "matchingStatus", "matchedBy", "matchedAt", "matchingNotes", "priceVariance", "quantityVariance", "withinTolerance", status, "approvalStatus", "approvedBy", "approvedAt", "rejectedBy", "rejectedAt", "rejectionReason", "accountsPayableId", "journalEntryId", description, "descriptionId", notes, "createdAt", "updatedAt", "createdBy", "updatedBy") FROM stdin;
\.


--
-- Data for Name: vendor_payment_allocations; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.vendor_payment_allocations (id, "paymentId", "apId", "allocatedAmount", "createdAt") FROM stdin;
\.


--
-- Data for Name: vendor_payments; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.vendor_payments (id, "paymentNumber", "paymentDate", "vendorId", "paymentMethod", "referenceNumber", "bankAccountId", "totalAmount", status, "clearedAt", "journalEntryId", notes, "notesId", "createdAt", "updatedAt", "createdBy", "updatedBy") FROM stdin;
\.


--
-- Data for Name: vendors; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.vendors (id, "vendorCode", name, "nameId", "vendorType", "industryType", "contactPerson", email, phone, address, city, province, "postalCode", country, npwp, "pkpStatus", "taxAddress", "bankName", "bankAccountNumber", "bankAccountName", "bankBranch", "swiftCode", "paymentTerms", "creditLimit", currency, "isActive", "isPKP", "createdAt", "updatedAt", "createdBy", "updatedBy") FROM stdin;
\.


--
-- Data for Name: work_in_progress; Type: TABLE DATA; Schema: public; Owner: invoiceuser
--

COPY public.work_in_progress (id, "projectId", "periodDate", "fiscalPeriodId", "directMaterialCost", "directLaborCost", "directExpenses", "allocatedOverhead", "totalCost", "billedToDate", "recognizedRevenue", "unbilledRevenue", "completionPercentage", "isCompleted", "costJournalId", "revenueJournalId", notes, "notesId", "createdAt", "updatedAt", "createdBy") FROM stdin;
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: account_balances account_balances_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.account_balances
    ADD CONSTRAINT account_balances_pkey PRIMARY KEY (id);


--
-- Name: accounts_payable accounts_payable_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.accounts_payable
    ADD CONSTRAINT accounts_payable_pkey PRIMARY KEY (id);


--
-- Name: allowance_for_doubtful_accounts allowance_for_doubtful_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.allowance_for_doubtful_accounts
    ADD CONSTRAINT allowance_for_doubtful_accounts_pkey PRIMARY KEY (id);


--
-- Name: asset_kit_items asset_kit_items_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.asset_kit_items
    ADD CONSTRAINT asset_kit_items_pkey PRIMARY KEY (id);


--
-- Name: asset_kits asset_kits_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.asset_kits
    ADD CONSTRAINT asset_kits_pkey PRIMARY KEY (id);


--
-- Name: asset_metadata asset_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.asset_metadata
    ADD CONSTRAINT asset_metadata_pkey PRIMARY KEY (id);


--
-- Name: asset_reservations asset_reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.asset_reservations
    ADD CONSTRAINT asset_reservations_pkey PRIMARY KEY (id);


--
-- Name: assets assets_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: bank_reconciliation_items bank_reconciliation_items_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.bank_reconciliation_items
    ADD CONSTRAINT bank_reconciliation_items_pkey PRIMARY KEY (id);


--
-- Name: bank_reconciliations bank_reconciliations_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.bank_reconciliations
    ADD CONSTRAINT bank_reconciliations_pkey PRIMARY KEY (id);


--
-- Name: bank_transfers bank_transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.bank_transfers
    ADD CONSTRAINT bank_transfers_pkey PRIMARY KEY (id);


--
-- Name: business_journey_event_metadata business_journey_event_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.business_journey_event_metadata
    ADD CONSTRAINT business_journey_event_metadata_pkey PRIMARY KEY (id);


--
-- Name: business_journey_events business_journey_events_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.business_journey_events
    ADD CONSTRAINT business_journey_events_pkey PRIMARY KEY (id);


--
-- Name: cash_bank_balances cash_bank_balances_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.cash_bank_balances
    ADD CONSTRAINT cash_bank_balances_pkey PRIMARY KEY (id);


--
-- Name: cash_transactions cash_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.cash_transactions
    ADD CONSTRAINT cash_transactions_pkey PRIMARY KEY (id);


--
-- Name: chart_of_accounts chart_of_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.chart_of_accounts
    ADD CONSTRAINT chart_of_accounts_pkey PRIMARY KEY (id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: collection_items collection_items_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.collection_items
    ADD CONSTRAINT collection_items_pkey PRIMARY KEY (id);


--
-- Name: collections collections_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.collections
    ADD CONSTRAINT collections_pkey PRIMARY KEY (id);


--
-- Name: company_settings company_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.company_settings
    ADD CONSTRAINT company_settings_pkey PRIMARY KEY (id);


--
-- Name: content_calendar_items content_calendar_items_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.content_calendar_items
    ADD CONSTRAINT content_calendar_items_pkey PRIMARY KEY (id);


--
-- Name: content_media content_media_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.content_media
    ADD CONSTRAINT content_media_pkey PRIMARY KEY (id);


--
-- Name: deferred_revenue deferred_revenue_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.deferred_revenue
    ADD CONSTRAINT deferred_revenue_pkey PRIMARY KEY (id);


--
-- Name: depreciation_entries depreciation_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.depreciation_entries
    ADD CONSTRAINT depreciation_entries_pkey PRIMARY KEY (id);


--
-- Name: depreciation_schedules depreciation_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.depreciation_schedules
    ADD CONSTRAINT depreciation_schedules_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: exchange_rates exchange_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.exchange_rates
    ADD CONSTRAINT exchange_rates_pkey PRIMARY KEY (id);


--
-- Name: expense_approval_history expense_approval_history_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.expense_approval_history
    ADD CONSTRAINT expense_approval_history_pkey PRIMARY KEY (id);


--
-- Name: expense_budgets expense_budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.expense_budgets
    ADD CONSTRAINT expense_budgets_pkey PRIMARY KEY (id);


--
-- Name: expense_categories expense_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.expense_categories
    ADD CONSTRAINT expense_categories_pkey PRIMARY KEY (id);


--
-- Name: expense_comments expense_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.expense_comments
    ADD CONSTRAINT expense_comments_pkey PRIMARY KEY (id);


--
-- Name: expense_documents expense_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.expense_documents
    ADD CONSTRAINT expense_documents_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: feature_flag_events feature_flag_events_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.feature_flag_events
    ADD CONSTRAINT feature_flag_events_pkey PRIMARY KEY (id);


--
-- Name: feature_flags feature_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.feature_flags
    ADD CONSTRAINT feature_flags_pkey PRIMARY KEY (id);


--
-- Name: financial_statements financial_statements_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.financial_statements
    ADD CONSTRAINT financial_statements_pkey PRIMARY KEY (id);


--
-- Name: fiscal_periods fiscal_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.fiscal_periods
    ADD CONSTRAINT fiscal_periods_pkey PRIMARY KEY (id);


--
-- Name: frame_comments frame_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.frame_comments
    ADD CONSTRAINT frame_comments_pkey PRIMARY KEY (id);


--
-- Name: frame_drawings frame_drawings_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.frame_drawings
    ADD CONSTRAINT frame_drawings_pkey PRIMARY KEY (id);


--
-- Name: general_ledger general_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.general_ledger
    ADD CONSTRAINT general_ledger_pkey PRIMARY KEY (id);


--
-- Name: goods_receipt_items goods_receipt_items_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.goods_receipt_items
    ADD CONSTRAINT goods_receipt_items_pkey PRIMARY KEY (id);


--
-- Name: goods_receipts goods_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.goods_receipts
    ADD CONSTRAINT goods_receipts_pkey PRIMARY KEY (id);


--
-- Name: indonesian_holidays indonesian_holidays_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.indonesian_holidays
    ADD CONSTRAINT indonesian_holidays_pkey PRIMARY KEY (id);


--
-- Name: invoice_counters invoice_counters_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.invoice_counters
    ADD CONSTRAINT invoice_counters_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: journal_entries journal_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_pkey PRIMARY KEY (id);


--
-- Name: journal_line_items journal_line_items_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.journal_line_items
    ADD CONSTRAINT journal_line_items_pkey PRIMARY KEY (id);


--
-- Name: labor_entries labor_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.labor_entries
    ADD CONSTRAINT labor_entries_pkey PRIMARY KEY (id);


--
-- Name: maintenance_records maintenance_records_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.maintenance_records
    ADD CONSTRAINT maintenance_records_pkey PRIMARY KEY (id);


--
-- Name: maintenance_schedules maintenance_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.maintenance_schedules
    ADD CONSTRAINT maintenance_schedules_pkey PRIMARY KEY (id);


--
-- Name: media_assets media_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.media_assets
    ADD CONSTRAINT media_assets_pkey PRIMARY KEY (id);


--
-- Name: media_collaborators media_collaborators_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.media_collaborators
    ADD CONSTRAINT media_collaborators_pkey PRIMARY KEY (id);


--
-- Name: media_folders media_folders_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.media_folders
    ADD CONSTRAINT media_folders_pkey PRIMARY KEY (id);


--
-- Name: media_frames media_frames_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.media_frames
    ADD CONSTRAINT media_frames_pkey PRIMARY KEY (id);


--
-- Name: media_projects media_projects_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.media_projects
    ADD CONSTRAINT media_projects_pkey PRIMARY KEY (id);


--
-- Name: media_versions media_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.media_versions
    ADD CONSTRAINT media_versions_pkey PRIMARY KEY (id);


--
-- Name: payment_milestones payment_milestones_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.payment_milestones
    ADD CONSTRAINT payment_milestones_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: project_cost_allocations project_cost_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.project_cost_allocations
    ADD CONSTRAINT project_cost_allocations_pkey PRIMARY KEY (id);


--
-- Name: project_equipment_usage project_equipment_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.project_equipment_usage
    ADD CONSTRAINT project_equipment_usage_pkey PRIMARY KEY (id);


--
-- Name: project_milestones project_milestones_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.project_milestones
    ADD CONSTRAINT project_milestones_pkey PRIMARY KEY (id);


--
-- Name: project_team_members project_team_members_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.project_team_members
    ADD CONSTRAINT project_team_members_pkey PRIMARY KEY (id);


--
-- Name: project_type_configs project_type_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.project_type_configs
    ADD CONSTRAINT project_type_configs_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: purchase_order_items purchase_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_pkey PRIMARY KEY (id);


--
-- Name: quotation_counters quotation_counters_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.quotation_counters
    ADD CONSTRAINT quotation_counters_pkey PRIMARY KEY (id);


--
-- Name: quotations quotations_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: report_sections report_sections_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.report_sections
    ADD CONSTRAINT report_sections_pkey PRIMARY KEY (id);


--
-- Name: social_media_reports social_media_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.social_media_reports
    ADD CONSTRAINT social_media_reports_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: user_preferences user_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.user_preferences
    ADD CONSTRAINT user_preferences_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ux_metrics ux_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.ux_metrics
    ADD CONSTRAINT ux_metrics_pkey PRIMARY KEY (id);


--
-- Name: vendor_invoice_items vendor_invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.vendor_invoice_items
    ADD CONSTRAINT vendor_invoice_items_pkey PRIMARY KEY (id);


--
-- Name: vendor_invoices vendor_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.vendor_invoices
    ADD CONSTRAINT vendor_invoices_pkey PRIMARY KEY (id);


--
-- Name: vendor_payment_allocations vendor_payment_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.vendor_payment_allocations
    ADD CONSTRAINT vendor_payment_allocations_pkey PRIMARY KEY (id);


--
-- Name: vendor_payments vendor_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.vendor_payments
    ADD CONSTRAINT vendor_payments_pkey PRIMARY KEY (id);


--
-- Name: vendors vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_pkey PRIMARY KEY (id);


--
-- Name: work_in_progress work_in_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.work_in_progress
    ADD CONSTRAINT work_in_progress_pkey PRIMARY KEY (id);


--
-- Name: account_balances_accountId_fiscalPeriodId_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "account_balances_accountId_fiscalPeriodId_key" ON public.account_balances USING btree ("accountId", "fiscalPeriodId");


--
-- Name: account_balances_accountId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "account_balances_accountId_idx" ON public.account_balances USING btree ("accountId");


--
-- Name: account_balances_fiscalPeriodId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "account_balances_fiscalPeriodId_idx" ON public.account_balances USING btree ("fiscalPeriodId");


--
-- Name: account_balances_isClosed_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "account_balances_isClosed_idx" ON public.account_balances USING btree ("isClosed");


--
-- Name: accounts_payable_agingBucket_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "accounts_payable_agingBucket_idx" ON public.accounts_payable USING btree ("agingBucket");


--
-- Name: accounts_payable_apNumber_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "accounts_payable_apNumber_idx" ON public.accounts_payable USING btree ("apNumber");


--
-- Name: accounts_payable_apNumber_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "accounts_payable_apNumber_key" ON public.accounts_payable USING btree ("apNumber");


--
-- Name: accounts_payable_dueDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "accounts_payable_dueDate_idx" ON public.accounts_payable USING btree ("dueDate");


--
-- Name: accounts_payable_expenseId_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "accounts_payable_expenseId_key" ON public.accounts_payable USING btree ("expenseId");


--
-- Name: accounts_payable_invoiceDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "accounts_payable_invoiceDate_idx" ON public.accounts_payable USING btree ("invoiceDate");


--
-- Name: accounts_payable_paymentStatus_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "accounts_payable_paymentStatus_idx" ON public.accounts_payable USING btree ("paymentStatus");


--
-- Name: accounts_payable_vendorId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "accounts_payable_vendorId_idx" ON public.accounts_payable USING btree ("vendorId");


--
-- Name: accounts_payable_vendorInvoiceId_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "accounts_payable_vendorInvoiceId_key" ON public.accounts_payable USING btree ("vendorInvoiceId");


--
-- Name: allowance_for_doubtful_accounts_agingBucket_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "allowance_for_doubtful_accounts_agingBucket_idx" ON public.allowance_for_doubtful_accounts USING btree ("agingBucket");


--
-- Name: allowance_for_doubtful_accounts_calculationDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "allowance_for_doubtful_accounts_calculationDate_idx" ON public.allowance_for_doubtful_accounts USING btree ("calculationDate");


--
-- Name: allowance_for_doubtful_accounts_daysPastDue_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "allowance_for_doubtful_accounts_daysPastDue_idx" ON public.allowance_for_doubtful_accounts USING btree ("daysPastDue");


--
-- Name: allowance_for_doubtful_accounts_fiscalPeriodId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "allowance_for_doubtful_accounts_fiscalPeriodId_idx" ON public.allowance_for_doubtful_accounts USING btree ("fiscalPeriodId");


--
-- Name: allowance_for_doubtful_accounts_invoiceId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "allowance_for_doubtful_accounts_invoiceId_idx" ON public.allowance_for_doubtful_accounts USING btree ("invoiceId");


--
-- Name: allowance_for_doubtful_accounts_journalEntryId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "allowance_for_doubtful_accounts_journalEntryId_idx" ON public.allowance_for_doubtful_accounts USING btree ("journalEntryId");


--
-- Name: allowance_for_doubtful_accounts_provisionStatus_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "allowance_for_doubtful_accounts_provisionStatus_idx" ON public.allowance_for_doubtful_accounts USING btree ("provisionStatus");


--
-- Name: asset_kit_items_assetId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "asset_kit_items_assetId_idx" ON public.asset_kit_items USING btree ("assetId");


--
-- Name: asset_kit_items_kitId_assetId_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "asset_kit_items_kitId_assetId_key" ON public.asset_kit_items USING btree ("kitId", "assetId");


--
-- Name: asset_kit_items_kitId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "asset_kit_items_kitId_idx" ON public.asset_kit_items USING btree ("kitId");


--
-- Name: asset_kits_isActive_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "asset_kits_isActive_idx" ON public.asset_kits USING btree ("isActive");


--
-- Name: asset_metadata_assetId_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "asset_metadata_assetId_key" ON public.asset_metadata USING btree ("assetId");


--
-- Name: asset_metadata_assigneeId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "asset_metadata_assigneeId_idx" ON public.asset_metadata USING btree ("assigneeId");


--
-- Name: asset_metadata_dueDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "asset_metadata_dueDate_idx" ON public.asset_metadata USING btree ("dueDate");


--
-- Name: asset_metadata_platforms_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX asset_metadata_platforms_idx ON public.asset_metadata USING btree (platforms);


--
-- Name: asset_reservations_assetId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "asset_reservations_assetId_idx" ON public.asset_reservations USING btree ("assetId");


--
-- Name: asset_reservations_assetId_startDate_endDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "asset_reservations_assetId_startDate_endDate_idx" ON public.asset_reservations USING btree ("assetId", "startDate", "endDate");


--
-- Name: asset_reservations_assetId_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "asset_reservations_assetId_status_idx" ON public.asset_reservations USING btree ("assetId", status);


--
-- Name: asset_reservations_endDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "asset_reservations_endDate_idx" ON public.asset_reservations USING btree ("endDate");


--
-- Name: asset_reservations_projectId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "asset_reservations_projectId_idx" ON public.asset_reservations USING btree ("projectId");


--
-- Name: asset_reservations_startDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "asset_reservations_startDate_idx" ON public.asset_reservations USING btree ("startDate");


--
-- Name: asset_reservations_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX asset_reservations_status_idx ON public.asset_reservations USING btree (status);


--
-- Name: asset_reservations_userId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "asset_reservations_userId_idx" ON public.asset_reservations USING btree ("userId");


--
-- Name: assets_assetCode_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "assets_assetCode_idx" ON public.assets USING btree ("assetCode");


--
-- Name: assets_assetCode_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "assets_assetCode_key" ON public.assets USING btree ("assetCode");


--
-- Name: assets_category_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX assets_category_idx ON public.assets USING btree (category);


--
-- Name: assets_category_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX assets_category_status_idx ON public.assets USING btree (category, status);


--
-- Name: assets_condition_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX assets_condition_idx ON public.assets USING btree (condition);


--
-- Name: assets_createdAt_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "assets_createdAt_idx" ON public.assets USING btree ("createdAt");


--
-- Name: assets_createdById_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "assets_createdById_idx" ON public.assets USING btree ("createdById");


--
-- Name: assets_status_condition_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX assets_status_condition_idx ON public.assets USING btree (status, condition);


--
-- Name: assets_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX assets_status_idx ON public.assets USING btree (status);


--
-- Name: bank_reconciliation_items_isMatched_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "bank_reconciliation_items_isMatched_idx" ON public.bank_reconciliation_items USING btree ("isMatched");


--
-- Name: bank_reconciliation_items_itemDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "bank_reconciliation_items_itemDate_idx" ON public.bank_reconciliation_items USING btree ("itemDate");


--
-- Name: bank_reconciliation_items_itemType_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "bank_reconciliation_items_itemType_idx" ON public.bank_reconciliation_items USING btree ("itemType");


--
-- Name: bank_reconciliation_items_reconciliationId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "bank_reconciliation_items_reconciliationId_idx" ON public.bank_reconciliation_items USING btree ("reconciliationId");


--
-- Name: bank_reconciliation_items_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX bank_reconciliation_items_status_idx ON public.bank_reconciliation_items USING btree (status);


--
-- Name: bank_reconciliations_bankAccountId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "bank_reconciliations_bankAccountId_idx" ON public.bank_reconciliations USING btree ("bankAccountId");


--
-- Name: bank_reconciliations_createdAt_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "bank_reconciliations_createdAt_idx" ON public.bank_reconciliations USING btree ("createdAt");


--
-- Name: bank_reconciliations_createdBy_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "bank_reconciliations_createdBy_idx" ON public.bank_reconciliations USING btree ("createdBy");


--
-- Name: bank_reconciliations_isBalanced_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "bank_reconciliations_isBalanced_idx" ON public.bank_reconciliations USING btree ("isBalanced");


--
-- Name: bank_reconciliations_periodStartDate_periodEndDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "bank_reconciliations_periodStartDate_periodEndDate_idx" ON public.bank_reconciliations USING btree ("periodStartDate", "periodEndDate");


--
-- Name: bank_reconciliations_reconciliationNumber_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "bank_reconciliations_reconciliationNumber_idx" ON public.bank_reconciliations USING btree ("reconciliationNumber");


--
-- Name: bank_reconciliations_reconciliationNumber_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "bank_reconciliations_reconciliationNumber_key" ON public.bank_reconciliations USING btree ("reconciliationNumber");


--
-- Name: bank_reconciliations_statementDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "bank_reconciliations_statementDate_idx" ON public.bank_reconciliations USING btree ("statementDate");


--
-- Name: bank_reconciliations_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX bank_reconciliations_status_idx ON public.bank_reconciliations USING btree (status);


--
-- Name: bank_transfers_clientId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "bank_transfers_clientId_idx" ON public.bank_transfers USING btree ("clientId");


--
-- Name: bank_transfers_createdAt_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "bank_transfers_createdAt_idx" ON public.bank_transfers USING btree ("createdAt");


--
-- Name: bank_transfers_createdBy_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "bank_transfers_createdBy_idx" ON public.bank_transfers USING btree ("createdBy");


--
-- Name: bank_transfers_fromAccountId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "bank_transfers_fromAccountId_idx" ON public.bank_transfers USING btree ("fromAccountId");


--
-- Name: bank_transfers_projectId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "bank_transfers_projectId_idx" ON public.bank_transfers USING btree ("projectId");


--
-- Name: bank_transfers_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX bank_transfers_status_idx ON public.bank_transfers USING btree (status);


--
-- Name: bank_transfers_toAccountId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "bank_transfers_toAccountId_idx" ON public.bank_transfers USING btree ("toAccountId");


--
-- Name: bank_transfers_transferDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "bank_transfers_transferDate_idx" ON public.bank_transfers USING btree ("transferDate");


--
-- Name: bank_transfers_transferNumber_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "bank_transfers_transferNumber_idx" ON public.bank_transfers USING btree ("transferNumber");


--
-- Name: bank_transfers_transferNumber_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "bank_transfers_transferNumber_key" ON public.bank_transfers USING btree ("transferNumber");


--
-- Name: business_journey_event_metadata_eventId_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "business_journey_event_metadata_eventId_key" ON public.business_journey_event_metadata USING btree ("eventId");


--
-- Name: business_journey_event_metadata_materaiRequired_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "business_journey_event_metadata_materaiRequired_idx" ON public.business_journey_event_metadata USING btree ("materaiRequired");


--
-- Name: business_journey_event_metadata_priority_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX business_journey_event_metadata_priority_idx ON public.business_journey_event_metadata USING btree (priority);


--
-- Name: business_journey_event_metadata_source_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX business_journey_event_metadata_source_idx ON public.business_journey_event_metadata USING btree (source);


--
-- Name: business_journey_events_amount_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX business_journey_events_amount_idx ON public.business_journey_events USING btree (amount);


--
-- Name: business_journey_events_clientId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "business_journey_events_clientId_idx" ON public.business_journey_events USING btree ("clientId");


--
-- Name: business_journey_events_clientId_status_createdAt_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "business_journey_events_clientId_status_createdAt_idx" ON public.business_journey_events USING btree ("clientId", status, "createdAt");


--
-- Name: business_journey_events_clientId_type_createdAt_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "business_journey_events_clientId_type_createdAt_idx" ON public.business_journey_events USING btree ("clientId", type, "createdAt");


--
-- Name: business_journey_events_createdAt_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "business_journey_events_createdAt_idx" ON public.business_journey_events USING btree ("createdAt");


--
-- Name: business_journey_events_invoiceId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "business_journey_events_invoiceId_idx" ON public.business_journey_events USING btree ("invoiceId");


--
-- Name: business_journey_events_projectId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "business_journey_events_projectId_idx" ON public.business_journey_events USING btree ("projectId");


--
-- Name: business_journey_events_quotationId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "business_journey_events_quotationId_idx" ON public.business_journey_events USING btree ("quotationId");


--
-- Name: business_journey_events_status_createdAt_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "business_journey_events_status_createdAt_idx" ON public.business_journey_events USING btree (status, "createdAt");


--
-- Name: business_journey_events_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX business_journey_events_status_idx ON public.business_journey_events USING btree (status);


--
-- Name: business_journey_events_type_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX business_journey_events_type_idx ON public.business_journey_events USING btree (type);


--
-- Name: business_journey_events_type_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX business_journey_events_type_status_idx ON public.business_journey_events USING btree (type, status);


--
-- Name: cash_bank_balances_createdAt_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "cash_bank_balances_createdAt_idx" ON public.cash_bank_balances USING btree ("createdAt");


--
-- Name: cash_bank_balances_periodDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "cash_bank_balances_periodDate_idx" ON public.cash_bank_balances USING btree ("periodDate");


--
-- Name: cash_bank_balances_year_month_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX cash_bank_balances_year_month_idx ON public.cash_bank_balances USING btree (year, month);


--
-- Name: cash_bank_balances_year_month_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX cash_bank_balances_year_month_key ON public.cash_bank_balances USING btree (year, month);


--
-- Name: cash_transactions_cashAccountId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "cash_transactions_cashAccountId_idx" ON public.cash_transactions USING btree ("cashAccountId");


--
-- Name: cash_transactions_category_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX cash_transactions_category_idx ON public.cash_transactions USING btree (category);


--
-- Name: cash_transactions_clientId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "cash_transactions_clientId_idx" ON public.cash_transactions USING btree ("clientId");


--
-- Name: cash_transactions_createdAt_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "cash_transactions_createdAt_idx" ON public.cash_transactions USING btree ("createdAt");


--
-- Name: cash_transactions_createdBy_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "cash_transactions_createdBy_idx" ON public.cash_transactions USING btree ("createdBy");


--
-- Name: cash_transactions_offsetAccountId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "cash_transactions_offsetAccountId_idx" ON public.cash_transactions USING btree ("offsetAccountId");


--
-- Name: cash_transactions_projectId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "cash_transactions_projectId_idx" ON public.cash_transactions USING btree ("projectId");


--
-- Name: cash_transactions_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX cash_transactions_status_idx ON public.cash_transactions USING btree (status);


--
-- Name: cash_transactions_transactionDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "cash_transactions_transactionDate_idx" ON public.cash_transactions USING btree ("transactionDate");


--
-- Name: cash_transactions_transactionNumber_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "cash_transactions_transactionNumber_idx" ON public.cash_transactions USING btree ("transactionNumber");


--
-- Name: cash_transactions_transactionNumber_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "cash_transactions_transactionNumber_key" ON public.cash_transactions USING btree ("transactionNumber");


--
-- Name: cash_transactions_transactionType_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "cash_transactions_transactionType_idx" ON public.cash_transactions USING btree ("transactionType");


--
-- Name: chart_of_accounts_accountType_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "chart_of_accounts_accountType_idx" ON public.chart_of_accounts USING btree ("accountType");


--
-- Name: chart_of_accounts_code_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX chart_of_accounts_code_idx ON public.chart_of_accounts USING btree (code);


--
-- Name: chart_of_accounts_code_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX chart_of_accounts_code_key ON public.chart_of_accounts USING btree (code);


--
-- Name: chart_of_accounts_isActive_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "chart_of_accounts_isActive_idx" ON public.chart_of_accounts USING btree ("isActive");


--
-- Name: chart_of_accounts_parentId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "chart_of_accounts_parentId_idx" ON public.chart_of_accounts USING btree ("parentId");


--
-- Name: clients_createdAt_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "clients_createdAt_idx" ON public.clients USING btree ("createdAt");


--
-- Name: clients_email_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX clients_email_idx ON public.clients USING btree (email);


--
-- Name: clients_name_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX clients_name_idx ON public.clients USING btree (name);


--
-- Name: clients_name_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX clients_name_status_idx ON public.clients USING btree (name, status);


--
-- Name: clients_phone_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX clients_phone_idx ON public.clients USING btree (phone);


--
-- Name: clients_status_createdAt_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "clients_status_createdAt_idx" ON public.clients USING btree (status, "createdAt");


--
-- Name: collection_items_collectionId_assetId_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "collection_items_collectionId_assetId_key" ON public.collection_items USING btree ("collectionId", "assetId");


--
-- Name: collection_items_collectionId_order_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "collection_items_collectionId_order_idx" ON public.collection_items USING btree ("collectionId", "order");


--
-- Name: collections_isDynamic_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "collections_isDynamic_idx" ON public.collections USING btree ("isDynamic");


--
-- Name: collections_projectId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "collections_projectId_idx" ON public.collections USING btree ("projectId");


--
-- Name: collections_shareToken_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "collections_shareToken_idx" ON public.collections USING btree ("shareToken");


--
-- Name: collections_shareToken_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "collections_shareToken_key" ON public.collections USING btree ("shareToken");


--
-- Name: content_calendar_items_clientId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "content_calendar_items_clientId_idx" ON public.content_calendar_items USING btree ("clientId");


--
-- Name: content_calendar_items_createdBy_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "content_calendar_items_createdBy_idx" ON public.content_calendar_items USING btree ("createdBy");


--
-- Name: content_calendar_items_projectId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "content_calendar_items_projectId_idx" ON public.content_calendar_items USING btree ("projectId");


--
-- Name: content_calendar_items_scheduledAt_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "content_calendar_items_scheduledAt_idx" ON public.content_calendar_items USING btree ("scheduledAt");


--
-- Name: content_calendar_items_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX content_calendar_items_status_idx ON public.content_calendar_items USING btree (status);


--
-- Name: content_calendar_items_status_scheduledAt_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "content_calendar_items_status_scheduledAt_idx" ON public.content_calendar_items USING btree (status, "scheduledAt");


--
-- Name: content_media_contentId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "content_media_contentId_idx" ON public.content_media USING btree ("contentId");


--
-- Name: content_media_contentId_order_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "content_media_contentId_order_idx" ON public.content_media USING btree ("contentId", "order");


--
-- Name: content_media_type_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX content_media_type_idx ON public.content_media USING btree (type);


--
-- Name: content_media_uploadedAt_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "content_media_uploadedAt_idx" ON public.content_media USING btree ("uploadedAt");


--
-- Name: deferred_revenue_fiscalPeriodId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "deferred_revenue_fiscalPeriodId_idx" ON public.deferred_revenue USING btree ("fiscalPeriodId");


--
-- Name: deferred_revenue_invoiceId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "deferred_revenue_invoiceId_idx" ON public.deferred_revenue USING btree ("invoiceId");


--
-- Name: deferred_revenue_paymentDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "deferred_revenue_paymentDate_idx" ON public.deferred_revenue USING btree ("paymentDate");


--
-- Name: deferred_revenue_recognitionDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "deferred_revenue_recognitionDate_idx" ON public.deferred_revenue USING btree ("recognitionDate");


--
-- Name: deferred_revenue_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX deferred_revenue_status_idx ON public.deferred_revenue USING btree (status);


--
-- Name: depreciation_entries_assetId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "depreciation_entries_assetId_idx" ON public.depreciation_entries USING btree ("assetId");


--
-- Name: depreciation_entries_assetId_periodDate_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "depreciation_entries_assetId_periodDate_key" ON public.depreciation_entries USING btree ("assetId", "periodDate");


--
-- Name: depreciation_entries_fiscalPeriodId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "depreciation_entries_fiscalPeriodId_idx" ON public.depreciation_entries USING btree ("fiscalPeriodId");


--
-- Name: depreciation_entries_journalEntryId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "depreciation_entries_journalEntryId_idx" ON public.depreciation_entries USING btree ("journalEntryId");


--
-- Name: depreciation_entries_periodDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "depreciation_entries_periodDate_idx" ON public.depreciation_entries USING btree ("periodDate");


--
-- Name: depreciation_entries_scheduleId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "depreciation_entries_scheduleId_idx" ON public.depreciation_entries USING btree ("scheduleId");


--
-- Name: depreciation_entries_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX depreciation_entries_status_idx ON public.depreciation_entries USING btree (status);


--
-- Name: depreciation_schedules_assetId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "depreciation_schedules_assetId_idx" ON public.depreciation_schedules USING btree ("assetId");


--
-- Name: depreciation_schedules_endDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "depreciation_schedules_endDate_idx" ON public.depreciation_schedules USING btree ("endDate");


--
-- Name: depreciation_schedules_isActive_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "depreciation_schedules_isActive_idx" ON public.depreciation_schedules USING btree ("isActive");


--
-- Name: depreciation_schedules_isFulfilled_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "depreciation_schedules_isFulfilled_idx" ON public.depreciation_schedules USING btree ("isFulfilled");


--
-- Name: depreciation_schedules_startDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "depreciation_schedules_startDate_idx" ON public.depreciation_schedules USING btree ("startDate");


--
-- Name: documents_category_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX documents_category_idx ON public.documents USING btree (category);


--
-- Name: documents_invoiceId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "documents_invoiceId_idx" ON public.documents USING btree ("invoiceId");


--
-- Name: documents_mimeType_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "documents_mimeType_idx" ON public.documents USING btree ("mimeType");


--
-- Name: documents_projectId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "documents_projectId_idx" ON public.documents USING btree ("projectId");


--
-- Name: documents_quotationId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "documents_quotationId_idx" ON public.documents USING btree ("quotationId");


--
-- Name: documents_uploadedAt_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "documents_uploadedAt_idx" ON public.documents USING btree ("uploadedAt");


--
-- Name: exchange_rates_effectiveDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "exchange_rates_effectiveDate_idx" ON public.exchange_rates USING btree ("effectiveDate");


--
-- Name: exchange_rates_fromCurrency_toCurrency_effectiveDate_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "exchange_rates_fromCurrency_toCurrency_effectiveDate_key" ON public.exchange_rates USING btree ("fromCurrency", "toCurrency", "effectiveDate");


--
-- Name: exchange_rates_fromCurrency_toCurrency_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "exchange_rates_fromCurrency_toCurrency_idx" ON public.exchange_rates USING btree ("fromCurrency", "toCurrency");


--
-- Name: exchange_rates_isActive_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "exchange_rates_isActive_idx" ON public.exchange_rates USING btree ("isActive");


--
-- Name: expense_approval_history_actionBy_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expense_approval_history_actionBy_idx" ON public.expense_approval_history USING btree ("actionBy");


--
-- Name: expense_approval_history_actionDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expense_approval_history_actionDate_idx" ON public.expense_approval_history USING btree ("actionDate");


--
-- Name: expense_approval_history_expenseId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expense_approval_history_expenseId_idx" ON public.expense_approval_history USING btree ("expenseId");


--
-- Name: expense_budgets_categoryId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expense_budgets_categoryId_idx" ON public.expense_budgets USING btree ("categoryId");


--
-- Name: expense_budgets_isActive_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expense_budgets_isActive_idx" ON public.expense_budgets USING btree ("isActive");


--
-- Name: expense_budgets_projectId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expense_budgets_projectId_idx" ON public.expense_budgets USING btree ("projectId");


--
-- Name: expense_budgets_startDate_endDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expense_budgets_startDate_endDate_idx" ON public.expense_budgets USING btree ("startDate", "endDate");


--
-- Name: expense_budgets_userId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expense_budgets_userId_idx" ON public.expense_budgets USING btree ("userId");


--
-- Name: expense_categories_accountCode_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expense_categories_accountCode_idx" ON public.expense_categories USING btree ("accountCode");


--
-- Name: expense_categories_code_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX expense_categories_code_idx ON public.expense_categories USING btree (code);


--
-- Name: expense_categories_code_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX expense_categories_code_key ON public.expense_categories USING btree (code);


--
-- Name: expense_categories_expenseClass_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expense_categories_expenseClass_idx" ON public.expense_categories USING btree ("expenseClass");


--
-- Name: expense_categories_isActive_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expense_categories_isActive_idx" ON public.expense_categories USING btree ("isActive");


--
-- Name: expense_categories_parentId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expense_categories_parentId_idx" ON public.expense_categories USING btree ("parentId");


--
-- Name: expense_comments_createdAt_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expense_comments_createdAt_idx" ON public.expense_comments USING btree ("createdAt");


--
-- Name: expense_comments_expenseId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expense_comments_expenseId_idx" ON public.expense_comments USING btree ("expenseId");


--
-- Name: expense_comments_userId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expense_comments_userId_idx" ON public.expense_comments USING btree ("userId");


--
-- Name: expense_documents_category_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX expense_documents_category_idx ON public.expense_documents USING btree (category);


--
-- Name: expense_documents_expenseId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expense_documents_expenseId_idx" ON public.expense_documents USING btree ("expenseId");


--
-- Name: expense_documents_mimeType_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expense_documents_mimeType_idx" ON public.expense_documents USING btree ("mimeType");


--
-- Name: expense_documents_uploadedAt_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expense_documents_uploadedAt_idx" ON public.expense_documents USING btree ("uploadedAt");


--
-- Name: expenses_accountCode_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expenses_accountCode_idx" ON public.expenses USING btree ("accountCode");


--
-- Name: expenses_accountsPayableId_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "expenses_accountsPayableId_key" ON public.expenses USING btree ("accountsPayableId");


--
-- Name: expenses_buktiPengeluaranNumber_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expenses_buktiPengeluaranNumber_idx" ON public.expenses USING btree ("buktiPengeluaranNumber");


--
-- Name: expenses_buktiPengeluaranNumber_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "expenses_buktiPengeluaranNumber_key" ON public.expenses USING btree ("buktiPengeluaranNumber");


--
-- Name: expenses_categoryId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expenses_categoryId_idx" ON public.expenses USING btree ("categoryId");


--
-- Name: expenses_clientId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expenses_clientId_idx" ON public.expenses USING btree ("clientId");


--
-- Name: expenses_createdAt_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expenses_createdAt_idx" ON public.expenses USING btree ("createdAt");


--
-- Name: expenses_dueDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expenses_dueDate_idx" ON public.expenses USING btree ("dueDate");


--
-- Name: expenses_eFakturNSFP_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expenses_eFakturNSFP_idx" ON public.expenses USING btree ("eFakturNSFP");


--
-- Name: expenses_expenseClass_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expenses_expenseClass_idx" ON public.expenses USING btree ("expenseClass");


--
-- Name: expenses_expenseDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expenses_expenseDate_idx" ON public.expenses USING btree ("expenseDate");


--
-- Name: expenses_expenseNumber_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expenses_expenseNumber_idx" ON public.expenses USING btree ("expenseNumber");


--
-- Name: expenses_expenseNumber_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "expenses_expenseNumber_key" ON public.expenses USING btree ("expenseNumber");


--
-- Name: expenses_paymentStatus_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expenses_paymentStatus_idx" ON public.expenses USING btree ("paymentStatus");


--
-- Name: expenses_ppnCategory_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expenses_ppnCategory_idx" ON public.expenses USING btree ("ppnCategory");


--
-- Name: expenses_projectId_categoryId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expenses_projectId_categoryId_idx" ON public.expenses USING btree ("projectId", "categoryId");


--
-- Name: expenses_projectId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expenses_projectId_idx" ON public.expenses USING btree ("projectId");


--
-- Name: expenses_projectId_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expenses_projectId_status_idx" ON public.expenses USING btree ("projectId", status);


--
-- Name: expenses_purchaseOrderId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expenses_purchaseOrderId_idx" ON public.expenses USING btree ("purchaseOrderId");


--
-- Name: expenses_purchaseSource_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expenses_purchaseSource_idx" ON public.expenses USING btree ("purchaseSource");


--
-- Name: expenses_purchaseType_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expenses_purchaseType_idx" ON public.expenses USING btree ("purchaseType");


--
-- Name: expenses_status_expenseDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expenses_status_expenseDate_idx" ON public.expenses USING btree (status, "expenseDate");


--
-- Name: expenses_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX expenses_status_idx ON public.expenses USING btree (status);


--
-- Name: expenses_status_userId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expenses_status_userId_idx" ON public.expenses USING btree (status, "userId");


--
-- Name: expenses_userId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expenses_userId_idx" ON public.expenses USING btree ("userId");


--
-- Name: expenses_vendorId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expenses_vendorId_idx" ON public.expenses USING btree ("vendorId");


--
-- Name: expenses_vendorId_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expenses_vendorId_status_idx" ON public.expenses USING btree ("vendorId", status);


--
-- Name: expenses_vendorInvoiceId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "expenses_vendorInvoiceId_idx" ON public.expenses USING btree ("vendorInvoiceId");


--
-- Name: feature_flag_events_eventType_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "feature_flag_events_eventType_idx" ON public.feature_flag_events USING btree ("eventType");


--
-- Name: feature_flag_events_flagId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "feature_flag_events_flagId_idx" ON public.feature_flag_events USING btree ("flagId");


--
-- Name: feature_flag_events_userId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "feature_flag_events_userId_idx" ON public.feature_flag_events USING btree ("userId");


--
-- Name: feature_flags_name_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX feature_flags_name_key ON public.feature_flags USING btree (name);


--
-- Name: financial_statements_fiscalPeriodId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "financial_statements_fiscalPeriodId_idx" ON public.financial_statements USING btree ("fiscalPeriodId");


--
-- Name: financial_statements_startDate_endDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "financial_statements_startDate_endDate_idx" ON public.financial_statements USING btree ("startDate", "endDate");


--
-- Name: financial_statements_statementType_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "financial_statements_statementType_idx" ON public.financial_statements USING btree ("statementType");


--
-- Name: fiscal_periods_code_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX fiscal_periods_code_idx ON public.fiscal_periods USING btree (code);


--
-- Name: fiscal_periods_code_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX fiscal_periods_code_key ON public.fiscal_periods USING btree (code);


--
-- Name: fiscal_periods_endDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "fiscal_periods_endDate_idx" ON public.fiscal_periods USING btree ("endDate");


--
-- Name: fiscal_periods_startDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "fiscal_periods_startDate_idx" ON public.fiscal_periods USING btree ("startDate");


--
-- Name: fiscal_periods_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX fiscal_periods_status_idx ON public.fiscal_periods USING btree (status);


--
-- Name: frame_comments_authorId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "frame_comments_authorId_idx" ON public.frame_comments USING btree ("authorId");


--
-- Name: frame_comments_frameId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "frame_comments_frameId_idx" ON public.frame_comments USING btree ("frameId");


--
-- Name: frame_comments_parentId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "frame_comments_parentId_idx" ON public.frame_comments USING btree ("parentId");


--
-- Name: frame_comments_resolved_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX frame_comments_resolved_idx ON public.frame_comments USING btree (resolved);


--
-- Name: frame_drawings_frameId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "frame_drawings_frameId_idx" ON public.frame_drawings USING btree ("frameId");


--
-- Name: general_ledger_accountId_fiscalPeriodId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "general_ledger_accountId_fiscalPeriodId_idx" ON public.general_ledger USING btree ("accountId", "fiscalPeriodId");


--
-- Name: general_ledger_accountId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "general_ledger_accountId_idx" ON public.general_ledger USING btree ("accountId");


--
-- Name: general_ledger_accountId_postingDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "general_ledger_accountId_postingDate_idx" ON public.general_ledger USING btree ("accountId", "postingDate");


--
-- Name: general_ledger_clientId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "general_ledger_clientId_idx" ON public.general_ledger USING btree ("clientId");


--
-- Name: general_ledger_entryDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "general_ledger_entryDate_idx" ON public.general_ledger USING btree ("entryDate");


--
-- Name: general_ledger_fiscalPeriodId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "general_ledger_fiscalPeriodId_idx" ON public.general_ledger USING btree ("fiscalPeriodId");


--
-- Name: general_ledger_journalEntryId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "general_ledger_journalEntryId_idx" ON public.general_ledger USING btree ("journalEntryId");


--
-- Name: general_ledger_postingDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "general_ledger_postingDate_idx" ON public.general_ledger USING btree ("postingDate");


--
-- Name: general_ledger_projectId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "general_ledger_projectId_idx" ON public.general_ledger USING btree ("projectId");


--
-- Name: general_ledger_transactionType_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "general_ledger_transactionType_idx" ON public.general_ledger USING btree ("transactionType");


--
-- Name: goods_receipt_items_grId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "goods_receipt_items_grId_idx" ON public.goods_receipt_items USING btree ("grId");


--
-- Name: goods_receipt_items_poItemId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "goods_receipt_items_poItemId_idx" ON public.goods_receipt_items USING btree ("poItemId");


--
-- Name: goods_receipts_grDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "goods_receipts_grDate_idx" ON public.goods_receipts USING btree ("grDate");


--
-- Name: goods_receipts_grNumber_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "goods_receipts_grNumber_idx" ON public.goods_receipts USING btree ("grNumber");


--
-- Name: goods_receipts_grNumber_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "goods_receipts_grNumber_key" ON public.goods_receipts USING btree ("grNumber");


--
-- Name: goods_receipts_poId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "goods_receipts_poId_idx" ON public.goods_receipts USING btree ("poId");


--
-- Name: goods_receipts_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX goods_receipts_status_idx ON public.goods_receipts USING btree (status);


--
-- Name: goods_receipts_vendorId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "goods_receipts_vendorId_idx" ON public.goods_receipts USING btree ("vendorId");


--
-- Name: indonesian_holidays_date_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX indonesian_holidays_date_idx ON public.indonesian_holidays USING btree (date);


--
-- Name: indonesian_holidays_date_region_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX indonesian_holidays_date_region_key ON public.indonesian_holidays USING btree (date, region);


--
-- Name: indonesian_holidays_region_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX indonesian_holidays_region_idx ON public.indonesian_holidays USING btree (region);


--
-- Name: indonesian_holidays_type_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX indonesian_holidays_type_idx ON public.indonesian_holidays USING btree (type);


--
-- Name: indonesian_holidays_year_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX indonesian_holidays_year_idx ON public.indonesian_holidays USING btree (year);


--
-- Name: invoice_counters_year_month_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX invoice_counters_year_month_idx ON public.invoice_counters USING btree (year, month);


--
-- Name: invoice_counters_year_month_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX invoice_counters_year_month_key ON public.invoice_counters USING btree (year, month);


--
-- Name: invoices_clientId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "invoices_clientId_idx" ON public.invoices USING btree ("clientId");


--
-- Name: invoices_clientId_projectId_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "invoices_clientId_projectId_status_idx" ON public.invoices USING btree ("clientId", "projectId", status);


--
-- Name: invoices_clientId_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "invoices_clientId_status_idx" ON public.invoices USING btree ("clientId", status);


--
-- Name: invoices_createdAt_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "invoices_createdAt_idx" ON public.invoices USING btree ("createdAt");


--
-- Name: invoices_createdAt_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "invoices_createdAt_status_idx" ON public.invoices USING btree ("createdAt", status);


--
-- Name: invoices_dueDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "invoices_dueDate_idx" ON public.invoices USING btree ("dueDate");


--
-- Name: invoices_invoiceNumber_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "invoices_invoiceNumber_idx" ON public.invoices USING btree ("invoiceNumber");


--
-- Name: invoices_invoiceNumber_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "invoices_invoiceNumber_key" ON public.invoices USING btree ("invoiceNumber");


--
-- Name: invoices_materaiRequired_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "invoices_materaiRequired_idx" ON public.invoices USING btree ("materaiRequired");


--
-- Name: invoices_materaiRequired_materaiApplied_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "invoices_materaiRequired_materaiApplied_status_idx" ON public.invoices USING btree ("materaiRequired", "materaiApplied", status);


--
-- Name: invoices_materaiRequired_totalAmount_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "invoices_materaiRequired_totalAmount_idx" ON public.invoices USING btree ("materaiRequired", "totalAmount");


--
-- Name: invoices_paymentMilestoneId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "invoices_paymentMilestoneId_idx" ON public.invoices USING btree ("paymentMilestoneId");


--
-- Name: invoices_projectId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "invoices_projectId_idx" ON public.invoices USING btree ("projectId");


--
-- Name: invoices_projectMilestoneId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "invoices_projectMilestoneId_idx" ON public.invoices USING btree ("projectMilestoneId");


--
-- Name: invoices_quotationId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "invoices_quotationId_idx" ON public.invoices USING btree ("quotationId");


--
-- Name: invoices_quotationId_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "invoices_quotationId_status_idx" ON public.invoices USING btree ("quotationId", status);


--
-- Name: invoices_status_createdAt_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "invoices_status_createdAt_idx" ON public.invoices USING btree (status, "createdAt");


--
-- Name: invoices_status_dueDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "invoices_status_dueDate_idx" ON public.invoices USING btree (status, "dueDate");


--
-- Name: invoices_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX invoices_status_idx ON public.invoices USING btree (status);


--
-- Name: journal_entries_entryDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "journal_entries_entryDate_idx" ON public.journal_entries USING btree ("entryDate");


--
-- Name: journal_entries_entryNumber_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "journal_entries_entryNumber_idx" ON public.journal_entries USING btree ("entryNumber");


--
-- Name: journal_entries_entryNumber_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "journal_entries_entryNumber_key" ON public.journal_entries USING btree ("entryNumber");


--
-- Name: journal_entries_fiscalPeriodId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "journal_entries_fiscalPeriodId_idx" ON public.journal_entries USING btree ("fiscalPeriodId");


--
-- Name: journal_entries_isPosted_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "journal_entries_isPosted_idx" ON public.journal_entries USING btree ("isPosted");


--
-- Name: journal_entries_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX journal_entries_status_idx ON public.journal_entries USING btree (status);


--
-- Name: journal_entries_transactionId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "journal_entries_transactionId_idx" ON public.journal_entries USING btree ("transactionId");


--
-- Name: journal_entries_transactionType_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "journal_entries_transactionType_idx" ON public.journal_entries USING btree ("transactionType");


--
-- Name: journal_line_items_accountId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "journal_line_items_accountId_idx" ON public.journal_line_items USING btree ("accountId");


--
-- Name: journal_line_items_clientId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "journal_line_items_clientId_idx" ON public.journal_line_items USING btree ("clientId");


--
-- Name: journal_line_items_journalEntryId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "journal_line_items_journalEntryId_idx" ON public.journal_line_items USING btree ("journalEntryId");


--
-- Name: journal_line_items_projectId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "journal_line_items_projectId_idx" ON public.journal_line_items USING btree ("projectId");


--
-- Name: labor_entries_expenseId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "labor_entries_expenseId_idx" ON public.labor_entries USING btree ("expenseId");


--
-- Name: labor_entries_projectId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "labor_entries_projectId_idx" ON public.labor_entries USING btree ("projectId");


--
-- Name: labor_entries_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX labor_entries_status_idx ON public.labor_entries USING btree (status);


--
-- Name: labor_entries_teamMemberId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "labor_entries_teamMemberId_idx" ON public.labor_entries USING btree ("teamMemberId");


--
-- Name: labor_entries_teamMemberId_workDate_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "labor_entries_teamMemberId_workDate_key" ON public.labor_entries USING btree ("teamMemberId", "workDate");


--
-- Name: labor_entries_userId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "labor_entries_userId_idx" ON public.labor_entries USING btree ("userId");


--
-- Name: labor_entries_workDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "labor_entries_workDate_idx" ON public.labor_entries USING btree ("workDate");


--
-- Name: maintenance_records_assetId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "maintenance_records_assetId_idx" ON public.maintenance_records USING btree ("assetId");


--
-- Name: maintenance_records_maintenanceType_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "maintenance_records_maintenanceType_idx" ON public.maintenance_records USING btree ("maintenanceType");


--
-- Name: maintenance_records_performedDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "maintenance_records_performedDate_idx" ON public.maintenance_records USING btree ("performedDate");


--
-- Name: maintenance_schedules_assetId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "maintenance_schedules_assetId_idx" ON public.maintenance_schedules USING btree ("assetId");


--
-- Name: maintenance_schedules_isActive_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "maintenance_schedules_isActive_idx" ON public.maintenance_schedules USING btree ("isActive");


--
-- Name: maintenance_schedules_isActive_nextMaintenanceDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "maintenance_schedules_isActive_nextMaintenanceDate_idx" ON public.maintenance_schedules USING btree ("isActive", "nextMaintenanceDate");


--
-- Name: maintenance_schedules_nextMaintenanceDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "maintenance_schedules_nextMaintenanceDate_idx" ON public.maintenance_schedules USING btree ("nextMaintenanceDate");


--
-- Name: media_assets_folderId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "media_assets_folderId_idx" ON public.media_assets USING btree ("folderId");


--
-- Name: media_assets_mediaType_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "media_assets_mediaType_idx" ON public.media_assets USING btree ("mediaType");


--
-- Name: media_assets_projectId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "media_assets_projectId_idx" ON public.media_assets USING btree ("projectId");


--
-- Name: media_assets_projectId_starRating_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "media_assets_projectId_starRating_idx" ON public.media_assets USING btree ("projectId", "starRating");


--
-- Name: media_assets_starRating_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "media_assets_starRating_idx" ON public.media_assets USING btree ("starRating");


--
-- Name: media_assets_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX media_assets_status_idx ON public.media_assets USING btree (status);


--
-- Name: media_assets_uploadedBy_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "media_assets_uploadedBy_idx" ON public.media_assets USING btree ("uploadedBy");


--
-- Name: media_collaborators_guestEmail_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "media_collaborators_guestEmail_idx" ON public.media_collaborators USING btree ("guestEmail");


--
-- Name: media_collaborators_inviteToken_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "media_collaborators_inviteToken_idx" ON public.media_collaborators USING btree ("inviteToken");


--
-- Name: media_collaborators_inviteToken_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "media_collaborators_inviteToken_key" ON public.media_collaborators USING btree ("inviteToken");


--
-- Name: media_collaborators_projectId_guestEmail_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "media_collaborators_projectId_guestEmail_key" ON public.media_collaborators USING btree ("projectId", "guestEmail");


--
-- Name: media_collaborators_projectId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "media_collaborators_projectId_idx" ON public.media_collaborators USING btree ("projectId");


--
-- Name: media_collaborators_projectId_userId_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "media_collaborators_projectId_userId_key" ON public.media_collaborators USING btree ("projectId", "userId");


--
-- Name: media_collaborators_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX media_collaborators_status_idx ON public.media_collaborators USING btree (status);


--
-- Name: media_collaborators_userId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "media_collaborators_userId_idx" ON public.media_collaborators USING btree ("userId");


--
-- Name: media_folders_createdById_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "media_folders_createdById_idx" ON public.media_folders USING btree ("createdById");


--
-- Name: media_folders_parentId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "media_folders_parentId_idx" ON public.media_folders USING btree ("parentId");


--
-- Name: media_folders_projectId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "media_folders_projectId_idx" ON public.media_folders USING btree ("projectId");


--
-- Name: media_frames_assetId_timestamp_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "media_frames_assetId_timestamp_idx" ON public.media_frames USING btree ("assetId", "timestamp");


--
-- Name: media_frames_assetId_x_y_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "media_frames_assetId_x_y_idx" ON public.media_frames USING btree ("assetId", x, y);


--
-- Name: media_frames_createdBy_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "media_frames_createdBy_idx" ON public.media_frames USING btree ("createdBy");


--
-- Name: media_projects_clientId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "media_projects_clientId_idx" ON public.media_projects USING btree ("clientId");


--
-- Name: media_projects_createdBy_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "media_projects_createdBy_idx" ON public.media_projects USING btree ("createdBy");


--
-- Name: media_projects_folderId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "media_projects_folderId_idx" ON public.media_projects USING btree ("folderId");


--
-- Name: media_projects_projectId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "media_projects_projectId_idx" ON public.media_projects USING btree ("projectId");


--
-- Name: media_projects_publicShareToken_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "media_projects_publicShareToken_idx" ON public.media_projects USING btree ("publicShareToken");


--
-- Name: media_projects_publicShareToken_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "media_projects_publicShareToken_key" ON public.media_projects USING btree ("publicShareToken");


--
-- Name: media_versions_assetId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "media_versions_assetId_idx" ON public.media_versions USING btree ("assetId");


--
-- Name: media_versions_assetId_versionNumber_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "media_versions_assetId_versionNumber_key" ON public.media_versions USING btree ("assetId", "versionNumber");


--
-- Name: payment_milestones_projectMilestoneId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "payment_milestones_projectMilestoneId_idx" ON public.payment_milestones USING btree ("projectMilestoneId");


--
-- Name: payment_milestones_quotationId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "payment_milestones_quotationId_idx" ON public.payment_milestones USING btree ("quotationId");


--
-- Name: payment_milestones_quotationId_milestoneNumber_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "payment_milestones_quotationId_milestoneNumber_key" ON public.payment_milestones USING btree ("quotationId", "milestoneNumber");


--
-- Name: payments_invoiceId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "payments_invoiceId_idx" ON public.payments USING btree ("invoiceId");


--
-- Name: payments_invoiceId_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "payments_invoiceId_status_idx" ON public.payments USING btree ("invoiceId", status);


--
-- Name: payments_paymentDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "payments_paymentDate_idx" ON public.payments USING btree ("paymentDate");


--
-- Name: payments_paymentMethod_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "payments_paymentMethod_idx" ON public.payments USING btree ("paymentMethod");


--
-- Name: payments_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX payments_status_idx ON public.payments USING btree (status);


--
-- Name: payments_status_paymentDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "payments_status_paymentDate_idx" ON public.payments USING btree (status, "paymentDate");


--
-- Name: project_cost_allocations_allocationDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "project_cost_allocations_allocationDate_idx" ON public.project_cost_allocations USING btree ("allocationDate");


--
-- Name: project_cost_allocations_costType_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "project_cost_allocations_costType_idx" ON public.project_cost_allocations USING btree ("costType");


--
-- Name: project_cost_allocations_expenseId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "project_cost_allocations_expenseId_idx" ON public.project_cost_allocations USING btree ("expenseId");


--
-- Name: project_cost_allocations_projectId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "project_cost_allocations_projectId_idx" ON public.project_cost_allocations USING btree ("projectId");


--
-- Name: project_equipment_usage_assetId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "project_equipment_usage_assetId_idx" ON public.project_equipment_usage USING btree ("assetId");


--
-- Name: project_equipment_usage_assetId_startDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "project_equipment_usage_assetId_startDate_idx" ON public.project_equipment_usage USING btree ("assetId", "startDate");


--
-- Name: project_equipment_usage_projectId_assetId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "project_equipment_usage_projectId_assetId_idx" ON public.project_equipment_usage USING btree ("projectId", "assetId");


--
-- Name: project_equipment_usage_projectId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "project_equipment_usage_projectId_idx" ON public.project_equipment_usage USING btree ("projectId");


--
-- Name: project_equipment_usage_returnDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "project_equipment_usage_returnDate_idx" ON public.project_equipment_usage USING btree ("returnDate");


--
-- Name: project_equipment_usage_startDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "project_equipment_usage_startDate_idx" ON public.project_equipment_usage USING btree ("startDate");


--
-- Name: project_milestones_completionPercentage_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "project_milestones_completionPercentage_idx" ON public.project_milestones USING btree ("completionPercentage");


--
-- Name: project_milestones_milestoneNumber_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "project_milestones_milestoneNumber_idx" ON public.project_milestones USING btree ("milestoneNumber");


--
-- Name: project_milestones_predecessorId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "project_milestones_predecessorId_idx" ON public.project_milestones USING btree ("predecessorId");


--
-- Name: project_milestones_priority_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX project_milestones_priority_idx ON public.project_milestones USING btree (priority);


--
-- Name: project_milestones_projectId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "project_milestones_projectId_idx" ON public.project_milestones USING btree ("projectId");


--
-- Name: project_milestones_projectId_milestoneNumber_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "project_milestones_projectId_milestoneNumber_key" ON public.project_milestones USING btree ("projectId", "milestoneNumber");


--
-- Name: project_milestones_projectId_plannedStartDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "project_milestones_projectId_plannedStartDate_idx" ON public.project_milestones USING btree ("projectId", "plannedStartDate");


--
-- Name: project_milestones_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX project_milestones_status_idx ON public.project_milestones USING btree (status);


--
-- Name: project_milestones_status_plannedEndDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "project_milestones_status_plannedEndDate_idx" ON public.project_milestones USING btree (status, "plannedEndDate");


--
-- Name: project_team_members_endDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "project_team_members_endDate_idx" ON public.project_team_members USING btree ("endDate");


--
-- Name: project_team_members_isActive_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "project_team_members_isActive_idx" ON public.project_team_members USING btree ("isActive");


--
-- Name: project_team_members_projectId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "project_team_members_projectId_idx" ON public.project_team_members USING btree ("projectId");


--
-- Name: project_team_members_projectId_userId_assignedDate_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "project_team_members_projectId_userId_assignedDate_key" ON public.project_team_members USING btree ("projectId", "userId", "assignedDate");


--
-- Name: project_team_members_startDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "project_team_members_startDate_idx" ON public.project_team_members USING btree ("startDate");


--
-- Name: project_team_members_userId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "project_team_members_userId_idx" ON public.project_team_members USING btree ("userId");


--
-- Name: project_type_configs_code_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX project_type_configs_code_idx ON public.project_type_configs USING btree (code);


--
-- Name: project_type_configs_code_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX project_type_configs_code_key ON public.project_type_configs USING btree (code);


--
-- Name: project_type_configs_isActive_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "project_type_configs_isActive_idx" ON public.project_type_configs USING btree ("isActive");


--
-- Name: project_type_configs_sortOrder_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "project_type_configs_sortOrder_idx" ON public.project_type_configs USING btree ("sortOrder");


--
-- Name: projects_clientId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "projects_clientId_idx" ON public.projects USING btree ("clientId");


--
-- Name: projects_clientId_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "projects_clientId_status_idx" ON public.projects USING btree ("clientId", status);


--
-- Name: projects_createdAt_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "projects_createdAt_idx" ON public.projects USING btree ("createdAt");


--
-- Name: projects_grossMarginPercent_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "projects_grossMarginPercent_idx" ON public.projects USING btree ("grossMarginPercent");


--
-- Name: projects_netMarginPercent_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "projects_netMarginPercent_idx" ON public.projects USING btree ("netMarginPercent");


--
-- Name: projects_number_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX projects_number_idx ON public.projects USING btree (number);


--
-- Name: projects_number_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX projects_number_key ON public.projects USING btree (number);


--
-- Name: projects_profitCalculatedAt_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "projects_profitCalculatedAt_idx" ON public.projects USING btree ("profitCalculatedAt");


--
-- Name: projects_projectTypeId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "projects_projectTypeId_idx" ON public.projects USING btree ("projectTypeId");


--
-- Name: projects_projectTypeId_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "projects_projectTypeId_status_idx" ON public.projects USING btree ("projectTypeId", status);


--
-- Name: projects_projectedNetMargin_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "projects_projectedNetMargin_idx" ON public.projects USING btree ("projectedNetMargin");


--
-- Name: projects_status_createdAt_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "projects_status_createdAt_idx" ON public.projects USING btree (status, "createdAt");


--
-- Name: projects_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX projects_status_idx ON public.projects USING btree (status);


--
-- Name: projects_totalAllocatedCosts_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "projects_totalAllocatedCosts_idx" ON public.projects USING btree ("totalAllocatedCosts");


--
-- Name: purchase_order_items_assetId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "purchase_order_items_assetId_idx" ON public.purchase_order_items USING btree ("assetId");


--
-- Name: purchase_order_items_expenseCategoryId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "purchase_order_items_expenseCategoryId_idx" ON public.purchase_order_items USING btree ("expenseCategoryId");


--
-- Name: purchase_order_items_poId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "purchase_order_items_poId_idx" ON public.purchase_order_items USING btree ("poId");


--
-- Name: purchase_orders_approvalStatus_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "purchase_orders_approvalStatus_idx" ON public.purchase_orders USING btree ("approvalStatus");


--
-- Name: purchase_orders_poDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "purchase_orders_poDate_idx" ON public.purchase_orders USING btree ("poDate");


--
-- Name: purchase_orders_poNumber_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "purchase_orders_poNumber_idx" ON public.purchase_orders USING btree ("poNumber");


--
-- Name: purchase_orders_poNumber_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "purchase_orders_poNumber_key" ON public.purchase_orders USING btree ("poNumber");


--
-- Name: purchase_orders_projectId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "purchase_orders_projectId_idx" ON public.purchase_orders USING btree ("projectId");


--
-- Name: purchase_orders_requestedBy_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "purchase_orders_requestedBy_idx" ON public.purchase_orders USING btree ("requestedBy");


--
-- Name: purchase_orders_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX purchase_orders_status_idx ON public.purchase_orders USING btree (status);


--
-- Name: purchase_orders_vendorId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "purchase_orders_vendorId_idx" ON public.purchase_orders USING btree ("vendorId");


--
-- Name: quotation_counters_year_month_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX quotation_counters_year_month_idx ON public.quotation_counters USING btree (year, month);


--
-- Name: quotation_counters_year_month_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX quotation_counters_year_month_key ON public.quotation_counters USING btree (year, month);


--
-- Name: quotations_clientId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "quotations_clientId_idx" ON public.quotations USING btree ("clientId");


--
-- Name: quotations_clientId_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "quotations_clientId_status_idx" ON public.quotations USING btree ("clientId", status);


--
-- Name: quotations_createdAt_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "quotations_createdAt_idx" ON public.quotations USING btree ("createdAt");


--
-- Name: quotations_createdAt_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "quotations_createdAt_status_idx" ON public.quotations USING btree ("createdAt", status);


--
-- Name: quotations_projectId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "quotations_projectId_idx" ON public.quotations USING btree ("projectId");


--
-- Name: quotations_projectId_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "quotations_projectId_status_idx" ON public.quotations USING btree ("projectId", status);


--
-- Name: quotations_quotationNumber_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "quotations_quotationNumber_idx" ON public.quotations USING btree ("quotationNumber");


--
-- Name: quotations_quotationNumber_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "quotations_quotationNumber_key" ON public.quotations USING btree ("quotationNumber");


--
-- Name: quotations_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX quotations_status_idx ON public.quotations USING btree (status);


--
-- Name: quotations_status_validUntil_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "quotations_status_validUntil_idx" ON public.quotations USING btree (status, "validUntil");


--
-- Name: quotations_validUntil_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "quotations_validUntil_idx" ON public.quotations USING btree ("validUntil");


--
-- Name: refresh_tokens_token_isRevoked_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "refresh_tokens_token_isRevoked_idx" ON public.refresh_tokens USING btree (token, "isRevoked");


--
-- Name: refresh_tokens_token_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX refresh_tokens_token_key ON public.refresh_tokens USING btree (token);


--
-- Name: refresh_tokens_userId_isRevoked_expiresAt_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "refresh_tokens_userId_isRevoked_expiresAt_idx" ON public.refresh_tokens USING btree ("userId", "isRevoked", "expiresAt");


--
-- Name: report_sections_reportId_order_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "report_sections_reportId_order_idx" ON public.report_sections USING btree ("reportId", "order");


--
-- Name: social_media_reports_projectId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "social_media_reports_projectId_idx" ON public.social_media_reports USING btree ("projectId");


--
-- Name: social_media_reports_projectId_year_month_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "social_media_reports_projectId_year_month_key" ON public.social_media_reports USING btree ("projectId", year, month);


--
-- Name: social_media_reports_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX social_media_reports_status_idx ON public.social_media_reports USING btree (status);


--
-- Name: social_media_reports_year_month_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX social_media_reports_year_month_idx ON public.social_media_reports USING btree (year, month);


--
-- Name: user_preferences_userId_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "user_preferences_userId_key" ON public.user_preferences USING btree ("userId");


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: ux_metrics_componentName_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "ux_metrics_componentName_idx" ON public.ux_metrics USING btree ("componentName");


--
-- Name: ux_metrics_createdAt_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "ux_metrics_createdAt_idx" ON public.ux_metrics USING btree ("createdAt");


--
-- Name: ux_metrics_eventType_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "ux_metrics_eventType_idx" ON public.ux_metrics USING btree ("eventType");


--
-- Name: ux_metrics_metricName_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "ux_metrics_metricName_idx" ON public.ux_metrics USING btree ("metricName");


--
-- Name: ux_metrics_userId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "ux_metrics_userId_idx" ON public.ux_metrics USING btree ("userId");


--
-- Name: vendor_invoice_items_poItemId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "vendor_invoice_items_poItemId_idx" ON public.vendor_invoice_items USING btree ("poItemId");


--
-- Name: vendor_invoice_items_viId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "vendor_invoice_items_viId_idx" ON public.vendor_invoice_items USING btree ("viId");


--
-- Name: vendor_invoices_accountsPayableId_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "vendor_invoices_accountsPayableId_key" ON public.vendor_invoices USING btree ("accountsPayableId");


--
-- Name: vendor_invoices_dueDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "vendor_invoices_dueDate_idx" ON public.vendor_invoices USING btree ("dueDate");


--
-- Name: vendor_invoices_eFakturNSFP_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "vendor_invoices_eFakturNSFP_idx" ON public.vendor_invoices USING btree ("eFakturNSFP");


--
-- Name: vendor_invoices_eFakturNSFP_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "vendor_invoices_eFakturNSFP_key" ON public.vendor_invoices USING btree ("eFakturNSFP");


--
-- Name: vendor_invoices_grId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "vendor_invoices_grId_idx" ON public.vendor_invoices USING btree ("grId");


--
-- Name: vendor_invoices_internalNumber_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "vendor_invoices_internalNumber_idx" ON public.vendor_invoices USING btree ("internalNumber");


--
-- Name: vendor_invoices_internalNumber_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "vendor_invoices_internalNumber_key" ON public.vendor_invoices USING btree ("internalNumber");


--
-- Name: vendor_invoices_invoiceDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "vendor_invoices_invoiceDate_idx" ON public.vendor_invoices USING btree ("invoiceDate");


--
-- Name: vendor_invoices_matchingStatus_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "vendor_invoices_matchingStatus_idx" ON public.vendor_invoices USING btree ("matchingStatus");


--
-- Name: vendor_invoices_poId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "vendor_invoices_poId_idx" ON public.vendor_invoices USING btree ("poId");


--
-- Name: vendor_invoices_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX vendor_invoices_status_idx ON public.vendor_invoices USING btree (status);


--
-- Name: vendor_invoices_vendorId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "vendor_invoices_vendorId_idx" ON public.vendor_invoices USING btree ("vendorId");


--
-- Name: vendor_payment_allocations_apId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "vendor_payment_allocations_apId_idx" ON public.vendor_payment_allocations USING btree ("apId");


--
-- Name: vendor_payment_allocations_paymentId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "vendor_payment_allocations_paymentId_idx" ON public.vendor_payment_allocations USING btree ("paymentId");


--
-- Name: vendor_payments_paymentDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "vendor_payments_paymentDate_idx" ON public.vendor_payments USING btree ("paymentDate");


--
-- Name: vendor_payments_paymentNumber_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "vendor_payments_paymentNumber_idx" ON public.vendor_payments USING btree ("paymentNumber");


--
-- Name: vendor_payments_paymentNumber_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "vendor_payments_paymentNumber_key" ON public.vendor_payments USING btree ("paymentNumber");


--
-- Name: vendor_payments_status_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX vendor_payments_status_idx ON public.vendor_payments USING btree (status);


--
-- Name: vendor_payments_vendorId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "vendor_payments_vendorId_idx" ON public.vendor_payments USING btree ("vendorId");


--
-- Name: vendors_isActive_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "vendors_isActive_idx" ON public.vendors USING btree ("isActive");


--
-- Name: vendors_name_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX vendors_name_idx ON public.vendors USING btree (name);


--
-- Name: vendors_npwp_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX vendors_npwp_idx ON public.vendors USING btree (npwp);


--
-- Name: vendors_npwp_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX vendors_npwp_key ON public.vendors USING btree (npwp);


--
-- Name: vendors_vendorCode_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "vendors_vendorCode_idx" ON public.vendors USING btree ("vendorCode");


--
-- Name: vendors_vendorCode_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "vendors_vendorCode_key" ON public.vendors USING btree ("vendorCode");


--
-- Name: vendors_vendorType_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "vendors_vendorType_idx" ON public.vendors USING btree ("vendorType");


--
-- Name: work_in_progress_fiscalPeriodId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "work_in_progress_fiscalPeriodId_idx" ON public.work_in_progress USING btree ("fiscalPeriodId");


--
-- Name: work_in_progress_isCompleted_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "work_in_progress_isCompleted_idx" ON public.work_in_progress USING btree ("isCompleted");


--
-- Name: work_in_progress_periodDate_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "work_in_progress_periodDate_idx" ON public.work_in_progress USING btree ("periodDate");


--
-- Name: work_in_progress_projectId_idx; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE INDEX "work_in_progress_projectId_idx" ON public.work_in_progress USING btree ("projectId");


--
-- Name: work_in_progress_projectId_periodDate_key; Type: INDEX; Schema: public; Owner: invoiceuser
--

CREATE UNIQUE INDEX "work_in_progress_projectId_periodDate_key" ON public.work_in_progress USING btree ("projectId", "periodDate");


--
-- Name: chart_of_accounts trg_auto_create_expense_category; Type: TRIGGER; Schema: public; Owner: invoiceuser
--

CREATE TRIGGER trg_auto_create_expense_category AFTER INSERT ON public.chart_of_accounts FOR EACH ROW EXECUTE FUNCTION public.auto_create_expense_category();


--
-- Name: chart_of_accounts trg_auto_update_expense_category; Type: TRIGGER; Schema: public; Owner: invoiceuser
--

CREATE TRIGGER trg_auto_update_expense_category AFTER UPDATE ON public.chart_of_accounts FOR EACH ROW WHEN (((old.code IS DISTINCT FROM new.code) OR (old.name IS DISTINCT FROM new.name))) EXECUTE FUNCTION public.auto_create_expense_category();


--
-- Name: account_balances account_balances_accountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.account_balances
    ADD CONSTRAINT "account_balances_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES public.chart_of_accounts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: account_balances account_balances_fiscalPeriodId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.account_balances
    ADD CONSTRAINT "account_balances_fiscalPeriodId_fkey" FOREIGN KEY ("fiscalPeriodId") REFERENCES public.fiscal_periods(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: accounts_payable accounts_payable_expenseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.accounts_payable
    ADD CONSTRAINT "accounts_payable_expenseId_fkey" FOREIGN KEY ("expenseId") REFERENCES public.expenses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: accounts_payable accounts_payable_vendorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.accounts_payable
    ADD CONSTRAINT "accounts_payable_vendorId_fkey" FOREIGN KEY ("vendorId") REFERENCES public.vendors(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: allowance_for_doubtful_accounts allowance_for_doubtful_accounts_fiscalPeriodId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.allowance_for_doubtful_accounts
    ADD CONSTRAINT "allowance_for_doubtful_accounts_fiscalPeriodId_fkey" FOREIGN KEY ("fiscalPeriodId") REFERENCES public.fiscal_periods(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: allowance_for_doubtful_accounts allowance_for_doubtful_accounts_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.allowance_for_doubtful_accounts
    ADD CONSTRAINT "allowance_for_doubtful_accounts_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.invoices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: allowance_for_doubtful_accounts allowance_for_doubtful_accounts_journalEntryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.allowance_for_doubtful_accounts
    ADD CONSTRAINT "allowance_for_doubtful_accounts_journalEntryId_fkey" FOREIGN KEY ("journalEntryId") REFERENCES public.journal_entries(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: asset_kit_items asset_kit_items_assetId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.asset_kit_items
    ADD CONSTRAINT "asset_kit_items_assetId_fkey" FOREIGN KEY ("assetId") REFERENCES public.assets(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: asset_kit_items asset_kit_items_kitId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.asset_kit_items
    ADD CONSTRAINT "asset_kit_items_kitId_fkey" FOREIGN KEY ("kitId") REFERENCES public.asset_kits(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: asset_metadata asset_metadata_assetId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.asset_metadata
    ADD CONSTRAINT "asset_metadata_assetId_fkey" FOREIGN KEY ("assetId") REFERENCES public.media_assets(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: asset_metadata asset_metadata_assigneeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.asset_metadata
    ADD CONSTRAINT "asset_metadata_assigneeId_fkey" FOREIGN KEY ("assigneeId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: asset_reservations asset_reservations_assetId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.asset_reservations
    ADD CONSTRAINT "asset_reservations_assetId_fkey" FOREIGN KEY ("assetId") REFERENCES public.assets(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: asset_reservations asset_reservations_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.asset_reservations
    ADD CONSTRAINT "asset_reservations_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: asset_reservations asset_reservations_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.asset_reservations
    ADD CONSTRAINT "asset_reservations_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: assets assets_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT "assets_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: assets assets_goodsReceiptId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT "assets_goodsReceiptId_fkey" FOREIGN KEY ("goodsReceiptId") REFERENCES public.goods_receipts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: assets assets_purchaseOrderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT "assets_purchaseOrderId_fkey" FOREIGN KEY ("purchaseOrderId") REFERENCES public.purchase_orders(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: assets assets_vendorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT "assets_vendorId_fkey" FOREIGN KEY ("vendorId") REFERENCES public.vendors(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: assets assets_vendorInvoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT "assets_vendorInvoiceId_fkey" FOREIGN KEY ("vendorInvoiceId") REFERENCES public.vendor_invoices(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: audit_logs audit_logs_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT "audit_logs_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: bank_reconciliation_items bank_reconciliation_items_reconciliationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.bank_reconciliation_items
    ADD CONSTRAINT "bank_reconciliation_items_reconciliationId_fkey" FOREIGN KEY ("reconciliationId") REFERENCES public.bank_reconciliations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: bank_reconciliations bank_reconciliations_bankAccountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.bank_reconciliations
    ADD CONSTRAINT "bank_reconciliations_bankAccountId_fkey" FOREIGN KEY ("bankAccountId") REFERENCES public.chart_of_accounts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: bank_transfers bank_transfers_fromAccountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.bank_transfers
    ADD CONSTRAINT "bank_transfers_fromAccountId_fkey" FOREIGN KEY ("fromAccountId") REFERENCES public.chart_of_accounts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: bank_transfers bank_transfers_toAccountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.bank_transfers
    ADD CONSTRAINT "bank_transfers_toAccountId_fkey" FOREIGN KEY ("toAccountId") REFERENCES public.chart_of_accounts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: business_journey_event_metadata business_journey_event_metadata_eventId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.business_journey_event_metadata
    ADD CONSTRAINT "business_journey_event_metadata_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES public.business_journey_events(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: business_journey_events business_journey_events_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.business_journey_events
    ADD CONSTRAINT "business_journey_events_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: business_journey_events business_journey_events_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.business_journey_events
    ADD CONSTRAINT "business_journey_events_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: business_journey_events business_journey_events_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.business_journey_events
    ADD CONSTRAINT "business_journey_events_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.invoices(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: business_journey_events business_journey_events_paymentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.business_journey_events
    ADD CONSTRAINT "business_journey_events_paymentId_fkey" FOREIGN KEY ("paymentId") REFERENCES public.payments(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: business_journey_events business_journey_events_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.business_journey_events
    ADD CONSTRAINT "business_journey_events_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: business_journey_events business_journey_events_quotationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.business_journey_events
    ADD CONSTRAINT "business_journey_events_quotationId_fkey" FOREIGN KEY ("quotationId") REFERENCES public.quotations(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: cash_transactions cash_transactions_cashAccountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.cash_transactions
    ADD CONSTRAINT "cash_transactions_cashAccountId_fkey" FOREIGN KEY ("cashAccountId") REFERENCES public.chart_of_accounts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: cash_transactions cash_transactions_offsetAccountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.cash_transactions
    ADD CONSTRAINT "cash_transactions_offsetAccountId_fkey" FOREIGN KEY ("offsetAccountId") REFERENCES public.chart_of_accounts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: chart_of_accounts chart_of_accounts_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.chart_of_accounts
    ADD CONSTRAINT "chart_of_accounts_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public.chart_of_accounts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: collection_items collection_items_assetId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.collection_items
    ADD CONSTRAINT "collection_items_assetId_fkey" FOREIGN KEY ("assetId") REFERENCES public.media_assets(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: collection_items collection_items_collectionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.collection_items
    ADD CONSTRAINT "collection_items_collectionId_fkey" FOREIGN KEY ("collectionId") REFERENCES public.collections(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: collections collections_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.collections
    ADD CONSTRAINT "collections_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: collections collections_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.collections
    ADD CONSTRAINT "collections_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.media_projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: content_calendar_items content_calendar_items_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.content_calendar_items
    ADD CONSTRAINT "content_calendar_items_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: content_calendar_items content_calendar_items_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.content_calendar_items
    ADD CONSTRAINT "content_calendar_items_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: content_calendar_items content_calendar_items_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.content_calendar_items
    ADD CONSTRAINT "content_calendar_items_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: content_media content_media_contentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.content_media
    ADD CONSTRAINT "content_media_contentId_fkey" FOREIGN KEY ("contentId") REFERENCES public.content_calendar_items(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: deferred_revenue deferred_revenue_fiscalPeriodId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.deferred_revenue
    ADD CONSTRAINT "deferred_revenue_fiscalPeriodId_fkey" FOREIGN KEY ("fiscalPeriodId") REFERENCES public.fiscal_periods(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: deferred_revenue deferred_revenue_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.deferred_revenue
    ADD CONSTRAINT "deferred_revenue_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.invoices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: depreciation_entries depreciation_entries_assetId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.depreciation_entries
    ADD CONSTRAINT "depreciation_entries_assetId_fkey" FOREIGN KEY ("assetId") REFERENCES public.assets(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: depreciation_entries depreciation_entries_fiscalPeriodId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.depreciation_entries
    ADD CONSTRAINT "depreciation_entries_fiscalPeriodId_fkey" FOREIGN KEY ("fiscalPeriodId") REFERENCES public.fiscal_periods(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: depreciation_entries depreciation_entries_journalEntryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.depreciation_entries
    ADD CONSTRAINT "depreciation_entries_journalEntryId_fkey" FOREIGN KEY ("journalEntryId") REFERENCES public.journal_entries(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: depreciation_entries depreciation_entries_scheduleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.depreciation_entries
    ADD CONSTRAINT "depreciation_entries_scheduleId_fkey" FOREIGN KEY ("scheduleId") REFERENCES public.depreciation_schedules(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: depreciation_schedules depreciation_schedules_assetId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.depreciation_schedules
    ADD CONSTRAINT "depreciation_schedules_assetId_fkey" FOREIGN KEY ("assetId") REFERENCES public.assets(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: documents documents_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT "documents_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.invoices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: documents documents_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT "documents_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: documents documents_quotationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT "documents_quotationId_fkey" FOREIGN KEY ("quotationId") REFERENCES public.quotations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: expense_approval_history expense_approval_history_actionBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.expense_approval_history
    ADD CONSTRAINT "expense_approval_history_actionBy_fkey" FOREIGN KEY ("actionBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: expense_approval_history expense_approval_history_expenseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.expense_approval_history
    ADD CONSTRAINT "expense_approval_history_expenseId_fkey" FOREIGN KEY ("expenseId") REFERENCES public.expenses(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: expense_budgets expense_budgets_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.expense_budgets
    ADD CONSTRAINT "expense_budgets_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.expense_categories(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: expense_budgets expense_budgets_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.expense_budgets
    ADD CONSTRAINT "expense_budgets_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: expense_budgets expense_budgets_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.expense_budgets
    ADD CONSTRAINT "expense_budgets_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: expense_categories expense_categories_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.expense_categories
    ADD CONSTRAINT "expense_categories_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public.expense_categories(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: expense_comments expense_comments_expenseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.expense_comments
    ADD CONSTRAINT "expense_comments_expenseId_fkey" FOREIGN KEY ("expenseId") REFERENCES public.expenses(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: expense_comments expense_comments_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.expense_comments
    ADD CONSTRAINT "expense_comments_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: expense_documents expense_documents_expenseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.expense_documents
    ADD CONSTRAINT "expense_documents_expenseId_fkey" FOREIGN KEY ("expenseId") REFERENCES public.expenses(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: expenses expenses_approvedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT "expenses_approvedBy_fkey" FOREIGN KEY ("approvedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: expenses expenses_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT "expenses_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.expense_categories(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: expenses expenses_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT "expenses_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: expenses expenses_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT "expenses_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.invoices(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: expenses expenses_paymentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT "expenses_paymentId_fkey" FOREIGN KEY ("paymentId") REFERENCES public.payments(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: expenses expenses_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT "expenses_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: expenses expenses_purchaseOrderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT "expenses_purchaseOrderId_fkey" FOREIGN KEY ("purchaseOrderId") REFERENCES public.purchase_orders(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: expenses expenses_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT "expenses_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: expenses expenses_vendorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT "expenses_vendorId_fkey" FOREIGN KEY ("vendorId") REFERENCES public.vendors(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: expenses expenses_vendorInvoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT "expenses_vendorInvoiceId_fkey" FOREIGN KEY ("vendorInvoiceId") REFERENCES public.vendor_invoices(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: feature_flag_events feature_flag_events_flagId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.feature_flag_events
    ADD CONSTRAINT "feature_flag_events_flagId_fkey" FOREIGN KEY ("flagId") REFERENCES public.feature_flags(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: frame_comments frame_comments_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.frame_comments
    ADD CONSTRAINT "frame_comments_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: frame_comments frame_comments_frameId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.frame_comments
    ADD CONSTRAINT "frame_comments_frameId_fkey" FOREIGN KEY ("frameId") REFERENCES public.media_frames(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: frame_comments frame_comments_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.frame_comments
    ADD CONSTRAINT "frame_comments_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public.frame_comments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: frame_comments frame_comments_resolvedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.frame_comments
    ADD CONSTRAINT "frame_comments_resolvedBy_fkey" FOREIGN KEY ("resolvedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: frame_drawings frame_drawings_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.frame_drawings
    ADD CONSTRAINT "frame_drawings_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: frame_drawings frame_drawings_frameId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.frame_drawings
    ADD CONSTRAINT "frame_drawings_frameId_fkey" FOREIGN KEY ("frameId") REFERENCES public.media_frames(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: general_ledger general_ledger_accountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.general_ledger
    ADD CONSTRAINT "general_ledger_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES public.chart_of_accounts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: general_ledger general_ledger_journalEntryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.general_ledger
    ADD CONSTRAINT "general_ledger_journalEntryId_fkey" FOREIGN KEY ("journalEntryId") REFERENCES public.journal_entries(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: goods_receipt_items goods_receipt_items_grId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.goods_receipt_items
    ADD CONSTRAINT "goods_receipt_items_grId_fkey" FOREIGN KEY ("grId") REFERENCES public.goods_receipts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: goods_receipt_items goods_receipt_items_poItemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.goods_receipt_items
    ADD CONSTRAINT "goods_receipt_items_poItemId_fkey" FOREIGN KEY ("poItemId") REFERENCES public.purchase_order_items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: goods_receipts goods_receipts_poId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.goods_receipts
    ADD CONSTRAINT "goods_receipts_poId_fkey" FOREIGN KEY ("poId") REFERENCES public.purchase_orders(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: goods_receipts goods_receipts_vendorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.goods_receipts
    ADD CONSTRAINT "goods_receipts_vendorId_fkey" FOREIGN KEY ("vendorId") REFERENCES public.vendors(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: invoices invoices_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: invoices invoices_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: invoices invoices_markedPaidBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_markedPaidBy_fkey" FOREIGN KEY ("markedPaidBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: invoices invoices_paymentMilestoneId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_paymentMilestoneId_fkey" FOREIGN KEY ("paymentMilestoneId") REFERENCES public.payment_milestones(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: invoices invoices_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: invoices invoices_projectMilestoneId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_projectMilestoneId_fkey" FOREIGN KEY ("projectMilestoneId") REFERENCES public.project_milestones(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: invoices invoices_quotationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_quotationId_fkey" FOREIGN KEY ("quotationId") REFERENCES public.quotations(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: journal_entries journal_entries_fiscalPeriodId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT "journal_entries_fiscalPeriodId_fkey" FOREIGN KEY ("fiscalPeriodId") REFERENCES public.fiscal_periods(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: journal_entries journal_entries_reversedEntryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT "journal_entries_reversedEntryId_fkey" FOREIGN KEY ("reversedEntryId") REFERENCES public.journal_entries(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: journal_line_items journal_line_items_accountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.journal_line_items
    ADD CONSTRAINT "journal_line_items_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES public.chart_of_accounts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: journal_line_items journal_line_items_journalEntryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.journal_line_items
    ADD CONSTRAINT "journal_line_items_journalEntryId_fkey" FOREIGN KEY ("journalEntryId") REFERENCES public.journal_entries(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: labor_entries labor_entries_costAllocationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.labor_entries
    ADD CONSTRAINT "labor_entries_costAllocationId_fkey" FOREIGN KEY ("costAllocationId") REFERENCES public.project_cost_allocations(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: labor_entries labor_entries_expenseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.labor_entries
    ADD CONSTRAINT "labor_entries_expenseId_fkey" FOREIGN KEY ("expenseId") REFERENCES public.expenses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: labor_entries labor_entries_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.labor_entries
    ADD CONSTRAINT "labor_entries_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: labor_entries labor_entries_teamMemberId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.labor_entries
    ADD CONSTRAINT "labor_entries_teamMemberId_fkey" FOREIGN KEY ("teamMemberId") REFERENCES public.project_team_members(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: labor_entries labor_entries_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.labor_entries
    ADD CONSTRAINT "labor_entries_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: maintenance_records maintenance_records_assetId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.maintenance_records
    ADD CONSTRAINT "maintenance_records_assetId_fkey" FOREIGN KEY ("assetId") REFERENCES public.assets(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: maintenance_schedules maintenance_schedules_assetId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.maintenance_schedules
    ADD CONSTRAINT "maintenance_schedules_assetId_fkey" FOREIGN KEY ("assetId") REFERENCES public.assets(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: media_assets media_assets_folderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.media_assets
    ADD CONSTRAINT "media_assets_folderId_fkey" FOREIGN KEY ("folderId") REFERENCES public.media_folders(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: media_assets media_assets_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.media_assets
    ADD CONSTRAINT "media_assets_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.media_projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: media_assets media_assets_uploadedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.media_assets
    ADD CONSTRAINT "media_assets_uploadedBy_fkey" FOREIGN KEY ("uploadedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: media_collaborators media_collaborators_invitedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.media_collaborators
    ADD CONSTRAINT "media_collaborators_invitedBy_fkey" FOREIGN KEY ("invitedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: media_collaborators media_collaborators_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.media_collaborators
    ADD CONSTRAINT "media_collaborators_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.media_projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: media_collaborators media_collaborators_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.media_collaborators
    ADD CONSTRAINT "media_collaborators_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: media_folders media_folders_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.media_folders
    ADD CONSTRAINT "media_folders_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: media_folders media_folders_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.media_folders
    ADD CONSTRAINT "media_folders_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public.media_folders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: media_folders media_folders_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.media_folders
    ADD CONSTRAINT "media_folders_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.media_projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: media_frames media_frames_assetId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.media_frames
    ADD CONSTRAINT "media_frames_assetId_fkey" FOREIGN KEY ("assetId") REFERENCES public.media_assets(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: media_frames media_frames_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.media_frames
    ADD CONSTRAINT "media_frames_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: media_projects media_projects_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.media_projects
    ADD CONSTRAINT "media_projects_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: media_projects media_projects_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.media_projects
    ADD CONSTRAINT "media_projects_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: media_projects media_projects_folderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.media_projects
    ADD CONSTRAINT "media_projects_folderId_fkey" FOREIGN KEY ("folderId") REFERENCES public.media_folders(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: media_projects media_projects_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.media_projects
    ADD CONSTRAINT "media_projects_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: media_versions media_versions_assetId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.media_versions
    ADD CONSTRAINT "media_versions_assetId_fkey" FOREIGN KEY ("assetId") REFERENCES public.media_assets(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: media_versions media_versions_uploadedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.media_versions
    ADD CONSTRAINT "media_versions_uploadedBy_fkey" FOREIGN KEY ("uploadedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: payment_milestones payment_milestones_projectMilestoneId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.payment_milestones
    ADD CONSTRAINT "payment_milestones_projectMilestoneId_fkey" FOREIGN KEY ("projectMilestoneId") REFERENCES public.project_milestones(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: payment_milestones payment_milestones_quotationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.payment_milestones
    ADD CONSTRAINT "payment_milestones_quotationId_fkey" FOREIGN KEY ("quotationId") REFERENCES public.quotations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payments payments_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT "payments_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.invoices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_cost_allocations project_cost_allocations_expenseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.project_cost_allocations
    ADD CONSTRAINT "project_cost_allocations_expenseId_fkey" FOREIGN KEY ("expenseId") REFERENCES public.expenses(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_cost_allocations project_cost_allocations_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.project_cost_allocations
    ADD CONSTRAINT "project_cost_allocations_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_equipment_usage project_equipment_usage_assetId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.project_equipment_usage
    ADD CONSTRAINT "project_equipment_usage_assetId_fkey" FOREIGN KEY ("assetId") REFERENCES public.assets(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_equipment_usage project_equipment_usage_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.project_equipment_usage
    ADD CONSTRAINT "project_equipment_usage_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_milestones project_milestones_predecessorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.project_milestones
    ADD CONSTRAINT "project_milestones_predecessorId_fkey" FOREIGN KEY ("predecessorId") REFERENCES public.project_milestones(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: project_milestones project_milestones_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.project_milestones
    ADD CONSTRAINT "project_milestones_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_team_members project_team_members_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.project_team_members
    ADD CONSTRAINT "project_team_members_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_team_members project_team_members_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.project_team_members
    ADD CONSTRAINT "project_team_members_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: projects projects_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT "projects_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: projects projects_projectTypeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT "projects_projectTypeId_fkey" FOREIGN KEY ("projectTypeId") REFERENCES public.project_type_configs(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: purchase_order_items purchase_order_items_assetId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT "purchase_order_items_assetId_fkey" FOREIGN KEY ("assetId") REFERENCES public.assets(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: purchase_order_items purchase_order_items_expenseCategoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT "purchase_order_items_expenseCategoryId_fkey" FOREIGN KEY ("expenseCategoryId") REFERENCES public.expense_categories(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: purchase_order_items purchase_order_items_poId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT "purchase_order_items_poId_fkey" FOREIGN KEY ("poId") REFERENCES public.purchase_orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: purchase_orders purchase_orders_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT "purchase_orders_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: purchase_orders purchase_orders_vendorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT "purchase_orders_vendorId_fkey" FOREIGN KEY ("vendorId") REFERENCES public.vendors(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: quotations quotations_approvedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT "quotations_approvedBy_fkey" FOREIGN KEY ("approvedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: quotations quotations_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT "quotations_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: quotations quotations_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT "quotations_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: quotations quotations_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT "quotations_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: quotations quotations_rejectedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT "quotations_rejectedBy_fkey" FOREIGN KEY ("rejectedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: refresh_tokens refresh_tokens_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT "refresh_tokens_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: report_sections report_sections_reportId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.report_sections
    ADD CONSTRAINT "report_sections_reportId_fkey" FOREIGN KEY ("reportId") REFERENCES public.social_media_reports(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: social_media_reports social_media_reports_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.social_media_reports
    ADD CONSTRAINT "social_media_reports_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_preferences user_preferences_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.user_preferences
    ADD CONSTRAINT "user_preferences_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: vendor_invoice_items vendor_invoice_items_poItemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.vendor_invoice_items
    ADD CONSTRAINT "vendor_invoice_items_poItemId_fkey" FOREIGN KEY ("poItemId") REFERENCES public.purchase_order_items(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: vendor_invoice_items vendor_invoice_items_viId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.vendor_invoice_items
    ADD CONSTRAINT "vendor_invoice_items_viId_fkey" FOREIGN KEY ("viId") REFERENCES public.vendor_invoices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vendor_invoices vendor_invoices_accountsPayableId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.vendor_invoices
    ADD CONSTRAINT "vendor_invoices_accountsPayableId_fkey" FOREIGN KEY ("accountsPayableId") REFERENCES public.accounts_payable(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: vendor_invoices vendor_invoices_grId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.vendor_invoices
    ADD CONSTRAINT "vendor_invoices_grId_fkey" FOREIGN KEY ("grId") REFERENCES public.goods_receipts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: vendor_invoices vendor_invoices_poId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.vendor_invoices
    ADD CONSTRAINT "vendor_invoices_poId_fkey" FOREIGN KEY ("poId") REFERENCES public.purchase_orders(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: vendor_invoices vendor_invoices_vendorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.vendor_invoices
    ADD CONSTRAINT "vendor_invoices_vendorId_fkey" FOREIGN KEY ("vendorId") REFERENCES public.vendors(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: vendor_payment_allocations vendor_payment_allocations_apId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.vendor_payment_allocations
    ADD CONSTRAINT "vendor_payment_allocations_apId_fkey" FOREIGN KEY ("apId") REFERENCES public.accounts_payable(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: vendor_payment_allocations vendor_payment_allocations_paymentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.vendor_payment_allocations
    ADD CONSTRAINT "vendor_payment_allocations_paymentId_fkey" FOREIGN KEY ("paymentId") REFERENCES public.vendor_payments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vendor_payments vendor_payments_vendorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.vendor_payments
    ADD CONSTRAINT "vendor_payments_vendorId_fkey" FOREIGN KEY ("vendorId") REFERENCES public.vendors(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: work_in_progress work_in_progress_fiscalPeriodId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.work_in_progress
    ADD CONSTRAINT "work_in_progress_fiscalPeriodId_fkey" FOREIGN KEY ("fiscalPeriodId") REFERENCES public.fiscal_periods(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: work_in_progress work_in_progress_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: invoiceuser
--

ALTER TABLE ONLY public.work_in_progress
    ADD CONSTRAINT "work_in_progress_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: invoiceuser
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict JGqL3Sr1R6ZJzcnLG4o02qgNnS1KmTdBe3UEEFXYPhLMlIzGmG3MgYXwe1vwdzM

